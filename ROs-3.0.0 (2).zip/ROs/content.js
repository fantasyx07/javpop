(function () {
  'use strict';
  if (window.__ROZAKA) return;

  const S = window.__ROZAKA = {
    game: null,
    ready: false,
    god: true,
    hpLock: false,
    oneShot: false,
    exp: false,
    pickup: false,
    findRate: false,
    autoExp: false,
    autoFest: false,
    expStage: '',
    findExtra: 3,
    autoPick: false,
    best: false,
    speed: 1,
    opacity: 100,
    hidden: false,
    cls: '',
    rarity: { legendary: true, epic: true, rare: true, uncommon: true, common: true },
    drawCount: 1,
    diag: true,
    lastGachaError: '',
    ver: '3.0.0'
  };


  const CHEAT_KEY = 'rozaka.cheats';

  /* ============================================================
     0) 診斷
     ============================================================ */
  const diagLog = [];

  function diagPush(tag, txt) {
    if (!S.diag) return;
    let s = String(txt == null ? '' : txt);
    if (s.length > 2000) s = s.slice(0, 2000) + '…';
    const t = new Date();
    const hh = String(t.getHours()).padStart(2, '0');
    const mm = String(t.getMinutes()).padStart(2, '0');
    const ss = String(t.getSeconds()).padStart(2, '0');
    diagLog.push('[' + hh + ':' + mm + ':' + ss + '] ' + tag + ' ' + s);
    while (diagLog.length > 90) diagLog.shift();
  }

  function diagText() {
    const g = S.game;
    const head = 'build=' + S.ver + ' stage=' + (S.stageInfo || '?') +
      ' season=' + (S.stageSeason ? 'y' : 'n') +
      ' game=' + (S.ready ? 'yes' : 'no') + ' speed=' + S.speed +
      ' find=' + (S.findRate ? 'y' : 'n') + ' extra=' + S.findExtra +
      ' pick=' + (g && Array.isArray(g.pickups) ? g.pickups.length : '?');
    return head + '\n' + diagLog.join('\n');
  }

  function copyDiag(notify) {
    const txt = diagText();
    function fallback() {
      const ta = document.createElement('textarea');
      ta.value = txt;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      let ok = false;
      try { ok = document.execCommand('copy'); } catch (e) {}
      ta.remove();
      if (notify) notify(ok ? '診斷已複製' : '複製失敗，請長按選取');
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(txt).then(function () {
        if (notify) notify('診斷已複製');
      }, fallback);
    } else {
      fallback();
    }
  }

  function shallow(o) {
    if (!o || typeof o !== 'object') return String(o);
    const out = {};
    let n = 0;
    for (const k of Object.keys(o)) {
      if (n++ > 16) break;
      const v = o[k];
      out[k] = (v && typeof v === 'object') ? '{…}' : v;
    }
    return JSON.stringify(out);
  }

  /* ============================================================
     1) 網路記錄
     ============================================================ */
  function isGachaBody(b) {
    return typeof b === 'string' && b.indexOf('gacha') >= 0 && b.indexOf('"op"') >= 0;
  }

  function noteError(res) {
    try {
      res.clone().text().then(function (txt) {
        let msg = txt || ('HTTP ' + res.status);
        try {
          const j = JSON.parse(txt);
          msg = j.code || j.error || j.message || msg;
        } catch (e) {}
        S.lastGachaError = '伺服器回應：' + msg;
        diagPush('[GACHA-FAIL]', 'HTTP ' + res.status + ' ' + txt);
      }).catch(function () {});
    } catch (e) {}
  }

  function bumpDraws(body) {
    if (!S.drawCount || S.drawCount <= 1) return body;
    try {
      const j = JSON.parse(body);
      if (!j || typeof j !== 'object') return body;
      let touched = false;
      for (const k of ['draws', 'count', 'times']) {
        if (typeof j[k] === 'number') { j[k] = S.drawCount; touched = true; }
      }
      return touched ? JSON.stringify(j) : body;
    } catch (e) { return body; }
  }

  try {
    const nativeFetch = window.fetch;
    if (nativeFetch) {
      window.fetch = function (input, init) {
        const url = typeof input === 'string' ? input : (input && input.url) || '';
        let body = init && typeof init.body === 'string' ? init.body : '';
        const hit = !!body && isGachaBody(body);
        if (hit) {
          const nb = bumpDraws(body);
          if (nb !== body && init) { init.body = nb; body = nb; }
          diagPush('[GACHA-REQ]', url + ' :: ' + body);
        }
        const p = nativeFetch.apply(this, arguments);
        if (!hit) return p;
        return p.then(function (res) {
          if (!res.ok) { noteError(res); return res; }
          try {
            res.clone().text().then(function (txt) {
              diagPush('[GACHA-RES]', 'HTTP ' + res.status + ' ' + txt);
            }).catch(function () {});
          } catch (e) {}
          return res;
        });
      };
    }
  } catch (e) {}

  /* ============================================================
     2) 抓遊戲實例
     ============================================================ */
  const nativeDP = Object.defineProperty;
  const pending = [];
  let capturing = true;

  Object.defineProperty = function (target, key, desc) {
    if (capturing && key === 'god' && target && typeof target === 'object') {
      pending.push(target);
    }
    return nativeDP(target, key, desc);
  };

  try {
    nativeDP(Object.prototype, 'god', {
      configurable: true,
      enumerable: false,
      get: function () { return undefined; },
      set: function (v) {
        nativeDP(this, 'god', { value: v, writable: true, enumerable: true, configurable: true });
      }
    });
  } catch (e) {}

  function looksLikeGame(o) {
    try {
      return !!(o && typeof o === 'object' &&
        o.player && Array.isArray(o.enemies) &&
        typeof o.hurtPlayer === 'function' &&
        typeof o.step === 'function' &&
        typeof o.damageEnemy === 'function' &&
        o.stats && typeof o.stats.maxHp === 'number');
    } catch (e) { return false; }
  }

  function stopCapture() {
    capturing = false;
    try { Object.defineProperty = nativeDP; } catch (e) {}
    try { delete Object.prototype.god; } catch (e) {}
    pending.length = 0;
  }

  let injLogged = 0;

  function install(g) {
    const P = Object.getPrototypeOf(g);
    if (!P) return;
    S.game = g;
    S.ready = true;
    if (P.__zakaHooked) return;

    diagPush('[INIT]', 'hooked; ' +
      ' killsBy=' + (g.killsBy ? (g.killsBy.constructor && g.killsBy.constructor.name) : 'none') +
      ' gkeys=' + Object.keys(g).length + ' app=' + typeof g.app);

    let findTick = 0;

    const origHurt = P.hurtPlayer;
    const origDmg = P.damageEnemy;
    const origExp = P.gainExp;
    const origStep = P.step;
    const origDrop = P.dropPickup;

    P.hurtPlayer = function () {
      if (S.god) {
        try { this.hp = this.stats.maxHp; this.player.dead = false; } catch (e) {}
        return;
      }
      return origHurt.apply(this, arguments);
    };

    P.damageEnemy = function (enemy, amount, opts) {
      if (S.oneShot && typeof amount === 'number') amount *= 999;
      return origDmg.call(this, enemy, amount, opts);
    };

    P.gainExp = function (n) {
      if (S.exp && typeof n === 'number') n *= 20;
      return origExp.call(this, n);
    };

    if (typeof origDrop === 'function') {
      P.dropPickup = function (kind, x, y, value, ref, quality, src, skip) {
        if (S.findRate && (kind === 'drop' || kind === 'loot')) {
          const out = origDrop.call(this, kind, x, y, value, ref, quality, src, skip);
          const extra = Math.max(1, Math.min(6, S.findExtra | 0));
          for (let i = 0; i < extra; i++) {
            try {
              origDrop.call(this, kind,
                x + (Math.random() - 0.5) * 44,
                y + (Math.random() - 0.5) * 44,
                value, ref, quality, src, skip);
            } catch (e) {}
          }
          return out;
        }
        return origDrop.call(this, kind, x, y, value, ref, quality, src, skip);
      };
    }

    ['rollQuality', 'pickQuality', 'rollRarity', 'rollDrop', 'rollFind',
     'rollChance', 'tryDrop', 'maybeDrop', 'chance'].forEach(function (name) {
      const orig = P[name];
      if (typeof orig !== 'function') return;
      P[name] = function () {
        const first = orig.apply(this, arguments);
        if (!S.findRate) return first;
        if (typeof first === 'number') {
          let best = first;
          for (let i = 0; i < 3; i++) {
            const v = orig.apply(this, arguments);
            if (typeof v === 'number' && v > best) best = v;
          }
          return best;
        }
        if (first === false) {
          for (let i = 0; i < 3; i++) if (orig.apply(this, arguments)) return true;
          return false;
        }
        return first;
      };
    });



    P.step = function (dt) {
      S.game = this;
      this.god = !!S.god;
      if (S.god && this.player) this.player.dead = false;
      if (S.hpLock && this.stats) this.hp = this.stats.maxHp;
      if (S.findRate && (++findTick % 30 === 0)) findRateOn();
      if (this.stageId && S.stageInfo !== this.stageId) {
        S.stageInfo = this.stageId;
        S.stageSeason = !!(this.script && this.script.season);
        diagPush('[STAGE]', String(this.stageId) + ' season=' + (this.stageSeason ? 'y' : 'n'));
      }
      const a = Array.prototype.slice.call(arguments);
      if (S.speed !== 1 && typeof a[0] === 'number') {
        a[0] = Math.min(a[0], 0.1) * S.speed;
      }
      return origStep.apply(this, a);
    };

    Object.defineProperty(P, '__zakaHooked', { value: true, enumerable: false });
    stopCapture();
  }

  const probe = setInterval(function () {
    if (S.ready) { clearInterval(probe); return; }
    for (let i = 0; i < pending.length; i++) {
      if (looksLikeGame(pending[i])) { clearInterval(probe); install(pending[i]); return; }
    }
  }, 250);

  setTimeout(function () { if (!S.ready && capturing) stopCapture(); }, 120000);

  function annihilateEnemies() {
    const g = S.game;
    if (!g || !Array.isArray(g.enemies) || typeof g.killEnemy !== 'function') return 0;
    let n = 0;
    for (const e of g.enemies) {
      if (e && !e.dead) { try { g.killEnemy(e); n++; } catch (err) {} }
    }
    return n;
  }

  /* ============================================================
     3) 尋寶率 / 磁吸
     ============================================================ */
  const FIND_FIELDS = [
    ['stats', 'find'], ['stats', 'findRate'], ['stats', 'loot'], ['stats', 'lootRate'],
    ['stats', 'dropRate'], ['stats', 'magicFind'], ['stats', 'mf'], ['stats', 'luck'],
    ['stats', 'treasure'], ['stats', 'treasureRate'], ['stats', 'dropBonus'],
    ['stats', 'bonusDrop'], ['player', 'find'], ['player', 'luck'],
    ['findRate'], ['lootRate'], ['dropRate'], ['magicFind']
  ];
  const FIND_BIG = 9999;
  const savedFind = new Map();

  function findRateOn() {
    const g = S.game;
    if (!g) return;
    for (const path of FIND_FIELDS) {
      try {
        const obj = path.length === 2 ? g[path[0]] : g;
        if (!obj) continue;
        const key = path[path.length - 1];
        if (typeof obj[key] === 'number') {
          const id = path.join('.');
          if (!savedFind.has(id)) savedFind.set(id, { obj: obj, key: key, v: obj[key] });
          obj[key] = FIND_BIG;
        }
      } catch (e) {}
    }
  }

  function findRateOff() {
    savedFind.forEach(function (rec) {
      try { rec.obj[rec.key] = rec.v; } catch (e) {}
    });
    savedFind.clear();
  }

  const MAGNET = [
    ['stats', 'magnet'], ['stats', 'magnetRange'], ['stats', 'pickupRange'], ['stats', 'pickupRadius'],
    ['player', 'magnet'], ['player', 'magnetRange'], ['player', 'pickupRange'], ['player', 'pickupRadius'],
    ['magnetRadius'], ['pickupRadius'], ['pickupRange']
  ];
  const MAGNET_BIG = 4000;
  const savedMagnet = new Map();

  function magnetOn() {
    const g = S.game;
    if (!g) return;
    for (const path of MAGNET) {
      try {
        const obj = path.length === 2 ? g[path[0]] : g;
        if (!obj) continue;
        const key = path[path.length - 1];
        if (typeof obj[key] === 'number') {
          const id = path.join('.');
          if (!savedMagnet.has(id)) savedMagnet.set(id, { obj: obj, key: key, v: obj[key] });
          obj[key] = MAGNET_BIG;
        }
      } catch (e) {}
    }
  }

  function magnetOff() {
    savedMagnet.forEach(function (rec) {
      try { rec.obj[rec.key] = rec.v; } catch (e) {}
    });
    savedMagnet.clear();
  }

  function collectAll() {
    const g = S.game;
    if (!g || !g.player) return 0;
    const px = g.player.x, py = g.player.y;
    if (typeof px !== 'number' || typeof py !== 'number') return 0;

    const lists = [];
    if (Array.isArray(g.pickups)) lists.push(g.pickups);
    for (const k of Object.keys(g)) {
      if (k === 'enemies' || k === 'pickups') continue;
      let v;
      try { v = g[k]; } catch (e) { continue; }
      if (!Array.isArray(v) || !v.length) continue;
      const s = v[0];
      if (!s || typeof s !== 'object' || typeof s.x !== 'number' || typeof s.y !== 'number') continue;
      lists.push(v);
    }

    let n = 0;
    for (const list of lists) {
      for (let i = 0; i < list.length; i++) {
        const it = list[i];
        if (!it || typeof it !== 'object') continue;
        if (it.dead || it.collected || it.taken || it.picked) continue;
        if (typeof it.x !== 'number' || typeof it.y !== 'number') continue;
        if (it.hp !== undefined && it.def && it.def.hp !== undefined) continue;

        it.x = px;
        it.y = py;
        if (typeof it.vx === 'number') it.vx = 0;
        if (typeof it.vy === 'number') it.vy = 0;
        if (typeof it.pull === 'boolean') it.pull = true;
        n++;

        for (const fn of ['collect', 'pickup', 'pickUp', 'take', 'grab']) {
          if (typeof g[fn] === 'function') { try { g[fn](it); } catch (e) {} }
        }
      }
    }
    return n;
  }

  function setPickup(on) {
    S.pickup = !!on;
    if (S.pickup) { magnetOn(); collectAll(); }
    else magnetOff();
  }

  /* ============================================================
     4) 卡片等級
     ============================================================ */
  const RARITY_DEFS = [
    { k: 'legendary', tier: 4, label: '傳說', color: '#ffb347' },
    { k: 'epic', tier: 3, label: '史詩', color: '#c084fc' },
    { k: 'rare', tier: 2, label: '稀有', color: '#60a5fa' },
    { k: 'uncommon', tier: 1, label: '優良', color: '#4ade80' },
    { k: 'common', tier: 0, label: '普通', color: '#94a3b8' }
  ];
  const TIER_KEY = ['common', 'uncommon', 'rare', 'epic', 'legendary'];
  const HEX_TIER = {
    '#2fb550': 1, '#3cc25c': 1, '#3a78e6': 2, '#4a82e6': 2, '#2f7bff': 2,
    '#9a45e0': 3, '#a050e0': 3, '#a040ff': 3,
    '#f08a20': 4, '#f07a12': 4, '#ff9a2e': 4
  };
  const RARITY_ZH = {
    legendary: ['傳說', '传说', '傳奇', '传奇', 'LEGENDARY'],
    epic: ['史詩', '史诗', 'EPIC'],
    rare: ['稀有', 'RARE'],
    uncommon: ['優良', '优良', 'UNCOMMON'],
    common: ['普通', 'COMMON']
  };
  const RARITY_KEY = 'rozaka.rarity';

  function clsOf(n) {
    if (!n) return '';
    const c = n.className;
    if (typeof c === 'string') return c;
    if (c && typeof c.baseVal === 'string') return c.baseVal;
    return '';
  }

  function tierOfCard(el) {
    const own = clsOf(el);
    let m = own.match(/(?:^|\s)[qr]([0-4])(?:\s|$)/);
    if (m) return +m[1];

    const badge = el.querySelector('.rarity');
    if (badge) {
      m = clsOf(badge).match(/(?:^|\s)r([0-4])(?:\s|$)/);
      if (m) return +m[1];
    }

    let hex = '';
    try { hex = getComputedStyle(el).getPropertyValue('--qc').trim().toLowerCase(); } catch (e) {}
    if (hex && HEX_TIER[hex] !== undefined) return HEX_TIER[hex];

    const hay = (el.textContent || '').toUpperCase();
    for (const d of RARITY_DEFS) {
      const list = RARITY_ZH[d.k];
      for (let i = 0; i < list.length; i++) if (hay.indexOf(list[i]) >= 0) return d.tier;
    }
    return -1;
  }

  function globalAllowed(tier) {
    if (tier < 0) return true;
    const on = Object.keys(S.rarity).filter(function (k) { return S.rarity[k]; });
    if (!on.length) return true;
    return !!S.rarity[TIER_KEY[tier]];
  }

  function ruleAllowed(rule, tier) {
    if (rule === null || rule === undefined) return globalAllowed(tier);
    if (tier < 0) return true;
    return rule.indexOf(tier) >= 0;
  }

  function tierLabel(t) {
    const d = RARITY_DEFS.find(function (x) { return x.tier === t; });
    return d ? d.label : '';
  }

  /* ============================================================
     7) 職業 / 技能
     ============================================================ */
  const BUILD_KEY = 'rozaka.builds';
  const CLS_KEY = 'rozaka.cls';
  const POOL_KEY = 'rozaka.pool';

  let CLASSES = ['Swordsman', 'Mage', 'Archer', 'Acolyte', 'Merchant', 'Thief',
                 'Knight', 'Crusader', 'Wizard', 'Sage', 'Hunter', 'Bard', 'Dancer',
                 'Priest', 'Monk', 'Blacksmith', 'Alchemist', 'Assassin', 'Rogue',
                 'Gunslinger', 'Ninja', 'Super Novice'];

  const builds = {};
  const pool = {};

  function cleanName(s) {
    s = String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
    if (!s) return '';
    s = s.replace(/[（(][^）)]*[）)]\s*$/, '').trim();
    if (!s) return '';
    if (s.length > 20) return '';
    if (/^[\d\s.·%+\-/]+$/.test(s)) return '';
    for (const d of RARITY_DEFS) {
      if (s === d.label) return '';
      if (RARITY_ZH[d.k].indexOf(s.toUpperCase()) >= 0) return '';
    }
    return s;
  }

  function toEntry(e) {
    if (typeof e === 'string') return { n: cleanName(e), r: null };
    if (!e || typeof e !== 'object') return null;
    const n = cleanName(e.n);
    if (!n) return null;
    let r = null;
    if (Array.isArray(e.r)) {
      r = e.r.filter(function (t) { return typeof t === 'number' && t >= 0 && t <= 4; });
    }
    return { n: n, r: r };
  }

  function loadStore() {
    try {
      const b = JSON.parse(localStorage.getItem(BUILD_KEY) || '{}');
      if (b && typeof b === 'object') {
        for (const k in b) {
          if (!Array.isArray(b[k])) continue;
          const arr = [];
          b[k].slice(0, 80).forEach(function (e) {
            const en = toEntry(e);
            if (en && !arr.some(function (x) { return x.n === en.n; })) arr.push(en);
          });
          builds[k] = arr;
        }
      }
      const p = JSON.parse(localStorage.getItem(POOL_KEY) || '{}');
      if (p && typeof p === 'object') {
        for (const k in p) if (Array.isArray(p[k])) pool[k] = p[k].slice(0, 400);
      }
      const cs = JSON.parse(localStorage.getItem('rozaka.classes') || 'null');
      if (Array.isArray(cs) && cs.length) {
        cs.forEach(function (c) { if (typeof c === 'string' && CLASSES.indexOf(c) < 0) CLASSES.push(c); });
      }
      const r = JSON.parse(localStorage.getItem(RARITY_KEY) || 'null');
      if (r && typeof r === 'object') {
        RARITY_DEFS.forEach(function (d) {
          if (typeof r[d.k] === 'boolean') S.rarity[d.k] = r[d.k];
        });
      }
      const ch = JSON.parse(localStorage.getItem(CHEAT_KEY) || 'null');
      if (ch && typeof ch === 'object') {
        if (typeof ch.dc === 'number' && ch.dc >= 1) S.drawCount = Math.min(100, Math.round(ch.dc));
        if (typeof ch.dg === 'boolean') S.diag = ch.dg;
        if (typeof ch.sp === 'number' && ch.sp >= 1 && ch.sp <= 20) S.speed = ch.sp;
        if (typeof ch.fr === 'boolean') S.findRate = ch.fr;
        if (typeof ch.fe === 'number' && ch.fe >= 0) S.findExtra = Math.min(6, Math.round(ch.fe));
      }
      const c = localStorage.getItem(CLS_KEY);
      if (c && CLASSES.indexOf(c) >= 0) S.cls = c;
    } catch (e) {}
    if (!S.cls) S.cls = CLASSES[0];
  }

  function saveStore() {
    try { localStorage.setItem(BUILD_KEY, JSON.stringify(builds)); } catch (e) {}
    try { localStorage.setItem(POOL_KEY, JSON.stringify(pool)); } catch (e) {}
    try { localStorage.setItem(CLS_KEY, S.cls); } catch (e) {}
    try { localStorage.setItem(RARITY_KEY, JSON.stringify(S.rarity)); } catch (e) {}
  }

  function saveCheat() {
    try {
      localStorage.setItem(CHEAT_KEY, JSON.stringify({
        dc: S.drawCount, dg: S.diag, sp: S.speed,
        fr: S.findRate, fe: S.findExtra
      }));
    } catch (e) {}
  }

  function saveClasses() {
    try { localStorage.setItem('rozaka.classes', JSON.stringify(CLASSES)); } catch (e) {}
  }

  function addPool(cls, name) {
    name = cleanName(name);
    if (!name) return false;
    if (!pool[cls]) pool[cls] = [];
    if (pool[cls].indexOf(name) >= 0) return false;
    pool[cls].push(name);
    if (pool[cls].length > 400) pool[cls].shift();
    return true;
  }

  function poolUnion() {
    const out = [];
    const seen = {};
    for (const k in pool) {
      pool[k].forEach(function (n) {
        if (seen[n]) return;
        seen[n] = 1;
        out.push(n);
      });
    }
    return out.sort(function (a, b) { return a.localeCompare(b, 'zh-Hant'); });
  }

  function entries() { return (builds[S.cls] || []).slice(); }

  let lastPickAt = 0;
  let lastPickName = '';
  let lastHarvestAt = 0;

  function fireClick(el) {
    const r = el.getBoundingClientRect();
    const x = r.left + r.width / 2, y = r.top + r.height / 2;
    const o = { bubbles: true, cancelable: true, clientX: x, clientY: y,
                view: window, button: 0, buttons: 0, pointerId: 1,
                pointerType: 'mouse', isPrimary: true };
    try { el.dispatchEvent(new PointerEvent('pointerdown', o)); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mousedown', o)); } catch (e) {}
    try { el.dispatchEvent(new PointerEvent('pointerup', o)); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mouseup', o)); } catch (e) {}
    try { el.click(); } catch (e) {}
  }

  function pickerOpen() {
    const el = document.getElementById('picker');
    if (!el || el.classList.contains('hidden')) return false;
    if (el.classList.contains('closing')) return false;
    return true;
  }

  function cardCandidates() {
    const box = document.getElementById('pk-cards');
    if (!box) return [];
    const out = [];
    const cards = box.querySelectorAll('.pk-card');
    for (let i = 0; i < cards.length; i++) {
      const el = cards[i];
      const nameEl = el.querySelector('.pk-name');
      const name = cleanName(nameEl ? nameEl.textContent : '');
      const txt = (el.textContent || '').replace(/\s+/g, ' ').trim();
      out.push({ el: el, name: name, txt: txt, tier: tierOfCard(el) });
    }
    return out;
  }

  function harvestDom() {
    const cands = cardCandidates();
    let n = 0;
    for (const c of cands) {
      if (c.name && addPool(S.cls, c.name)) n++;
    }
    return n;
  }

  const DEF_PATHS = ['skills', 'skillDefs', 'upgrades', 'upgradeDefs', 'skillPool', 'pool',
                     'defs.skills', 'defs.upgrades', 'db.skills', 'data.skills'];

  function harvestObjects() {
    const g = S.game;
    if (!g) return 0;
    let n = 0;
    for (const path of DEF_PATHS) {
      let o = g;
      for (const seg of path.split('.')) { o = o && o[seg]; if (!o) break; }
      if (!o || typeof o !== 'object') continue;
      const arr = Array.isArray(o) ? o : Object.keys(o).map(function (k) { return o[k]; });
      if (arr.length > 800) continue;
      for (const it of arr) {
        if (!it) continue;
        if (typeof it === 'string') { if (addPool(S.cls, it)) n++; continue; }
        if (typeof it !== 'object') continue;
        const cands = [it.name, it.label, it.title, it.skillName];
        for (const c of cands) if (c && addPool(S.cls, c)) n++;
      }
    }
    return n;
  }

  function harvestAll() {
    const n = harvestObjects() + harvestDom();
    lastHarvestAt = Date.now();
    return n;
  }

  function chooseBestCard() {
    const list = entries();
    const cands = cardCandidates();
    if (!cands.length) return null;

    let best = null, bestScore = -Infinity;

    for (const c of cands) {
      const hay = (c.name || c.txt).toLowerCase();

      let rank = -1;
      for (let i = 0; i < list.length; i++) {
        if (hay.indexOf(list[i].n.toLowerCase()) >= 0) { rank = i; break; }
      }
      const rule = rank >= 0 ? list[rank].r : null;

      if (rank >= 0 ? !ruleAllowed(rule, c.tier) : !globalAllowed(c.tier)) continue;

      const t = c.tier < 0 ? 0 : c.tier;
      let score;
      if (S.best) {
        score = t * 1000 + (rank >= 0 ? (999 - rank) : 0);
      } else {
        if (rank < 0) continue;
        score = (9999 - rank * 100) + t;
      }
      if (score > bestScore) { bestScore = score; best = c; }
    }
    return best;
  }

  function tryPick() {
    const now = Date.now();
    if (now - lastPickAt < 400) return false;
    const best = chooseBestCard();
    if (!best) return false;
    if (best.txt === lastPickName && now - lastPickAt < 1200) return false;
    fireClick(best.el);
    lastPickAt = Date.now();
    lastPickName = best.txt;
    S.lastPick = best.name || best.txt;
    S.lastTier = best.tier;
    return true;
  }

  function autoPickTick() {
    if (Date.now() - lastHarvestAt > 900 && pickerOpen()) {
      if (harvestDom() && S.refreshSkills) S.refreshSkills();
    }
    if (!S.autoPick || !pickerOpen()) return;
    if (!S.best && !entries().length) return;
    try { tryPick(); } catch (e) {}
  }

  /* ============================================================
     8) 面板
     ============================================================ */
  const POS_KEY = 'rozaka.pos';
  const GHOST_KEY = 'rozaka.ghost';
  const UI_KEY = 'rozaka.ui';

  function boot() {
    if (document.getElementById('rozaka-panel')) return;
    loadStore();

    const css = document.createElement('style');
    css.textContent = [
      '#rozaka-panel{position:fixed;z-index:2147483646;width:214px;',
      'right:calc(14px + env(safe-area-inset-right,0px));',
      'bottom:calc(14px + env(safe-area-inset-bottom,0px));',
      'font:12px/1.5 -apple-system,"Segoe UI","Microsoft YaHei",sans-serif;color:#4b2636;',
      'background:linear-gradient(180deg,rgba(255,255,255,.98),rgba(255,244,248,.98));',
      'border:1px solid rgba(232,107,154,.38);border-radius:12px;',
      'box-shadow:0 10px 30px rgba(181,73,117,.22);backdrop-filter:blur(6px);',
      'user-select:none;-webkit-user-select:none;-webkit-tap-highlight-color:transparent;',
      'overscroll-behavior:contain;overflow:hidden;transition:opacity .12s}',
      '#rozaka-panel .rz-h{display:flex;align-items:center;gap:6px;',
      'padding:8px 10px;cursor:grab;touch-action:none;background:rgba(232,107,154,.16);',
      'font-weight:700;letter-spacing:.3px}',
      '#rozaka-panel .rz-h.dragging{cursor:grabbing}',
      '#rozaka-panel .rz-h .grip{opacity:.55;font-size:13px;line-height:1;letter-spacing:-1px}',
      '#rozaka-panel .rz-h .t{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
      '#rozaka-panel .rz-h span.d{width:8px;height:8px;border-radius:50%;background:#e96b9a;',
      'flex:0 0 auto;display:inline-block}',
      '#rozaka-panel .rz-h span.d.on{background:#43e08a;box-shadow:0 0 8px #43e08a}',
      '#rozaka-panel .rz-b{padding:8px 10px 10px}',
      '#rozaka-panel label{display:flex;align-items:center;justify-content:space-between;',
      'padding:4px 0;cursor:pointer;touch-action:manipulation}',
      '#rozaka-panel label input[type=checkbox][data-k]{-webkit-appearance:none;appearance:none;position:relative;width:42px;height:24px;flex:0 0 42px;margin:0 0 0 10px;border:1px solid rgba(232,107,154,.45);border-radius:999px;background:#f4dce5;cursor:pointer;transition:background .16s,border-color .16s,box-shadow .16s}',
      '#rozaka-panel label input[type=checkbox][data-k]::after{content:"";position:absolute;top:2px;left:2px;width:18px;height:18px;border-radius:50%;background:#fff;box-shadow:0 1px 4px rgba(110,38,70,.28);transition:transform .16s}',
      '#rozaka-panel label input[type=checkbox][data-k]:checked{background:#e96b9a;border-color:#d94f86;box-shadow:0 0 0 2px rgba(232,107,154,.12)}',
      '#rozaka-panel label input[type=checkbox][data-k]:checked::after{transform:translateX(18px)}',
      '#rozaka-panel .rz-op{display:flex;align-items:center;gap:8px;margin:2px 0 6px;',
      'padding-bottom:7px;border-bottom:1px solid rgba(120,160,255,.18)}',
      '#rozaka-panel .rz-op .k{color:#8a5c6d;flex:0 0 auto}',
      '#rozaka-panel .rz-op .v{width:34px;text-align:right;color:#a55f78;flex:0 0 auto;',
      'font-variant-numeric:tabular-nums}',
      '#rozaka-panel input[type=range]{-webkit-appearance:none;appearance:none;flex:1;',
      'height:22px;background:transparent;touch-action:none;margin:0}',
      '#rozaka-panel input[type=range]::-webkit-slider-runnable-track{height:6px;border-radius:3px;',
      'background:rgba(120,160,255,.28)}',
      '#rozaka-panel input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;',
      'width:18px;height:18px;margin-top:-6px;border-radius:50%;background:#f08bad;',
      'border:2px solid #fff0f5;box-shadow:0 0 7px rgba(232,107,154,.65)}',
      '#rozaka-panel input[type=range]::-moz-range-track{height:6px;border-radius:3px;',
      'background:rgba(120,160,255,.28)}',
      '#rozaka-panel input[type=range]::-moz-range-thumb{width:16px;height:16px;border-radius:50%;',
      'background:#f08bad;border:2px solid #fff0f5}',
      '#rozaka-panel .rz-g{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:8px}',
      '#rozaka-panel button{padding:6px 4px;border-radius:8px;border:1px solid rgba(232,107,154,.38);',
      'background:rgba(232,107,154,.16);color:#4b2636;font-size:11px;cursor:pointer;',
      'touch-action:manipulation}',
      '#rozaka-panel button:hover{background:rgba(232,107,154,.28)}',
      '#rozaka-panel button:active{background:rgba(232,107,154,.38)}',
      '#rozaka-panel button.wide{grid-column:1 / -1}',
      '#rozaka-panel .rz-s{margin-top:8px;padding-top:6px;border-top:1px solid rgba(120,160,255,.18);',
      'color:#8a5c6d;font-size:11px}',
      '#rozaka-panel .rz-t{margin-top:4px;color:#a47788;font-size:10px}',
      '#rozaka-panel.min .rz-b{display:none}',
      '#rozaka-panel .rz-sec{margin-top:8px;padding-top:7px;border-top:1px solid rgba(120,160,255,.18)}',
      '#rozaka-panel .rz-sec .hd{display:flex;align-items:center;gap:6px;',
      'color:#6f304d;font-weight:700;margin-bottom:5px;font-size:11px}',
      '#rozaka-panel .rz-sec .hd span.n{font-weight:400;color:#a47788;font-size:9px;flex:1;',
      'text-align:right}',
      '#rozaka-panel .rz-sec .hd button{padding:3px 7px;font-size:10px}',
      '#rozaka-panel select,#rozaka-panel .rz-add,#rozaka-panel .rz-num{width:100%;',
      'box-sizing:border-box;padding:5px 6px;border-radius:7px;',
      'border:1px solid rgba(232,107,154,.38);background:#fff7fa;color:#4b2636;font-size:11px;',
      'margin-bottom:5px;touch-action:manipulation;font-family:inherit}',
      '#rozaka-panel select:focus,#rozaka-panel .rz-add:focus,#rozaka-panel .rz-num:focus{',
      'outline:2px solid #e96b9a}',
      '#rozaka-panel .rz-num{-moz-appearance:textfield}',
      '#rozaka-panel .rz-num::-webkit-outer-spin-button,',
      '#rozaka-panel .rz-num::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}',
      '#rozaka-panel .rz-f2{display:grid;grid-template-columns:1fr 1fr;gap:5px}',
      '#rozaka-panel .rz-f2 .fl{display:flex;flex-direction:column;gap:2px}',
      '#rozaka-panel .rz-f2 .fl span{font-size:9px;color:#a47788}',
      '#rozaka-panel .rz-rar{display:flex;flex-wrap:wrap;gap:4px;margin:2px 0 6px}',
      '#rozaka-panel .rar{padding:2px 7px;border-radius:999px;font-size:10px;cursor:pointer;',
      'border:1px solid rgba(232,107,154,.38);background:rgba(120,140,180,.14);',
      'color:#93a4c4;opacity:.5;touch-action:manipulation;transition:opacity .1s}',
      '#rozaka-panel .rar.on{opacity:1;color:#0b1120;font-weight:700}',
      '#rozaka-panel .rar[data-r="legendary"].on{background:#ffb347;border-color:#ffb347}',
      '#rozaka-panel .rar[data-r="epic"].on{background:#c084fc;border-color:#c084fc}',
      '#rozaka-panel .rar[data-r="rare"].on{background:#60a5fa;border-color:#60a5fa}',
      '#rozaka-panel .rar[data-r="uncommon"].on{background:#4ade80;border-color:#4ade80}',
      '#rozaka-panel .rar[data-r="common"].on{background:#94a3b8;border-color:#94a3b8}',
      '#rozaka-panel .rz-chips{display:flex;flex-wrap:wrap;gap:4px;max-height:78px;',
      'overflow-y:auto;overscroll-behavior:contain;padding:1px 0}',
      '#rozaka-panel .chip{display:inline-flex;align-items:center;gap:4px;padding:2px 6px;',
      'border-radius:6px;background:rgba(232,107,154,.14);border:1px solid rgba(120,160,255,.4);',
      'font-size:10px;cursor:pointer;touch-action:manipulation}',
      '#rozaka-panel .chip.sel{background:rgba(90,130,255,.4);border-color:#7d9bff}',
      '#rozaka-panel .chip i{font-style:normal;color:#a55f78;font-size:9px;',
      'font-variant-numeric:tabular-nums}',
      '#rozaka-panel .chip u{text-decoration:none;color:#a55f78}',
      '#rozaka-panel .chip:hover u{color:#ff8a8a}',
      '#rozaka-panel .chip em{font-style:normal;font-size:9px;color:#a47788;letter-spacing:1px}',
      '#rozaka-panel .rz-rule{margin-top:6px;padding:7px;border-radius:9px;',
      'border:1px solid rgba(125,155,255,.5);background:rgba(90,130,255,.1)}',
      '#rozaka-panel .rz-rule.hidden{display:none}',
      '#rozaka-panel .rz-rule .rt{font-size:10px;color:#6f304d;margin-bottom:5px}',
      '#rozaka-panel .rz-rule .rt b{color:#fff}',
      '#rozaka-panel .rz-rule .rbs{display:flex;flex-wrap:wrap;gap:4px}',
      '#rozaka-panel .rz-rule .rb{padding:3px 8px;border-radius:8px;font-size:10px;',
      'border:1px solid rgba(232,107,154,.38);background:rgba(120,140,180,.14);',
      'color:#93a4c4;cursor:pointer;touch-action:manipulation}',
      '#rozaka-panel .rz-rule .rb.on{color:#0b1120;font-weight:700}',
      '#rozaka-panel .rz-rule .rb[data-t="4"].on{background:#ffb347;border-color:#ffb347}',
      '#rozaka-panel .rz-rule .rb[data-t="3"].on{background:#c084fc;border-color:#c084fc}',
      '#rozaka-panel .rz-rule .rb[data-t="2"].on{background:#60a5fa;border-color:#60a5fa}',
      '#rozaka-panel .rz-rule .rb[data-t="1"].on{background:#4ade80;border-color:#4ade80}',
      '#rozaka-panel .rz-rule .rb[data-t="0"].on{background:#94a3b8;border-color:#94a3b8}',
      '#rozaka-panel .rz-rule .rf{display:flex;gap:4px;margin-top:5px}',
      '#rozaka-panel .rz-rule .rf button{flex:1;font-size:10px;padding:4px}',
      '#rozaka-panel .rz-empty{color:#a47788;font-size:10px;padding:2px 0}',
      '#rozaka-panel .rz-row2{display:grid;grid-template-columns:1fr auto;gap:4px}',
      '#rozaka-panel .rz-row2 button{margin-bottom:5px}',
      '#rozaka-ghost{position:fixed;left:0;top:0;z-index:2147483647;display:none;',
      'width:38px;height:38px;border-radius:50%;box-sizing:border-box;',
      'align-items:center;justify-content:center;cursor:grab;touch-action:none;',
      'background:rgba(255,240,246,.96);border:2px solid rgba(232,107,154,.9);',
      'box-shadow:0 0 14px rgba(232,107,154,.5),0 4px 14px rgba(181,73,117,.25);',
      'opacity:.92;-webkit-tap-highlight-color:transparent;transition:opacity .12s,transform .12s}',
      '#rozaka-ghost.show{display:flex}',
      '#rozaka-ghost:hover{opacity:1}',
      '#rozaka-ghost:active{transform:scale(.94)}',
      '#rozaka-ghost span{width:14px;height:14px;border-radius:50%;background:#e96b9a;',
      'box-shadow:0 0 0 2px #fff,0 0 8px #e96b9a}',
      '#rozaka-ghost span.on{background:#43e08a;box-shadow:0 0 0 2px rgba(255,255,255,.9),0 0 10px #43e08a}',
      '@media (pointer:coarse), (max-width:720px){',
      '#rozaka-panel{width:236px;max-width:calc(100vw - 20px);font-size:13.5px}',
      '#rozaka-panel .rz-h{padding:12px 12px;font-size:13.5px}',
      '#rozaka-panel .rz-h .grip{font-size:16px}',
      '#rozaka-panel .rz-h span.d{width:10px;height:10px}',
      '#rozaka-panel .rz-b{padding:6px 12px 12px;max-height:calc(100vh - 110px);overflow-y:auto;',
      'overscroll-behavior:contain}',
      '#rozaka-panel label{min-height:38px;padding:5px 0}',
      '#rozaka-panel label input{width:20px;height:20px}',
      '#rozaka-panel input[type=range]{height:34px}',
      '#rozaka-panel input[type=range]::-webkit-slider-thumb{width:26px;height:26px;margin-top:-10px}',
      '#rozaka-panel .rz-op{padding-bottom:9px;margin-bottom:8px}',
      '#rozaka-panel button{min-height:44px;font-size:13px;border-radius:10px}',
      '#rozaka-panel label{min-height:42px}',
      '#rozaka-panel .rz-g{gap:8px}',
      '#rozaka-panel .rz-t{display:none}',
      '#rozaka-panel .rz-s{font-size:12px;line-height:1.6}',
      '#rozaka-panel select,#rozaka-panel .rz-add,#rozaka-panel .rz-num{min-height:40px;font-size:13px}',
      '#rozaka-panel .rz-sec .hd{font-size:13px}',
      '#rozaka-panel .rz-sec .hd button{min-height:34px;font-size:12px;padding:0 10px}',
      '#rozaka-panel .rz-rar{gap:6px}',
      '#rozaka-panel .rar{padding:7px 11px;font-size:12px}',
      '#rozaka-panel .rz-chips{max-height:104px;gap:6px}',
      '#rozaka-panel .chip{font-size:12px;padding:5px 9px;border-radius:8px}',
      '#rozaka-panel .rz-rule .rt{font-size:12px}',
      '#rozaka-panel .rz-rule .rb{padding:7px 11px;font-size:12px;border-radius:8px}',
      '#rozaka-panel .rz-rule .rf button{min-height:38px;font-size:12px}',
      '#rozaka-ghost{width:50px;height:50px}',
      '#rozaka-ghost span{width:18px;height:18px}',
      '}'
    ].join('');
    document.head.appendChild(css);

    const p = document.createElement('div');
    p.id = 'rozaka-panel';
    p.innerHTML = [
      '<div class="rz-h" title="拖曳移動 / 點擊收合"><span class="grip">⠿</span><span class="d"></span>',
      '<b class="t">ROs v3.0.0</b><span class="rz-c">▸</span></div>',
      '<div class="rz-b">',
      '  <div class="rz-op"><span class="k">透明度</span>',
      '    <input type="range" min="15" max="100" step="5" value="100" aria-label="面板透明度">',
      '    <span class="v">100%</span></div>',
      '  <label>無敵（不吃傷害）<input type="checkbox" data-k="god" checked></label>',
      '  <label>鎖血（永遠滿血）<input type="checkbox" data-k="hpLock"></label>',
      '  <label>秒殺 ×999<input type="checkbox" data-k="oneShot"></label>',
      '  <label>經驗 ×20<input type="checkbox" data-k="exp"></label>',
      '  <label>全屏拾取<input type="checkbox" data-k="pickup"></label>',
      '  <label>持續殲滅<input type="checkbox" data-k="annihilate"></label>',
      '  <label>9999% 尋寶率<input type="checkbox" data-k="findRate"></label>',
      '  <div class="rz-g">',
      '    <button data-a="pick" class="wide">立即全拾</button>',
      '    <button data-a="heal">回滿血</button>',
      '    <label>+200萬 Zeny<input type="checkbox" data-k="zenyBtn"></label>',
      '    <button data-a="lvl">升級 ×5</button>',
      '    <button data-a="annihilate">殲滅</button>',
      '    <button data-a="dim">半透明</button>',
      '    <button data-a="hide">隱藏</button>',
      '  </div>',
      '  <div class="rz-sec">',
      '    <div class="hd"><span>自動遠征</span></div>',
      '    <label>自動遠征<input type="checkbox" data-k="autoExp"></label>',
      '    <input class="rz-num rz-expstage" type="text" maxlength="24" placeholder="關卡名稱（留空＝不選關），Enter 新增">',
      '    <div class="rz-row2">',
      '      <select class="rz-expsel" aria-label="已存關卡"></select>',
      '      <span><button data-a="expAdd" title="新增輸入框的關卡">＋</button> <button data-a="expDel" title="刪除選取的關卡">✕</button></span>',
      '    </div>',
      '  </div>',
      '  <div class="rz-sec">',
      '    <div class="hd"><span>自動節慶</span></div>',
      '    <label>自動節慶<input type="checkbox" data-k="autoFest"></label>',
      '  </div>',
      '  <div class="rz-sec">',
      '    <div class="hd"><span>倍速</span><span class="n"></span></div>',
      '    <div class="rz-op"><span class="k">速度</span>',
      '      <input type="range" min="1" max="20" step="1" value="1" class="rz-sp" aria-label="倍速">',
      '      <span class="v rz-spv">1x</span></div>',
      '  </div>',
      '  <div class="rz-sec">',
      '    <div class="hd"><span>自動選技</span><span class="n"></span>',
      '      <button data-a="scan">掃描</button></div>',
      '    <label>啟用自動選技<input type="checkbox" data-k="autoPick"></label>',
      '    <label>自動選最佳等級<input type="checkbox" data-k="best"></label>',
      '    <div class="rz-rar"></div>',
      '    <select class="rz-cls" aria-label="職業"></select>',
      '    <div class="rz-row2">',
      '      <select class="rz-skill" aria-label="技能"></select>',
      '      <button data-a="addSkill" title="加入輸入框的名稱">＋</button>',
      '    </div>',
      '    <input class="rz-add" type="text" placeholder="技能名，Enter 加入" maxlength="24">',
      '    <div class="rz-chips"></div>',
      '    <div class="rz-rule hidden"></div>',
      '  </div>',
      '  <div class="rz-sec">',
      '    <div class="hd"><span>抽卡與診斷</span><span class="n"></span></div>',
      '    <div class="rz-f2">',
      '      <div class="fl"><span>抽卡次數</span>',
      '        <input class="rz-num" type="number" min="1" max="100" step="1" data-n="drawCount"></div>',
      '      <div class="fl"><span>診斷</span>',
      '        <label>記錄<input type="checkbox" data-k="diag"></label></div>',
      '    </div>',
      '    <div class="rz-g"><button data-a="diag" class="wide">複製診斷</button></div>',
      '  </div>',
      '  <div class="rz-s">狀態：等待開局…</div>',
      '  <div class="rz-t">F1 無敵 / F2 鎖血 / F3 秒殺 / F4 經驗<br>F5 回血 / F6 顯隱 / F7 半透明 / F8 全拾<br>F9 選技 / F10 尋寶 / F12 殲滅</div>',
      '</div>'
    ].join('');
    p.classList.add('min');
    document.body.appendChild(p);

    const ghost = document.createElement('div');
    ghost.id = 'rozaka-ghost';
    ghost.title = '點擊展開面板（可拖曳）';
    ghost.innerHTML = '<span></span>';
    document.body.appendChild(ghost);
    const ghostDot = ghost.querySelector('span');

    const head = p.querySelector('.rz-h');
    const dot = p.querySelector('.d');
    const caret = p.querySelector('.rz-c');
    const status = p.querySelector('.rz-s');
    const slider = p.querySelector('.rz-op input[type=range]');
    const sliderVal = p.querySelector('.rz-op .v');
    const spSlider = p.querySelector('.rz-sp');
    const spVal = p.querySelector('.rz-spv');
    const clsSel = p.querySelector('.rz-cls');
    const skillSel = p.querySelector('.rz-skill');
    const addInput = p.querySelector('.rz-add');
    const chipsBox = p.querySelector('.rz-chips');
    const ruleBox = p.querySelector('.rz-rule');
    const poolCount = p.querySelector('.rz-sec .hd .n');
    const rarBox = p.querySelector('.rz-rar');

    p.addEventListener('click', function (e) { e.stopPropagation(); });
    p.addEventListener('pointerdown', function (e) { e.stopPropagation(); });
    ghost.addEventListener('click', function (e) { e.stopPropagation(); });
    ghost.addEventListener('pointerdown', function (e) { e.stopPropagation(); });

    let editing = -1;

    RARITY_DEFS.forEach(function (d) {
      const b = document.createElement('span');
      b.className = 'rar' + (S.rarity[d.k] ? ' on' : '');
      b.dataset.r = d.k;
      b.textContent = d.label;
      b.title = '全域：點擊切換是否選此等級';
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        S.rarity[d.k] = !S.rarity[d.k];
        b.classList.toggle('on', S.rarity[d.k]);
        saveStore();
      });
      rarBox.appendChild(b);
    });

    function fillClasses() {
      clsSel.innerHTML = '';
      CLASSES.forEach(function (c) {
        const o = document.createElement('option');
        o.value = c;
        o.textContent = c;
        clsSel.appendChild(o);
      });
      const add = document.createElement('option');
      add.value = '__new__';
      add.textContent = '＋ 新增職業…';
      clsSel.appendChild(add);
      clsSel.value = S.cls;
    }

    function fillSkills() {
      const own = (builds[S.cls] || []).map(function (e) { return e.n; });
      const seen = {};
      skillSel.innerHTML = '';
      const head0 = document.createElement('option');
      head0.value = '';
      head0.textContent = poolUnion().length ? '選擇技能…' : '尚無資料，先按掃描';
      skillSel.appendChild(head0);

      poolUnion().concat(own).forEach(function (s) {
        if (seen[s]) return;
        seen[s] = 1;
        const o = document.createElement('option');
        o.value = s;
        o.textContent = s;
        skillSel.appendChild(o);
      });
      poolCount.textContent = '已擷取 ' + poolUnion().length;
    }

    S.refreshSkills = fillSkills;

    function ruleBadge(e) {
      const em = document.createElement('em');
      if (!e.r) { em.textContent = '默'; em.title = '跟隨全域'; return em; }
      if (!e.r.length) { em.textContent = '×'; em.title = '全關'; return em; }
      const sorted = e.r.slice().sort(function (a, b) { return b - a; });
      em.textContent = sorted.map(function (t) {
        const d = RARITY_DEFS.find(function (x) { return x.tier === t; });
        return d ? d.label.charAt(0) : '';
      }).join('');
      em.title = sorted.map(tierLabel).join('/');
      em.style.color = (RARITY_DEFS.find(function (x) { return x.tier === sorted[0]; }) || {}).color || '#6d80a6';
      return em;
    }

    function renderChips() {
      const list = builds[S.cls] || [];
      chipsBox.innerHTML = '';
      if (!list.length) {
        const e = document.createElement('div');
        e.className = 'rz-empty';
        e.textContent = '尚未設定，於上方選擇技能';
        chipsBox.appendChild(e);
        renderRule();
        return;
      }
      list.forEach(function (ent, i) {
        const c = document.createElement('span');
        c.className = 'chip' + (editing === i ? ' sel' : '');
        c.title = '點擊設定等級';
        const n = document.createElement('i');
        n.textContent = (i + 1) + '.';
        const b = document.createElement('b');
        b.textContent = ent.n;
        const x = document.createElement('u');
        x.textContent = '✕';
        x.title = '移除';
        c.appendChild(n);
        c.appendChild(b);
        c.appendChild(ruleBadge(ent));
        c.appendChild(x);
        c.addEventListener('click', function (e) {
          e.stopPropagation();
          if (e.target === x) { removeSkill(i); return; }
          editing = (editing === i) ? -1 : i;
          renderChips();
        });
        chipsBox.appendChild(c);
      });
      renderRule();
    }

    function renderRule() {
      const list = builds[S.cls] || [];
      if (editing < 0 || !list[editing]) {
        ruleBox.classList.add('hidden');
        ruleBox.innerHTML = '';
        return;
      }
      const ent = list[editing];
      ruleBox.classList.remove('hidden');
      ruleBox.innerHTML = '';

      const rt = document.createElement('div');
      rt.className = 'rt';
      rt.innerHTML = '第 ' + (editing + 1) + ' 項「<b></b>」可接受的等級';
      rt.querySelector('b').textContent = ent.n;
      ruleBox.appendChild(rt);

      const rbs = document.createElement('div');
      rbs.className = 'rbs';
      RARITY_DEFS.forEach(function (d) {
        const btn = document.createElement('span');
        const active = ent.r === null ? S.rarity[d.k] : ent.r.indexOf(d.tier) >= 0;
        btn.className = 'rb' + (active ? ' on' : '');
        btn.dataset.t = d.tier;
        btn.textContent = d.label;
        btn.addEventListener('click', function (e) {
          e.stopPropagation();
          if (ent.r === null) {
            ent.r = RARITY_DEFS.filter(function (x) { return S.rarity[x.k]; })
              .map(function (x) { return x.tier; });
          }
          const at = ent.r.indexOf(d.tier);
          if (at >= 0) ent.r.splice(at, 1); else ent.r.push(d.tier);
          saveStore();
          renderChips();
        });
        rbs.appendChild(btn);
      });
      ruleBox.appendChild(rbs);

      const rf = document.createElement('div');
      rf.className = 'rf';

      const bAll = document.createElement('button');
      bAll.textContent = '全部';
      bAll.addEventListener('click', function (e) {
        e.stopPropagation();
        ent.r = [0, 1, 2, 3, 4];
        saveStore();
        renderChips();
      });
      rf.appendChild(bAll);

      const bDef = document.createElement('button');
      bDef.textContent = '跟隨全域';
      bDef.addEventListener('click', function (e) {
        e.stopPropagation();
        ent.r = null;
        saveStore();
        renderChips();
      });
      rf.appendChild(bDef);

      const bDone = document.createElement('button');
      bDone.textContent = '完成';
      bDone.addEventListener('click', function (e) {
        e.stopPropagation();
        editing = -1;
        renderChips();
      });
      rf.appendChild(bDone);

      ruleBox.appendChild(rf);
    }

    function addSkill(name) {
      name = cleanName(name);
      if (!name) return;
      if (!builds[S.cls]) builds[S.cls] = [];
      if (builds[S.cls].some(function (e) { return e.n === name; })) return;
      builds[S.cls].push({ n: name, r: null });
      addPool(S.cls, name);
      saveStore();
      fillSkills();
      renderChips();
    }

    function removeSkill(i) {
      const list = builds[S.cls];
      if (!list) return;
      list.splice(i, 1);
      if (editing >= list.length) editing = list.length - 1;
      saveStore();
      fillSkills();
      renderChips();
    }

    clsSel.addEventListener('change', function () {
      editing = -1;
      if (clsSel.value === '__new__') {
        const name = cleanName(window.prompt('新職業名稱：') || '');
        clsSel.value = S.cls;
        if (!name) return;
        if (CLASSES.indexOf(name) < 0) { CLASSES.push(name); saveClasses(); }
        S.cls = name;
        saveStore();
        fillClasses();
      } else {
        S.cls = clsSel.value;
        saveStore();
      }
      fillSkills();
      renderChips();
    });

    skillSel.addEventListener('change', function () {
      if (skillSel.value) addSkill(skillSel.value);
      skillSel.value = '';
    });

    addInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); addSkill(addInput.value); addInput.value = ''; }
      e.stopPropagation();
    });


    fillClasses();
    fillSkills();
    renderChips();

    function applyOpacity() {
      const v = Math.max(15, Math.min(100, Math.round(S.opacity) || 100));
      S.opacity = v;
      slider.value = v;
      sliderVal.textContent = v + '%';
      p.style.opacity = (v / 100).toFixed(2);
    }

    slider.addEventListener('input', function () {
      S.opacity = parseInt(slider.value, 10) || 100;
      sliderVal.textContent = S.opacity + '%';
      if (!S.hidden) p.style.opacity = (S.opacity / 100).toFixed(2);
    });
    slider.addEventListener('change', function () { applyOpacity(); saveUI(); });

    function applySpeed() {
      const v = Math.max(1, Math.min(20, Math.round(S.speed) || 1));
      S.speed = v;
      spSlider.value = v;
      spVal.textContent = v + 'x';
    }

    spSlider.addEventListener('input', function () {
      S.speed = parseInt(spSlider.value, 10) || 1;
      spVal.textContent = S.speed + 'x';
    });
    spSlider.addEventListener('change', function () { applySpeed(); saveCheat(); });

    p.querySelectorAll('input[data-n]').forEach(function (el) {
      const key = el.getAttribute('data-n');
      el.value = S[key];
      el.addEventListener('input', function () {
        const v = parseInt(el.value, 10);
        if (isNaN(v)) return;
        if (key === 'drawCount') S.drawCount = Math.max(1, Math.min(100, v));
        saveCheat();
      });
      el.addEventListener('keydown', function (e) { e.stopPropagation(); });
    });

    function clampTo(el, x, y) {
      const w = el.offsetWidth || 40, h = el.offsetHeight || 40;
      return {
        x: Math.max(4, Math.min(Math.max(4, window.innerWidth - w - 4), x)),
        y: Math.max(4, Math.min(Math.max(4, window.innerHeight - h - 4), y))
      };
    }

    function savePos() {
      try {
        localStorage.setItem(POS_KEY, JSON.stringify({
          l: parseInt(p.style.left, 10) || 0,
          t: parseInt(p.style.top, 10) || 0
        }));
      } catch (e) {}
    }

    function saveGhostPos() {
      try {
        localStorage.setItem(GHOST_KEY, JSON.stringify({
          l: parseInt(ghost.style.left, 10) || 0,
          t: parseInt(ghost.style.top, 10) || 0
        }));
      } catch (e) {}
    }

    function saveUI() {
      try {
        localStorage.setItem(UI_KEY, JSON.stringify({ o: S.opacity, h: S.hidden }));
      } catch (e) {}
    }

    function syncUI() {
      ghost.classList.toggle('show', !!S.hidden);
      p.style.display = S.hidden ? 'none' : '';
      if (S.hidden) {
        p.classList.remove('min');
        caret.textContent = '▾';
      } else {
        applyOpacity();
      }
    }

    function doHide() {
      if (S.hidden) return;
      const r = p.getBoundingClientRect();
      const c = clampTo(ghost, r.left, r.top);
      ghost.style.left = c.x + 'px';
      ghost.style.top = c.y + 'px';
      S.hidden = true;
      syncUI();
      saveUI();
      saveGhostPos();
    }

    function doShow() {
      if (!S.hidden) return;
      S.hidden = false;
      const gx = parseFloat(ghost.style.left);
      const gy = parseFloat(ghost.style.top);
      syncUI();
      if (!isNaN(gx) && !isNaN(gy)) {
        const c = clampTo(p, gx, gy);
        p.style.left = c.x + 'px';
        p.style.top = c.y + 'px';
        p.style.right = 'auto';
        p.style.bottom = 'auto';
        savePos();
      }
      saveUI();
    }

    function toggleHidden() { S.hidden ? doShow() : doHide(); }

    function toggleDim() {
      S.opacity = (S.opacity <= 40) ? 100 : 35;
      applyOpacity();
      saveUI();
    }

    function toggleFind() {
      S.findRate = !S.findRate;
      if (S.findRate) findRateOn(); else findRateOff();
      saveCheat();
      syncBoxes();
      diagPush('[FIND]', S.findRate ? 'on extra=' + S.findExtra : 'off');
    }


    function makeDraggable(el, onTap, store) {
      let d = null;
      let tapped = false;
      el.addEventListener('pointerdown', function (e) {
        if (e.pointerType === 'mouse' && e.button !== 0) return;
        const r = el.getBoundingClientRect();
        d = { id: e.pointerId, dx: e.clientX - r.left, dy: e.clientY - r.top,
              sx: e.clientX, sy: e.clientY, moved: false };
        el.style.left = r.left + 'px';
        el.style.top = r.top + 'px';
        el.style.right = 'auto';
        el.style.bottom = 'auto';
        el.classList.add('dragging');
        try { el.setPointerCapture(e.pointerId); } catch (err) {}
        if (e.pointerType === 'mouse') e.preventDefault();
      });
      el.addEventListener('pointermove', function (e) {
        if (!d || e.pointerId !== d.id) return;
        if (!d.moved) {
          if (Math.abs(e.clientX - d.sx) + Math.abs(e.clientY - d.sy) < 5) return;
          d.moved = true;
        }
        const c = clampTo(el, e.clientX - d.dx, e.clientY - d.dy);
        el.style.left = c.x + 'px';
        el.style.top = c.y + 'px';
      });
      function end(e) {
        if (!d || (e && e.pointerId !== d.id)) return;
        const moved = d.moved;
        try { el.releasePointerCapture(d.id); } catch (err) {}
        el.classList.remove('dragging');
        d = null;
        if (moved) {
          tapped = true;
          setTimeout(function () { tapped = false; }, 0);
          store();
        }
      }
      el.addEventListener('pointerup', end);
      el.addEventListener('pointercancel', end);
      el.addEventListener('click', function (e) {
        if (tapped) return;
        onTap(e);
      });
    }

    try {
      const sp = JSON.parse(localStorage.getItem(POS_KEY) || 'null');
      if (sp && typeof sp.l === 'number' && typeof sp.t === 'number') {
        const c = clampTo(p, sp.l, sp.t);
        p.style.left = c.x + 'px';
        p.style.top = c.y + 'px';
        p.style.right = 'auto';
        p.style.bottom = 'auto';
      }
      const sg = JSON.parse(localStorage.getItem(GHOST_KEY) || 'null');
      if (sg && typeof sg.l === 'number' && typeof sg.t === 'number') {
        const c = clampTo(ghost, sg.l, sg.t);
        ghost.style.left = c.x + 'px';
        ghost.style.top = c.y + 'px';
      }
    } catch (e) {}

    makeDraggable(head, function () {
      p.classList.toggle('min');
      caret.textContent = p.classList.contains('min') ? '▸' : '▾';
    }, savePos);

    makeDraggable(ghost, doShow, saveGhostPos);

    window.addEventListener('resize', function () {
      if (p.style.left) {
        const c = clampTo(p, parseInt(p.style.left, 10) || 0, parseInt(p.style.top, 10) || 0);
        p.style.left = c.x + 'px';
        p.style.top = c.y + 'px';
      }
      if (ghost.style.left) {
        const c = clampTo(ghost, parseInt(ghost.style.left, 10) || 0, parseInt(ghost.style.top, 10) || 0);
        ghost.style.left = c.x + 'px';
        ghost.style.top = c.y + 'px';
      }
    });

    p.querySelectorAll('input[data-k]').forEach(function (el) {
      el.addEventListener('change', function () {
        const k = el.getAttribute('data-k');
        if (k === 'pickup') setPickup(el.checked);
        else if (k === 'zenyBtn') {
          S.zenyBtn = el.checked;
          if (el.checked) act('zeny');
        }
        else if (k === 'findRate') {
          S.findRate = el.checked;
          if (S.findRate) findRateOn(); else findRateOff();
          saveCheat();
          diagPush('[FIND]', S.findRate ? 'on extra=' + S.findExtra : 'off');
        } else {
          S[k] = el.checked;
          if (k === 'autoExp' || k === 'autoFest') {
            if (el.checked) { if (k === 'autoExp') S.autoFest = false; else S.autoExp = false; }
            saveExp();
          }
          if (k === 'diag') saveCheat();
        }
        syncBoxes();
      });
    });

    function syncBoxes() {
      p.querySelectorAll('input[data-k]').forEach(function (el) {
        el.checked = !!S[el.getAttribute('data-k')];
      });
    }

    function act(name) {
      if (name === 'dim') { toggleDim(); return; }
      if (name === 'hide') { doHide(); return; }
      if (name === 'pick') { collectAll(); return; }
      if (name === 'expAdd') { expAddStage(); return; }
      if (name === 'expDel') { expDelStage(); return; }
      if (name === 'addSkill') { addSkill(addInput.value); addInput.value = ''; return; }
      if (name === 'diag') {
        copyDiag(function (msg) { status.textContent = msg; });
        return;
      }
      if (name === 'scan') {
        const n = harvestAll();
        saveStore();
        fillSkills();
        status.textContent = n
          ? '掃描完成，新增 ' + n + ' 個名稱'
          : '掃描完成，沒發現新名稱（等升級卡片出現時再掃）';
        return;
      }
      const g = S.game;
      if (!g) return;
      try {
        if (name === 'heal') {
          g.hp = g.stats.maxHp;
          if (g.player) g.player.dead = false;
        } else if (name === 'zeny') {
          g.zeny = (g.zeny || 0) + 2000000;
        } else if (name === 'lvl') {
          for (let i = 0; i < 5; i++) g.gainExp(g.expNext * 1.02);
        } else if (name === 'annihilate') {
          annihilateEnemies();
        }
      } catch (err) {}
    }

    p.querySelectorAll('button[data-a]').forEach(function (b) {
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        act(b.getAttribute('data-a'));
      });
    });

    window.addEventListener('keydown', function (e) {
      const t = e.target;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' ||
                t.isContentEditable)) return;
      const k = e.key;
      if (k === 'F1') { S.god = !S.god; e.preventDefault(); }
      else if (k === 'F2') { S.hpLock = !S.hpLock; e.preventDefault(); }
      else if (k === 'F3') { S.oneShot = !S.oneShot; e.preventDefault(); }
      else if (k === 'F4') { S.exp = !S.exp; e.preventDefault(); }
      else if (k === 'F5') { act('heal'); e.preventDefault(); }
      else if (k === 'F6') { toggleHidden(); e.preventDefault(); }
      else if (k === 'F7') { toggleDim(); e.preventDefault(); }
      else if (k === 'F8') { setPickup(!S.pickup); e.preventDefault(); }
      else if (k === 'F9') { S.autoPick = !S.autoPick; e.preventDefault(); }
      else if (k === 'F10') { toggleFind(); e.preventDefault(); }
      else if (k === 'F12') { S.annihilate = !S.annihilate; e.preventDefault(); }
      else return;
      syncBoxes();
    }, true);

    try {
      const ui = JSON.parse(localStorage.getItem(UI_KEY) || 'null');
      if (ui) {
        if (typeof ui.o === 'number') S.opacity = ui.o;
        S.hidden = !!ui.h;
      }
    } catch (e) {}
    applySpeed();
    syncUI();
    syncBoxes();
    if (S.findRate) findRateOn();

    /* ===== 自動遠征：隊長 → 遠征 → 選關 → 出發（依畫面文字比對） ===== */
    const expInput = p.querySelector('.rz-expstage');
    const expSel = p.querySelector('.rz-expsel');
    let expList = [];
    function saveExp() {
      try {
        localStorage.setItem('rozaka.exp', JSON.stringify({ on: S.autoExp, fest: S.autoFest, st: S.expStage, list: expList }));
      } catch (e) {}
    }
    function renderExpList() {
      expSel.innerHTML = '';
      const o0 = document.createElement('option');
      o0.value = '';
      o0.textContent = expList.length ? '已存關卡（' + expList.length + '）' : '尚無已存關卡';
      expSel.appendChild(o0);
      expList.forEach(function (n) {
        const o = document.createElement('option');
        o.value = n;
        o.textContent = n;
        if (n === S.expStage) o.selected = true;
        expSel.appendChild(o);
      });
    }
    function expAddStage() {
      const n = expInput.value.trim();
      if (!n) return;
      S.expStage = n;
      if (expList.indexOf(n) < 0) { expList.push(n); if (expList.length > 30) expList.shift(); }
      saveExp();
      renderExpList();
    }
    function expDelStage() {
      const n = expSel.value;
      if (!n) return;
      expList = expList.filter(function (x) { return x !== n; });
      saveExp();
      renderExpList();
    }
    try {
      const ex = JSON.parse(localStorage.getItem('rozaka.exp') || 'null');
      if (ex) {
        S.autoExp = !!ex.on;
        S.autoFest = !S.autoExp && !!ex.fest;
        S.expStage = String(ex.st || '');
        if (Array.isArray(ex.list)) {
          expList = ex.list.filter(function (x) { return typeof x === 'string' && x; }).slice(0, 30);
        }
      }
    } catch (e) {}
    expInput.value = S.expStage;
    renderExpList();
    expSel.addEventListener('change', function () {
      if (!expSel.value) return;
      expInput.value = expSel.value;
      S.expStage = expSel.value;
      saveExp();
    });
    syncBoxes();
    ['keydown', 'keyup', 'keypress'].forEach(function (t) {
      expInput.addEventListener(t, function (e) {
        e.stopPropagation();
        if (t === 'keydown' && e.key === 'Enter') expAddStage();
      });
    });
    expInput.addEventListener('input', function () {
      S.expStage = expInput.value.trim();
      saveExp();
    });

    function expVisible(el) {
      const r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return false;
      const cs = getComputedStyle(el);
      return cs.visibility !== 'hidden' && cs.display !== 'none' && parseFloat(cs.opacity) !== 0;
    }
    function expFind(test) {
      const all = document.body.querySelectorAll('*');
      let hit = null;
      for (let i = 0; i < all.length; i++) {
        const el = all[i];
        if (p.contains(el) || ghost.contains(el)) continue;
        const tag = el.tagName;
        if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'CANVAS') continue;
        const t = (el.textContent || '').trim();
        if (!t || t.length > 40 || !test(t)) continue;
        let childHit = false;
        for (let j = 0; j < el.children.length; j++) {
          if (test((el.children[j].textContent || '').trim())) { childHit = true; break; }
        }
        if (childHit) continue;
        if (!expVisible(el)) continue;
        hit = el;
        break;
      }
      return hit;
    }
    function expClick(el) {
      const target = el.closest('button,a,[role=button],[onclick]') || el;
      try { target.click(); } catch (e) {}
    }
    let expStagePicked = false;
    let expState = 'lobby';
    let expPrevOn = false;
    let expPrevMode = '';
    let expArrived = false;
    let expNpcEl = null;
    let expNpcName = '';
    let expNpcAt = 0;
    const expHeld = {};
    const EXP_KEYS = {
      ArrowUp: ['ArrowUp', 38], ArrowDown: ['ArrowDown', 40],
      ArrowLeft: ['ArrowLeft', 37], ArrowRight: ['ArrowRight', 39],
      KeyW: ['w', 87], KeyS: ['s', 83], KeyA: ['a', 65], KeyD: ['d', 68]
    };
    function expKeyEvent(type, code) {
      const t = document.querySelector('canvas') || document.body;
      const d = EXP_KEYS[code];
      try {
        t.dispatchEvent(new KeyboardEvent(type, {
          key: d[0], code: code, keyCode: d[1], which: d[1], bubbles: true, cancelable: true
        }));
      } catch (e) {}
    }
    function expSetKeys(want) {
      Object.keys(EXP_KEYS).forEach(function (code) {
        const on = want.indexOf(code) >= 0;
        if (on) { expKeyEvent('keydown', code); expHeld[code] = true; }
        else if (expHeld[code]) { expKeyEvent('keyup', code); expHeld[code] = false; }
      });
    }
    function expPromptBtn(re) {
      const els = document.querySelectorAll('button,[role=button],a');
      for (let i = 0; i < els.length; i++) {
        const el = els[i];
        if (p.contains(el)) continue;
        const t = (el.textContent || '').trim();
        if (t.length < 40 && re.test(t) && expVisible(el)) return el;
      }
      return null;
    }
    function expWalkLoop() {
      const mode = S.autoExp ? 'exp' : (S.autoFest ? 'fest' : '');
      if (!mode || expState !== 'lobby') { expArrived = false; expSetKeys([]); return; }
      if (mode === 'fest') {
        const pr = expPromptBtn(/與.*(主持人|節慶).*交談/);
        if (pr) { expArrived = true; expSetKeys([]); return; }
        expArrived = false;
        expSetKeys(['ArrowRight', 'KeyD']);
        return;
      }
      const name = '遠征隊長';
      const now = Date.now();
      if (expNpcName !== name || !expNpcEl || !expNpcEl.isConnected || now - expNpcAt > 1500) {
        expNpcName = name;
        expNpcAt = now;
        expNpcEl = expFind(function (t) { return t === name; });
      }
      if (!expNpcEl) { expArrived = false; expSetKeys([]); return; }
      const r = expNpcEl.getBoundingClientRect();
      const cv = document.querySelector('canvas');
      const cr = cv ? cv.getBoundingClientRect() : { left: 0, top: 0, width: innerWidth, height: innerHeight };
      const px = cr.left + cr.width / 2;
      const py = cr.top + cr.height / 2;
      const tx = r.left + r.width / 2;
      const ty = r.top + r.height + 60;
      const dx = tx - px;
      const dy = ty - py;
      if (Math.abs(dx) < 90 && Math.abs(dy) < 90) { expArrived = true; expSetKeys([]); return; }
      expArrived = false;
      const want = [];
      if (dx > 45) want.push('ArrowRight', 'KeyD');
      else if (dx < -45) want.push('ArrowLeft', 'KeyA');
      if (dy > 45) want.push('ArrowDown', 'KeyS');
      else if (dy < -45) want.push('ArrowUp', 'KeyW');
      expSetKeys(want);
    }
    let expLastAct = 0;
    let expZenyAt = 0;
    function expPressSpace() {
      const t = document.querySelector('canvas') || document.body;
      const mk = function (type) {
        return new KeyboardEvent(type, {
          key: ' ', code: 'Space', keyCode: 32, which: 32, bubbles: true, cancelable: true
        });
      };
      try { t.dispatchEvent(mk('keydown')); } catch (e) {}
      setTimeout(function () { try { t.dispatchEvent(mk('keyup')); } catch (e) {} }, 80);
    }
    function expTick() {
      if ((!S.autoExp && !S.autoFest) || !document.body) { expPrevOn = false; expPrevMode = ''; expSetKeys([]); return; }
      const mode = S.autoExp ? 'exp' : 'fest';
      if (!expPrevOn || expPrevMode !== mode) { expPrevOn = true; expPrevMode = mode; expState = 'lobby'; expZenyAt = 0; }
      const now = Date.now();
      if (expZenyAt && now >= expZenyAt && S.game) {
        expZenyAt = 0;
        S.zenyBtn = true;
        try { act('zeny'); } catch (e) {}
        syncBoxes();
      }
      if (now - expLastAct < 700) return;
      const kw = S.expStage;
      const back = expFind(function (t) {
        return mode === 'exp' ? /返回角色/.test(t) : /返回/.test(t);
      });
      if (back) { expClick(back); expStagePicked = false; expState = 'lobby'; expZenyAt = 0; expLastAct = now; return; }
      const field = expFind(function (t) { return /前往野外/.test(t); });
      if (field) {
        expClick(field); expStagePicked = false; expState = 'field'; expSetKeys([]);
        if (mode === 'exp') expZenyAt = now + 2500;
        expLastAct = now;
        return;
      }
      if (mode === 'exp') {
        if (kw && !expStagePicked) {
          const st = expFind(function (t) { return t.indexOf(kw) >= 0; });
          if (st) { expClick(st); expStagePicked = true; expLastAct = now; return; }
        }
        const go = expFind(function (t) { return /出發|出发/.test(t); });
        if (go) { expClick(go); expStagePicked = false; expLastAct = now; return; }
        expStagePicked = false;
        const ex = expFind(function (t) { return /遠征|远征/.test(t) && !/隊長|队长/.test(t); });
        if (ex) { expClick(ex); expLastAct = now; return; }
      } else {
        const st = expFind(function (t) { return /開始遊戲|开始游戏/.test(t); });
        if (st) { expClick(st); expLastAct = now; return; }
      }
      const lobby = expFind(function (t) { return /單人大廳|单人大厅/.test(t); });
      if (lobby) { expClick(lobby); expState = 'lobby'; expLastAct = now; return; }
      if (expState === 'lobby') {
        const npcRe = mode === 'exp' ? /與.*隊長.*交談/ : /與.*(主持人|節慶).*交談/;
        const pr = expFind(function (t) { return npcRe.test(t); });
        if (pr) { expSetKeys([]); expClick(pr); expLastAct = now + 800; return; }
        if (expArrived) { expSetKeys([]); expPressSpace(); expLastAct = now + 800; }
      }
    }
    setInterval(function () { try { expTick(); } catch (e) {} }, 800);
    setInterval(function () { try { expWalkLoop(); } catch (e) {} }, 150);

    setInterval(function () {
      if (S.annihilate && S.game) { try { annihilateEnemies(); } catch (e) {} }
      if (S.pickup && S.game) { try { collectAll(); } catch (e) {} }
      autoPickTick();

      const g = S.game;
      const live = !!(g && g.stats);
      dot.classList.toggle('on', live);
      ghostDot.classList.toggle('on', live);

      if (!live) {
        status.textContent = '狀態：等待開局（進遊戲自動作業）';
        return;
      }
      const alive = g.enemies ? g.enemies.filter(function (e) { return e && !e.dead; }).length : 0;
      let txt = 'Lv ' + (g.level || 1) +
        ' · HP ' + Math.round(g.hp) + '/' + Math.round(g.stats.maxHp) +
        ' · 敵人 ' + alive +
        ' · 拾取 ' + (Array.isArray(g.pickups) ? g.pickups.length : 0) +
        ' · Zeny ' + Math.round(g.zeny || 0);
      if (S.speed > 1) txt += ' · ' + S.speed + 'x';
      if (S.findRate) txt += ' · 尋寶';
      if (S.autoPick) {
        const pr = entries();
        const rOn = RARITY_DEFS.filter(function (d) { return S.rarity[d.k]; })
          .map(function (d) { return d.label; }).join('/');
        txt += ' · ' + (S.best ? '選最高等' : '選技 ' + (pr.length ? '待' + pr[0].n : '未設定')) +
               ' · 限 ' + (rOn || '全部');
        if (pickerOpen()) txt += ' · 選卡中';
      }
      status.textContent = txt;
    }, 200);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
