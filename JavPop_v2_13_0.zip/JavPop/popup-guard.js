// 在頁面本身的 JS 環境執行：廣告阻擋開啟時攔截 window.open 彈出視窗
(() => {
  const nativeOpen = window.open;
  window.open = function (...args) {
    if (document.documentElement?.dataset.jpAdblock === '1') return null;
    return nativeOpen.apply(this, args);
  };
})();
