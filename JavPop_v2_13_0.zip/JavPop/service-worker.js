const DEFAULT_SETTINGS = {
  enabled: false, // 預設不開啟
  allTabs: true,
  pageKeywords: [],
  linkKeywords: [],
  delayMs: 500,
  clickOnce: true,
  scanOncePerPage: true,
  caseSensitive: false,
  onlyOpenedTabs: false, // 只在「批次開啟」自動開出的分頁執行關鍵字點擊
  targetTabId: null,
  mediaKeywordEnabled: false,
  mediaKeywordPageKeywords: [],
  mediaKeywordLinkKeywords: [],
  mediaKeywordDelayMs: 500,
  mediaKeywordCaseSensitive: false,
  mediaKeywordClickOnce: true,
  mediaKeywordOnlyOpenedTabs: false,
  triggerOnce: true, // 同一個網址只觸發一次（關鍵字點擊）
  mediaKeywordTriggerOnce: true // 同一個網址只觸發一次（影片流程）
};

const openedKey = (tabId) => `opened:${tabId}`; // 由批次開啟功能建立的分頁
const openerKey = (tabId) => `opener:${tabId}`; // 目前正在執行批次開啟的列表頁
const mediaFollowupKey = (tabId) => `media-followup:${tabId}`;
const BUILD = '2.13.0-claim-first'; // 必須與 popup.js 的 BUILD 相同；不同代表檔案版本混用
const switchOnceKey = (tabId) => `switch-once:${tabId}`; // 該分頁目前這個頁面已處理過「切換過來」的複製
const copiedKey = (tabId) => `autocopied:${tabId}`; // 該分頁已自動複製過影片連結（存在 session，背景程式被回收也不會遺失）

const OPENER_DEFAULTS = { openerSelector: 'a:has(img)', openerDelay: 1500, openerMax: 20 };

// 全域徽章：關鍵字自動點擊開啟時顯示 KW
async function syncBadge() {
  const { enabled } = await chrome.storage.local.get({ enabled: DEFAULT_SETTINGS.enabled });
  await chrome.action.setBadgeBackgroundColor({ color: '#596fff' });
  await chrome.action.setBadgeText({ text: enabled ? 'KW' : '' });
}

// ---- 廣告阻擋 ----
const AD_TYPES = ['script', 'sub_frame', 'image', 'stylesheet', 'xmlhttprequest', 'ping', 'media', 'font', 'other', 'object', 'websocket'];
const DOMAIN_RE = /^[a-z0-9-]+(\.[a-z0-9-]+)+$/;
const cleanDomains = (list) => [...new Set((list || [])
  .map((d) => String(d).trim().toLowerCase().replace(/^[a-z]+:\/\//, '').replace(/^\*?\.?/, '').split(/[\/?#:]/)[0])
  .filter((d) => DOMAIN_RE.test(d)))];

async function applyAdblock() {
  const s = await chrome.storage.local.get({ adblockEnabled: false, adblockCustom: [], adblockAllow: [] });
  await chrome.declarativeNetRequest.updateEnabledRulesets(
    s.adblockEnabled ? { enableRulesetIds: ['ads'] } : { disableRulesetIds: ['ads'] });

  const rules = [];
  let id = 1;
  const custom = cleanDomains(s.adblockCustom);
  if (s.adblockEnabled && custom.length) {
    rules.push({ id: id++, priority: 1, action: { type: 'block' },
      condition: { requestDomains: custom, resourceTypes: AD_TYPES } });
  }
  for (const d of cleanDomains(s.adblockAllow)) {
    rules.push({ id: id++, priority: 2, action: { type: 'allowAllRequests' },
      condition: { requestDomains: [d], resourceTypes: ['main_frame', 'sub_frame'] } });
  }
  const old = await chrome.declarativeNetRequest.getDynamicRules();
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: old.map((r) => r.id),
    addRules: rules
  });
}

// YouTube 廣告阻擋的網路層規則：只有「阻擋 YouTube 廣告」與「攔截廣告網路請求」同時開啟才啟用
const YT_MAIN_ID = 'jp-yt-main';
async function applyYoutube() {
  const s = await chrome.storage.local.get({ ytAdblock: false, ytNetwork: false });
  await chrome.declarativeNetRequest.updateEnabledRulesets(
    s.ytAdblock && s.ytNetwork ? { enableRulesetIds: ['yt'] } : { disableRulesetIds: ['yt'] });
  // 頁面環境腳本（移除播放器資料裡的廣告欄位）只在開啟時才註冊：
  // 它必須在 YouTube 自己的腳本之前執行，無法等 chrome.storage 的非同步讀取，所以用「註冊與否」代替開關
  const reg = await chrome.scripting.getRegisteredContentScripts({ ids: [YT_MAIN_ID] }).catch(() => []);
  if (s.ytAdblock && !reg.length) {
    await chrome.scripting.registerContentScripts([{
      id: YT_MAIN_ID, js: ['yt-adblock-main.js'], matches: ['*://*.youtube.com/*', '*://*.youtube-nocookie.com/*'],
      runAt: 'document_start', allFrames: true, world: 'MAIN', persistAcrossSessions: true
    }]).catch(() => {});
  } else if (!s.ytAdblock && reg.length) {
    await chrome.scripting.unregisterContentScripts({ ids: [YT_MAIN_ID] }).catch(() => {});
  }
}
chrome.runtime.onStartup.addListener(applyYoutube);

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && (changes.ytAdblock || changes.ytNetwork)) applyYoutube();
  if (area === 'local' && (changes.adblockEnabled || changes.adblockCustom || changes.adblockAllow)) applyAdblock();
});

chrome.runtime.onInstalled.addListener(async () => {
  applyAdblock();
  applyYoutube();
  const current = await chrome.storage.local.get(DEFAULT_SETTINGS);
  await chrome.storage.local.set({ ...DEFAULT_SETTINGS, ...current });
  syncBadge();
});
chrome.runtime.onStartup.addListener(syncBadge);
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.enabled) syncBadge();
});

async function broadcastSettings() {
  const settings = await chrome.storage.local.get(DEFAULT_SETTINGS);
  const tabs = await chrome.tabs.query({});
  await Promise.all(tabs
    .filter((t) => settings.allTabs || settings.targetTabId == null || settings.targetTabId === t.id)
    .map((t) => chrome.tabs.sendMessage(t.id, { type: 'settings-updated', settings }).catch(() => {})));
}

// ---- 快捷鍵 ----
chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'run-opener') {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;
    const cfg = await chrome.storage.local.get(OPENER_DEFAULTS);
    try {
      const r = await chrome.tabs.sendMessage(tab.id, {
        type: 'opener-toggle',
        selector: cfg.openerSelector,
        delay: cfg.openerDelay,
        max: cfg.openerMax
      });
      if (r?.stopped) {
        await chrome.action.setBadgeText({ tabId: tab.id, text: '' });
      } else if (r?.ok) {
        await chrome.action.setBadgeBackgroundColor({ tabId: tab.id, color: '#2e9c69' });
        await chrome.action.setBadgeText({ tabId: tab.id, text: '▶' });
      } else {
        await flashBadge(tab.id, '無');
      }
    } catch {
      await flashBadge(tab.id, '!'); // 非 javpop 頁面或需重新整理
    }
  }

  if (command === 'toggle-picker') {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;
    try { await chrome.tabs.sendMessage(tab.id, { type: 'picker-toggle' }); }
    catch { await flashBadge(tab.id, '!'); } // 內建頁面不支援，或需重新整理頁面
  }

  if (command === 'toggle-keyword') await toggleKeyword();
  if (command === 'toggle-adblock') {
    const { adblockEnabled } = await chrome.storage.local.get({ adblockEnabled: false });
    await chrome.storage.local.set({ adblockEnabled: !adblockEnabled });
  }
});

async function toggleKeyword() {
  const { enabled } = await chrome.storage.local.get({ enabled: DEFAULT_SETTINGS.enabled });
  await chrome.storage.local.set({ enabled: !enabled });
  await broadcastSettings();
}

async function flashBadge(tabId, text) {
  await chrome.action.setBadgeBackgroundColor({ tabId, color: '#d64545' });
  await chrome.action.setBadgeText({ tabId, text });
  setTimeout(() => chrome.action.setBadgeText({ tabId, text: '' }).catch(() => {}), 2000);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const senderTabId = sender.tab?.id;

  // ---- 批次開啟 ----
  if (message.type === 'open' && message.url) {
    (async () => {
      const tab = await chrome.tabs.create({
        url: message.url,
        active: false,
        index: (sender.tab?.index ?? 0) + 1
      });
      await chrome.storage.session.set({ [openedKey(tab.id)]: true });
    })();
    return false;
  }

  if (message.type === 'toggle-keyword') {
    toggleKeyword().then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === 'opener-state' && senderTabId != null) {
    if (message.running) {
      chrome.action.setBadgeBackgroundColor({ tabId: senderTabId, color: '#2e9c69' });
      chrome.action.setBadgeText({ tabId: senderTabId, text: '▶' });
    }
    if (!message.running) chrome.action.setBadgeText({ tabId: senderTabId, text: '' }).catch(() => {});
    const op = message.running
      ? chrome.storage.session.set({ [openerKey(senderTabId)]: true })
      : chrome.storage.session.remove(openerKey(senderTabId));
    op.then(() => sendResponse({ ok: true }));
    return true;
  }

  // ---- 關鍵字點擊 ----
  if (message.type === 'get-settings') {
    (async () => {
      const settings = await chrome.storage.local.get(DEFAULT_SETTINGS);
      const locked = senderTabId != null
        && !!(await chrome.storage.session.get(mediaFollowupKey(senderTabId)))[mediaFollowupKey(senderTabId)];
      sendResponse({ ...settings, mediaPageLocked: locked });
    })();
    return true;
  }

  if (message.type === 'can-run-on-tab') {
    (async () => {
      const settings = await chrome.storage.local.get(DEFAULT_SETTINGS);
      const flags = await chrome.storage.session.get([openerKey(senderTabId), openedKey(senderTabId)]);
      const mediaFlow = message.workflow === 'media';
      let allowed = mediaFlow
        ? settings.mediaKeywordEnabled
        : (settings.allTabs || settings.targetTabId == null || settings.targetTabId === senderTabId);
      if (flags[openerKey(senderTabId)]) allowed = false; // 正在批次開啟的列表頁不要自動點擊
      if ((mediaFlow ? settings.mediaKeywordOnlyOpenedTabs : settings.onlyOpenedTabs) && !flags[openedKey(senderTabId)]) allowed = false;
      sendResponse({ allowed });
    })();
    return true;
  }

  if (message.type === 'claim-page-scan') {
    (async () => {
      const settings = await chrome.storage.local.get(DEFAULT_SETTINGS);
      const scanOnce = message.workflow === 'media' ? settings.mediaKeywordClickOnce : settings.scanOncePerPage;
      if (!scanOnce) {
        sendResponse({ allowed: true });
        return;
      }
      const url = sender.tab?.url || message.url || '';
      const key = `scanned:${senderTabId}:${url}:${message.scanSignature || ''}`;
      const stored = await chrome.storage.session.get(key);
      if (stored[key]) {
        sendResponse({ allowed: false });
        return;
      }
      await chrome.storage.session.set({ [key]: Date.now() });
      sendResponse({ allowed: true });
    })();
    return true;
  }

  // 同一個網址只觸發一次：記住已觸發過的「流程＋網址＋關鍵字」，重新整理或另開分頁都不會再觸發（關閉瀏覽器後清空）
  if (message.type === 'claim-trigger') {
    claimTrigger(String(message.key || '')).then((allowed) => sendResponse({ allowed }));
    return true;
  }

  if (message.type === 'set-settings') {
    chrome.storage.local.set({ ...DEFAULT_SETTINGS, ...message.settings }).then(async () => {
      const settings = await chrome.storage.local.get(DEFAULT_SETTINGS);
      sendResponse({ ok: true, settings });
    });
    return true;
  }

  if (message.type === 'media-keyword-clicked' && senderTabId != null) {
    recordMediaDebug(senderTabId, 'keyword-clicked', { url: sender.tab?.url || '' }).catch(() => {});
    chrome.storage.session.set({ [mediaFollowupKey(senderTabId)]: Date.now() });
    // 影片流程點擊後要為新內容重新複製，所以同時清掉「已複製」記錄
    chrome.storage.session.remove([mediaKey(senderTabId), copiedKey(senderTabId)]).then(() => sendResponse({ ok: true }));
    return true;
  }
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (changeInfo.discarded === false) restoredAt.set(tabId, Date.now()); // 休眠分頁被喚醒
  // 頁面重新載入後，列表頁的 content script 會被重置，清掉執行中標記
  if (changeInfo.status === 'loading') {
    await mediaReady;
    const all = await chrome.storage.session.get(null);
    const prefix = `scanned:${tabId}:`;
    const stale = Object.keys(all).filter((k) => k.startsWith(prefix));
    // 換頁／重新整理時清空媒體與掃描認領記錄。「已複製」旗標不在這裡清：
    // tab 狀態變成 loading 也可能只是播放器 iframe 重新載入或休眠分頁被喚醒，不應讓切換回來的分頁重複複製
    await chrome.storage.session.remove([openerKey(tabId), mediaKey(tabId), ...stale]);
    return;
  }
  if (changeInfo.status !== 'complete') return;
  const followupKey = mediaFollowupKey(tabId);
  const followup = (await chrome.storage.session.get(followupKey))[followupKey];
  const settings = await chrome.storage.local.get(DEFAULT_SETTINGS);
  // ST 可能以同一網址重新載入；把「這次已完成關鍵字點擊」帶給新內容腳本，
  // 避免它在播放器載入期間又重新點擊 ST。
  chrome.tabs.sendMessage(tabId, {
    type: 'settings-updated',
    settings: { ...settings, mediaPageLocked: !!followup }
  }).catch(() => {});
  if (followup) {
    await chrome.storage.session.remove(followupKey);
    chrome.tabs.sendMessage(tabId, { type: 'media-followup' }).catch(() => {});
  }
  // 部分播放器在頁面 complete 後才發出播放清單，補檢查一次（該分頁已複製過則不會重複）。
  setTimeout(() => autoCopyTab(tabId, 'complete').catch(() => {}), 1200);
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  activatedAt.delete(tabId); restoredAt.delete(tabId); memCopiedTabs.delete(tabId);
  const all = await chrome.storage.session.get(null);
  const prefix = `scanned:${tabId}:`;
  const stale = Object.keys(all).filter((k) => k.startsWith(prefix));
  await chrome.storage.session.remove([openedKey(tabId), openerKey(tabId), mediaKey(tabId), mediaFollowupKey(tabId), mediaDebugKey(tabId), copiedKey(tabId), switchOnceKey(tabId), ...stale]);
});


/* =====================================================================
 * 影片偵測：以 webRequest 觀察回應標頭，找出影片／音訊／HLS／DASH
 * （只在本機記錄，不修改、不上傳任何請求）
 * ===================================================================== */
const mediaKey = (tabId) => `media:${tabId}`;
const mediaDebugKey = (tabId) => `media-debug:${tabId}`;
const MEDIA_FILE_EXT = /\.(mp4|m4v|webm|mp3|m4a|aac|ogg|oga|opus|flac|wav|mov|mkv|flv)$/i;
const MEDIA_SKIP_EXT = /\.(ts|m4s|mts|cmfv|cmfa|cmft|vtt|webvtt|srt|jpg|jpeg|png|gif|webp|svg|js|css|html?|json|key|woff2?)$/i;
const MEDIA_MIN_SIZE = 30 * 1024; // 小於 30KB 的直連檔多半是片段或廣告，不列出

let mediaDetectOn = false;
let mediaAutoCopy = true; // 偵測到影片時自動複製連結到剪貼簿
let mediaAutoCopyReset = true; // 換頁／重新整理後重新計算「每個分頁只複製一次」
let mediaSwitchOnce = true; // 切換到分頁只複製一次；來回切換回同一頁面不再複製
const mediaReady = chrome.storage.local.get({ mediaDetect: false, mediaAutoCopy: true, mediaAutoCopyReset: true, mediaSwitchOnce: true }).then((v) => {
  mediaSwitchOnce = v.mediaSwitchOnce !== false;
  mediaDetectOn = !!v.mediaDetect;
  mediaAutoCopy = v.mediaAutoCopy !== false;
  mediaAutoCopyReset = v.mediaAutoCopyReset !== false;
});
chrome.storage.onChanged.addListener((c, area) => {
  if (area !== 'local') return;
  if (c.mediaDetect) mediaDetectOn = !!c.mediaDetect.newValue;
  if (c.mediaAutoCopy) mediaAutoCopy = c.mediaAutoCopy.newValue !== false;
  if (c.mediaAutoCopyReset) mediaAutoCopyReset = c.mediaAutoCopyReset.newValue !== false;
  if (c.mediaSwitchOnce) mediaSwitchOnce = c.mediaSwitchOnce.newValue !== false;
});

async function recordMediaDebug(tabId, event, details = {}) {
  if (tabId == null || tabId < 0) return;
  const key = mediaDebugKey(tabId);
  const current = (await chrome.storage.session.get(key))[key] || [];
  current.push({ time: new Date().toISOString(), event, ...details });
  while (current.length > 80) current.shift();
  await chrome.storage.session.set({ [key]: current });
}

function classifyMedia(d) {
  if (d.method !== 'GET') return null;
  const headers = {};
  for (const h of d.responseHeaders || []) headers[h.name.toLowerCase()] = h.value || '';
  const mime = (headers['content-type'] || '').split(';')[0].trim().toLowerCase();
  let path = '';
  try { path = new URL(d.url).pathname; } catch { return null; }

  const isHls = /\.m3u8$/i.test(path) || /mpegurl/.test(mime);
  const isDash = /\.mpd$/i.test(path) || mime === 'application/dash+xml';
  if (isHls || isDash) {
    if (d.statusCode !== 200) return null;
    return { url: d.url, kind: isHls ? 'hls' : 'dash', ext: isHls ? 'm3u8' : 'mpd', mime, size: 0 };
  }

  if (MEDIA_SKIP_EXT.test(path) || mime === 'video/mp2t' || mime.startsWith('image/') || mime.startsWith('text/')) return null;
  const mediaByType = mime.startsWith('video/') || mime.startsWith('audio/');
  if (!mediaByType && !MEDIA_FILE_EXT.test(path)) return null;
  if (d.statusCode !== 200 && d.statusCode !== 206) return null;

  let size = parseInt(headers['content-length'] || '0', 10) || 0;
  const cr = /\/(\d+)$/.exec(headers['content-range'] || '');
  if (d.statusCode === 206 && cr) size = parseInt(cr[1], 10);
  if (size && size < MEDIA_MIN_SIZE) return null;

  let ext = (MEDIA_FILE_EXT.exec(path)?.[1] || '').toLowerCase();
  if (!ext) {
    const sub = mime.split('/')[1] || 'bin';
    ext = { mpeg: 'mp3', 'x-m4a': 'm4a', 'x-matroska': 'mkv', quicktime: 'mov', 'x-flv': 'flv' }[sub] || sub.replace(/^x-/, '');
  }
  return { url: d.url, kind: 'file', ext, mime, size };
}

let mediaChain = Promise.resolve(); // 序列化寫入，避免同時讀寫同一個清單
async function handleMedia(d) {
  await mediaReady;
  if (!mediaDetectOn) return;
  const info = classifyMedia(d);
  if (!info) return;
  recordMediaDebug(d.tabId, 'media-response', { kind: info.kind, url: d.url }).catch(() => {});
  const key = mediaKey(d.tabId);
  const cur = (await chrome.storage.session.get(key))[key] || [];
  const dup = cur.find((x) => x.url === info.url);
  if (dup) {
    if (info.size && !dup.size) { dup.size = info.size; await chrome.storage.session.set({ [key]: cur }); }
    return;
  }
  let referer = d.documentUrl || '';
  if (!referer) {
    try { referer = (await chrome.tabs.get(d.tabId)).url || ''; } catch { /* 分頁已關閉 */ }
  }
  cur.push({ ...info, referer, time: Date.now() });
  while (cur.length > 40) cur.shift();
  await chrome.storage.session.set({ [key]: cur });
  await autoCopyTab(d.tabId, 'detect').catch(() => {});
}

/* ---- 偵測到影片自動複製連結到剪貼簿 ----
 * 每個分頁只複製一次；「換頁／重新整理後重新計算」開關決定重新整理後是否再允許複製。
 * 只處理「目前正在瀏覽」的分頁（最後取得焦點的視窗中的使用中分頁）：
 *  - 目前分頁偵測到影片，且該分頁還沒複製過 → 複製
 *  - 背景分頁偵測到影片 → 只記錄，不動剪貼簿；等使用者切換到該分頁時才複製（一次）
 *  - 已經複製過的分頁，切換回來或又偵測到新影片都不再複製
 */
const AUDIO_EXT = /^(mp3|m4a|aac|ogg|oga|opus|flac|wav)$/;
const isVideoItem = (x) => !(/^audio\//.test(x.mime || '') || AUDIO_EXT.test(x.ext || ''));
const hostOf = (u) => { try { return new URL(u).host; } catch { return ''; } };

// 挑出該分頁要複製的連結：直連影片取最新一個；HLS／DASH 取「同一批」裡最早的（通常是主播放清單，內含各畫質）
function primaryOf(list) {
  const c = list.filter(isVideoItem).sort((a, b) => a.time - b.time);
  if (!c.length) return null;
  let i = c.length - 1;
  const last = c[i];
  if (last.kind === 'file') return last;
  while (i > 0 && c[i - 1].kind !== 'file' && c[i].time - c[i - 1].time < 15000 && hostOf(c[i - 1].url) === hostOf(last.url)) i--;
  return c[i];
}

async function isCurrentTab(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab.active) return false;
    const win = await chrome.windows.getLastFocused({ windowTypes: ['normal'] });
    return win.id === tab.windowId;
  } catch { return false; }
}

async function copyText(text) {
  try {
    await ensureOffscreen();
    const r = await chrome.runtime.sendMessage({ type: 'clip-copy', text });
    return !!r?.ok;
  } catch { return false; }
}

const activatedAt = new Map(); // tabId → 最近一次被切換成使用中分頁的時間（記憶體；事件同步寫入，不會有先後競態）
const restoredAt = new Map();  // tabId → 休眠分頁被喚醒的時間
const pageKey = (u) => { try { const x = new URL(u); x.hash = ''; return x.href; } catch { return String(u || ''); } };

// 序列化：偵測與切換分頁可能同時觸發，避免兩邊都判斷「還沒複製」而重複複製
let copyChain = Promise.resolve();
function autoCopyTab(tabId, reason = 'detect') {
  copyChain = copyChain.then(() => doAutoCopy(tabId, reason)).catch(() => {});
  return copyChain;
}

// 記憶體備援：即使 chrome.storage.session 寫入失敗，也能在背景程式存活期間避免重複複製
const memCopiedUrls = new Set();   // 已複製過的影片連結（pageKey）
const memCopiedTabs = new Map();   // tabId → 已複製／已處理的頁面（pageKey）

async function doAutoCopy(tabId, reason) {
  await mediaReady;
  if (!mediaDetectOn || !mediaAutoCopy) return;
  let curPage = '';
  try { curPage = pageKey((await chrome.tabs.get(tabId)).url); } catch { return; } // 分頁已關閉

  // 切換過去只複製一次：這個頁面已經因「切換／載入完成」處理過，來回切換不再複製。
  // 即使「已複製旗標」因換頁判斷被清掉，只要仍是同一個頁面就不會因切換而重複複製。
  const sk = switchOnceKey(tabId);
  const markHandled = async () => {
    memCopiedTabs.set(tabId, curPage);
    try { await chrome.storage.session.set({ [sk]: { page: curPage, time: Date.now() } }); } catch { /* 記憶體備援仍有效 */ }
  };
  if (mediaSwitchOnce && reason !== 'detect') {
    let rec = null;
    try { rec = (await chrome.storage.session.get(sk))[sk]; } catch { /* ignore */ }
    if ((rec && rec.page === curPage) || memCopiedTabs.get(tabId) === curPage) {
      recordMediaDebug(tabId, 'switch-skip', { why: 'same-page-already-handled', reason, page: curPage }).catch(() => {});
      return;
    }
  }

  const ck = copiedKey(tabId);
  let flag = null;
  try { flag = (await chrome.storage.session.get(ck))[ck]; } catch { /* ignore */ }
  if (!flag && memCopiedTabs.get(tabId) === curPage) flag = { page: curPage };
  if (flag) { // 這個分頁已經複製過，一律不再複製
    if (reason !== 'detect') {
      if (mediaSwitchOnce) await markHandled();
      recordMediaDebug(tabId, 'switch-skip', { why: 'already-copied', reason, copiedPage: flag.page || '' }).catch(() => {});
    }
    return;
  }
  if (!(await isCurrentTab(tabId))) return;
  const key = mediaKey(tabId);
  const list = (await chrome.storage.session.get(key))[key] || [];
  const p = primaryOf(list);
  if (!p) return;
  // 複製過的影片連結不再重複複製（不分分頁、重新整理後也一樣；關閉瀏覽器後清空）。
  // 此時不設定分頁旗標，該分頁之後若出現不同的影片，仍可複製。
  const urlKey = pageKey(p.url);
  let seen = {};
  try { seen = (await chrome.storage.session.get('copiedUrls')).copiedUrls || {}; } catch { /* ignore */ }
  if (seen[urlKey] || memCopiedUrls.has(urlKey)) {
    if (reason !== 'detect') {
      if (mediaSwitchOnce) await markHandled(); // 這次切換已處理，之後切換回來不再重新判斷
      recordMediaDebug(tabId, 'copy-skip', { why: 'url-already-copied', reason, url: p.url }).catch(() => {});
    }
    return;
  }

  // 先「認領」再複製：任何一步寫入失敗或同時觸發，都不會造成重複複製
  memCopiedUrls.add(urlKey);
  memCopiedTabs.set(tabId, curPage);
  try {
    seen[urlKey] = Date.now();
    const seenKeys = Object.keys(seen);
    if (seenKeys.length > 500) seenKeys.sort((x, y) => seen[x] - seen[y]).slice(0, seenKeys.length - 500).forEach((k) => delete seen[k]);
    await chrome.storage.session.set({ copiedUrls: seen });
    await chrome.storage.session.set({ [ck]: { video: p.url, page: curPage } });
    if (mediaSwitchOnce) await markHandled();
  } catch (e) {
    recordMediaDebug(tabId, 'claim-store-failed', { error: String(e?.message || e) }).catch(() => {});
  }
  if (!(await copyText(p.url))) { // 複製失敗：撤銷認領，讓之後還有機會再試
    memCopiedUrls.delete(urlKey);
    memCopiedTabs.delete(tabId);
    try {
      delete seen[urlKey];
      await chrome.storage.session.set({ copiedUrls: seen });
      await chrome.storage.session.remove([ck, sk]);
    } catch { /* ignore */ }
    recordMediaDebug(tabId, 'copy-failed', { reason, url: p.url }).catch(() => {});
    return;
  }
  recordMediaDebug(tabId, 'copied', { reason, kind: p.kind, url: p.url, page: curPage }).catch(() => {});
  chrome.tabs.sendMessage(tabId, { type: 'copy-toast', url: p.url, kind: p.kind }, () => void chrome.runtime.lastError);
}

// 同一網址只觸發一次的記錄（單一物件，最多 500 筆）；以序列化避免同時認領
let triggerChain = Promise.resolve();
function claimTrigger(key) {
  const run = triggerChain.then(async () => {
    const o = (await chrome.storage.session.get('triggeredUrls')).triggeredUrls || {};
    if (o[key]) return false;
    o[key] = Date.now();
    const keys = Object.keys(o);
    if (keys.length > 500) keys.sort((x, y) => o[x] - o[y]).slice(0, keys.length - 500).forEach((k) => delete o[k]);
    await chrome.storage.session.set({ triggeredUrls: o });
    return true;
  }).catch(() => true); // 儲存失敗時不阻擋
  triggerChain = run;
  return run;
}

let switchTimer = null;
function onViewChanged(tabId) { // 快速連續切換分頁時，只處理最後停留的那一個
  activatedAt.set(tabId, Date.now());
  clearTimeout(switchTimer);
  switchTimer = setTimeout(() => autoCopyTab(tabId, 'switch').catch(() => {}), 300);
}
chrome.tabs.onActivated.addListener(({ tabId }) => onViewChanged(tabId));
chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) return;
  const [tab] = await chrome.tabs.query({ active: true, windowId }).catch(() => []);
  if (tab) onViewChanged(tab.id);
});

// 「換頁／重新整理後重新計算」：只有「確定是使用者換頁或重新整理」才清掉已複製旗標。
//  - 換到不同網址 → 重置
//  - 同一網址的重新載入（可能是重新整理，也可能是休眠喚醒、網站在切回分頁時自動重新載入、背景自動重新整理）
//    → 只有「目前正在瀏覽」、且不是剛切換過來（8 秒內）、也不是剛被喚醒（20 秒內）才算使用者重新整理
async function onMainFrameNavigation(d) {
  if (d.statusCode >= 300 && d.statusCode < 400) return; // 轉址中間站，不算
  await mediaReady;
  if (!mediaAutoCopyReset) return;
  const tabId = d.tabId;
  const ck = copiedKey(tabId);
  const flag = (await chrome.storage.session.get(ck))[ck];
  if (!flag) return;
  const now = Date.now();
  let reason = '';
  let skip = '';
  if (pageKey(d.url) !== (typeof flag === 'object' ? flag.page : '')) reason = 'new-page';
  else if (now - (activatedAt.get(tabId) || 0) < 8000) skip = 'just-activated';
  else if (now - (restoredAt.get(tabId) || 0) < 20000) skip = 'just-restored';
  else if (!(await isCurrentTab(tabId))) skip = 'background-reload';
  else reason = 'user-reload';
  if (!reason) {
    recordMediaDebug(tabId, 'copy-reset-skipped', { why: skip, url: d.url }).catch(() => {});
    return;
  }
  memCopiedTabs.delete(tabId);
  await chrome.storage.session.remove([ck, switchOnceKey(tabId)]);
  recordMediaDebug(tabId, 'copy-reset', { reason, url: d.url }).catch(() => {});
}

chrome.webRequest.onHeadersReceived.addListener(
  (d) => {
    if (d.tabId < 0) return;
    mediaChain = mediaChain.then(async () => {
      if (d.type === 'main_frame') await onMainFrameNavigation(d);
      return handleMedia(d);
    }).catch(() => {});
  },
  { urls: ['<all_urls>'], types: ['main_frame', 'media', 'xmlhttprequest', 'other', 'object'] },
  ['responseHeaders']
);


/* =====================================================================
 * 下載引擎（offscreen 文件）：由彈出視窗操作，關閉彈出視窗後仍會繼續下載
 * offscreen 文件只能用 chrome.runtime，downloads／declarativeNetRequest 由這裡代為呼叫
 * ===================================================================== */
async function ensureOffscreen() {
  const ctx = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
  if (ctx.length) return;
  try {
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['BLOBS', 'CLIPBOARD'],
      justification: '在背景下載並合併影片區段（Blob）；並將偵測到的影片連結寫入剪貼簿'
    });
  } catch (e) {
    if (!/single offscreen/i.test(e.message)) throw e; // 同時建立時的競爭，忽略
  }
}

const DL_API = {
  'downloads.download': (o) => chrome.downloads.download(o),
  'downloads.search': (q) => chrome.downloads.search(q),
  'downloads.pause': (id) => chrome.downloads.pause(id),
  'downloads.resume': (id) => chrome.downloads.resume(id),
  'downloads.cancel': (id) => chrome.downloads.cancel(id),
  'downloads.show': async (id) => { chrome.downloads.show(id); },
  'dnr.updateSessionRules': (o) => chrome.declarativeNetRequest.updateSessionRules(o),
  'dnr.getSessionRules': () => chrome.declarativeNetRequest.getSessionRules(),
  'storage.get': (keys) => chrome.storage.local.get(keys)
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) return false;
  if (message.type === 'media-debug' && sender.tab?.id != null) {
    recordMediaDebug(sender.tab.id, message.event || 'page-event', message.details || {}).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message.type === 'adblock-add') { // 元素選取器：把選取的元素加入阻擋清單（隱藏規則／封鎖網域）
    (async () => {
      const cur = await chrome.storage.local.get({ adblockHide: [], adblockCustom: [], adblockEnabled: false });
      const hide = Array.isArray(cur.adblockHide) ? cur.adblockHide.slice() : [];
      let addedRules = 0;
      let rejected = 0;
      for (const raw of message.rules || []) {
        const m = /^([a-z0-9.,*-]*)##([\s\S]+)$/i.exec(String(raw).trim());
        const sel = m ? m[2].trim() : '';
        if (!m || !sel || sel.length > 600 || /^(html|body|head|\*)$/i.test(sel)) { rejected++; continue; } // 過於寬鬆的規則會讓整頁消失
        const rule = `${m[1].toLowerCase()}##${sel}`;
        if (!hide.includes(rule)) { hide.push(rule); addedRules++; }
      }
      const custom = cleanDomains(cur.adblockCustom);
      const own = cleanDomains([message.pageHost || '']);
      const addedDomains = cleanDomains(message.domains).filter((d) => !custom.includes(d) && !own.includes(d));
      await chrome.storage.local.set({ adblockHide: hide, adblockCustom: [...custom, ...addedDomains] });
      sendResponse({ ok: true, addedRules, rejected, addedDomains, enabled: !!cur.adblockEnabled });
    })().catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  }
  if (message.type === 'build-check') { // 彈出視窗用來確認背景程式是不是同一版
    sendResponse({ build: BUILD, version: chrome.runtime.getManifest().version });
    return false;
  }
  if (message.type === 'media-diagnostics') {
    (async () => {
      const tabId = Number(message.tabId);
      const tab = await chrome.tabs.get(tabId).catch(() => null);
      const local = await chrome.storage.local.get({
        mediaDetect: false, mediaAutoCopy: true, mediaAutoCopyReset: true, mediaSwitchOnce: true, mediaKeywordEnabled: false,
        mediaKeywordPageKeywords: [], mediaKeywordLinkKeywords: [], mediaKeywordDelayMs: 500,
        mediaKeywordCaseSensitive: false, mediaKeywordClickOnce: true, mediaKeywordOnlyOpenedTabs: false,
        triggerOnce: true, mediaKeywordTriggerOnce: true
      });
      const media = (await chrome.storage.session.get(mediaKey(tabId)))[mediaKey(tabId)] || [];
      const debug = (await chrome.storage.session.get(mediaDebugKey(tabId)))[mediaDebugKey(tabId)] || [];
      const flagKey = copiedKey(tabId);
      const onceKey = switchOnceKey(tabId);
      const st = await chrome.storage.session.get([flagKey, onceKey, 'copiedUrls']);
      sendResponse({
        version: chrome.runtime.getManifest().version,
        build: BUILD,
        copyState: {
          autocopiedFlag: st[flagKey] || null,
          switchOnceRecord: st[onceKey] || null,
          copiedUrlsCount: Object.keys(st.copiedUrls || {}).length,
          memoryTabPage: memCopiedTabs.get(tabId) || null,
          memoryUrlsCount: memCopiedUrls.size
        },
        generatedAt: new Date().toISOString(),
        tab: tab ? { id: tab.id, title: tab.title, url: tab.url, status: tab.status } : null,
        settings: local,
        media,
        debug: debug.slice(-80)
      });
    })().catch((e) => sendResponse({ error: e.message }));
    return true;
  }
  if (message.type === 'dl-ensure') {
    ensureOffscreen().then(() => sendResponse({ ok: true }), (e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (message.type === 'autocopy-off') { // 頁面提示上的「關閉自動複製」
    chrome.storage.local.set({ mediaAutoCopy: false }).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message.type === 'dl-proxy') {
    const fn = DL_API[message.api];
    if (!fn) { sendResponse({ error: '不支援的呼叫' }); return false; }
    Promise.resolve(fn(...(message.args || [])))
      .then((result) => sendResponse({ result }), (e) => sendResponse({ error: e?.message || String(e) }));
    return true;
  }
  return false;
});
