const BUILD = '2.13.0-claim-first'; // 必須與 service-worker.js 的 BUILD 相同
const $ = (id) => document.getElementById(id);

/* ---------- 分頁切換 ---------- */
document.querySelectorAll('.tab').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((b) => b.classList.toggle('active', b === btn));
    document.querySelectorAll('.view').forEach((v) => { v.hidden = v.id !== btn.dataset.view; });
    chrome.storage.local.set({ lastView: btn.dataset.view });
  });
});

/* ================= 批次開啟 ================= */
const openerStatus = (t) => { $('openerStatus').textContent = t; };

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function sendToPage(msg) {
  const tab = await activeTab();
  try {
    return await chrome.tabs.sendMessage(tab.id, msg);
  } catch {
    openerStatus('此頁面無法使用（請重新整理頁面，或 chrome:// 等內建頁面不支援）');
    return null;
  }
}

function openerConfig() {
  return {
    selector: $('selector').value.trim() || 'a:has(img)',
    delay: Math.max(300, Number($('delay').value) || 1500),
    max: Math.max(1, Number($('max').value) || 20)
  };
}

async function saveOpener() {
  const cfg = openerConfig();
  await chrome.storage.local.set({
    openerSelector: cfg.selector, openerDelay: cfg.delay, openerMax: cfg.max,
    openerMark: $('openerMark').checked, openerSkipVisited: $('openerSkipVisited').checked,
    openerMarkExclude: cleanHosts(toList($('openerMarkExclude').value)),
    pickerText: $('pickerText').checked,
    pickerTextLen: Math.min(200, Math.max(5, Number($('pickerTextLen').value) || 40)),
    pickerUrl: $('pickerUrl').checked,
    pickerUrlKey: ($('pickerUrlKey').value.trim().charAt(0) || 'u').toLowerCase()
  });
  $('pickerTextLen').value = Math.min(200, Math.max(5, Number($('pickerTextLen').value) || 40));
  $('pickerUrlKey').value = ($('pickerUrlKey').value.trim().charAt(0) || 'u').toLowerCase();
  $('openerMarkExclude').value = toText(cleanHosts(toList($('openerMarkExclude').value)));
  refreshExcludeButton();
  $('selector').value = cfg.selector; $('delay').value = cfg.delay; $('max').value = cfg.max;
}

$('start').onclick = async () => {
  const cfg = openerConfig();
  await saveOpener(); // 先存設定（含「略過已開啟」），頁面端才會用最新值
  const r = await sendToPage({ type: 'opener-start', ...cfg });
  const sk = r?.skipped ? `（已略過 ${r.skipped} 個已開啟）` : '';
  if (r) openerStatus(r.ok ? `開始開啟，共 ${r.count} 個連結${sk}` : `沒有可開啟的連結${sk}`);
};

$('startPicker').onclick = async () => {
  await saveOpener();
  const r = await sendToPage({ type: 'picker-toggle' });
  if (r) window.close(); // 關閉彈出視窗，才能在頁面上點選元素
};

$('stop').onclick = async () => {
  const r = await sendToPage({ type: 'opener-stop' });
  if (r) openerStatus('已停止');
};

async function previewCount() {
  const tab = await activeTab();
  try {
    const r = await chrome.tabs.sendMessage(tab.id, { type: 'opener-count', selector: openerConfig().selector });
    if (r) openerStatus(`目前頁面可開啟 ${r.count} 個連結${r.skipped ? `（已略過 ${r.skipped} 個已開啟）` : ''}`);
  } catch { /* 非 javpop 頁面，忽略 */ }
}
$('selector').addEventListener('change', previewCount);

/* ---------- 標示例外網站 ---------- */
const hostRe = /^[a-z0-9-]+(\.[a-z0-9-]+)+$/;
const cleanHosts = (list) => [...new Set((list || [])
  .map((d) => String(d).trim().toLowerCase().replace(/^[a-z]+:\/\//, '').replace(/^\*?\.?/, '').replace(/^www\./, '').split(/[\/?#:]/)[0])
  .filter((d) => hostRe.test(d)))];

async function currentHost() {
  const tab = await activeTab();
  try {
    const u = new URL(tab.url);
    if (!/^https?:$/.test(u.protocol)) return '';
    return u.hostname.toLowerCase().replace(/^www\./, '');
  } catch { return ''; }
}
const hostMatches = (host, list) => list.some((d) => host === d || host.endsWith('.' + d));

async function refreshExcludeButton() {
  const host = await currentHost();
  const btn = $('markExcludeHere');
  if (!host) {
    btn.disabled = true;
    btn.textContent = '目前網站加入例外清單';
    $('markExcludeStatus').textContent = '此頁面無法加入（僅支援 http／https 網站）';
    return;
  }
  btn.disabled = false;
  const excluded = hostMatches(host, cleanHosts(toList($('openerMarkExclude').value)));
  btn.textContent = excluded ? `將 ${host} 移出例外清單` : `將 ${host} 加入例外清單`;
  $('markExcludeStatus').textContent = excluded ? `${host} 目前不標示 ✓` : '';
}

$('markExcludeHere').addEventListener('click', async () => {
  const host = await currentHost();
  if (!host) return;
  let list = cleanHosts(toList($('openerMarkExclude').value));
  const excluded = hostMatches(host, list);
  // 移出時，同時移除涵蓋此網站的條目（例如 example.com 涵蓋 a.example.com）
  list = excluded ? list.filter((d) => !(host === d || host.endsWith('.' + d))) : [...list, host];
  $('openerMarkExclude').value = toText(list);
  await chrome.storage.local.set({ openerMarkExclude: list });
  await refreshExcludeButton();
  $('markExcludeStatus').textContent = excluded ? `已將 ${host} 移出例外清單，頁面會恢復標示` : `已將 ${host} 加入例外清單，頁面不再標示`;
});
$('openerMarkExclude').addEventListener('input', refreshExcludeButton);

async function showVisitedCount() {
  const { openerVisited } = await chrome.storage.local.get({ openerVisited: {} });
  $('visitedCount').textContent = `已記錄 ${Object.keys(openerVisited).length} 個已開啟連結`;
}
$('clearVisited').onclick = async () => {
  if (!confirm('確定清除所有已開啟紀錄？')) return;
  await chrome.storage.local.remove('openerVisited');
  showVisitedCount();
  openerStatus('已清除紀錄');
  previewCount();
};
$('openerSkipVisited').addEventListener('change', async () => {
  await chrome.storage.local.set({ openerSkipVisited: $('openerSkipVisited').checked });
  previewCount();
});

/* ================= 關鍵字點擊 ================= */
const defaults = {
  enabled: false,
  allTabs: true,
  pageKeywords: [],
  linkKeywords: [],
  delayMs: 500,
  clickOnce: true,
  triggerOnce: true,
  scanOncePerPage: true,
  caseSensitive: false,
  onlyOpenedTabs: false,
  targetTabId: null
};

const toList = (value) => value.split(/[\n,，、]+/).map((item) => item.trim()).filter(Boolean);
const toText = (value) => Array.isArray(value) ? value.join(', ') : (value || '');

function updateHint() {
  $('scopeHint').textContent = $('allTabs').checked ? '所有已開啟及之後開啟的分頁' : '關閉時只套用目前分頁';
}
$('allTabs').addEventListener('change', updateHint);

async function saveKeyword() {
  const tab = await activeTab();
  const allTabs = $('allTabs').checked;
  const settings = {
    enabled: $('enabled').checked,
    allTabs,
    onlyOpenedTabs: $('onlyOpenedTabs').checked,
    pageKeywords: toList($('pageKeywords').value),
    linkKeywords: toList($('linkKeywords').value),
    delayMs: Math.max(0, Number($('delayMs').value) || 0),
    clickOnce: $('clickOnce').checked,
    triggerOnce: $('triggerOnce').checked,
    scanOncePerPage: $('scanOncePerPage').checked,
    caseSensitive: $('caseSensitive').value === 'true',
    targetTabId: allTabs ? null : (tab?.id ?? null)
  };
  await chrome.storage.local.set(settings);
  const tabs = allTabs ? await chrome.tabs.query({}) : (tab ? [tab] : []);
  await Promise.all(tabs.map((item) => chrome.tabs.sendMessage(item.id, { type: 'settings-updated', settings }).catch(() => {})));
  return allTabs ? '關鍵字點擊套用所有分頁' : '關鍵字點擊只套用目前分頁';
}

/* ================= 廣告阻擋 ================= */
const adStatus = (t) => { $('adblockStatus').textContent = t; setTimeout(() => { $('adblockStatus').textContent = ''; }, 2500); };

async function saveAdblock() {
  await chrome.storage.local.set({
    adblockEnabled: $('adblockEnabled').checked,
    ytAdblock: $('ytAdblock').checked,
    ytNetwork: $('ytNetwork').checked,
    adblockCustom: toList($('adblockCustom').value),
    // 隱藏規則每行一筆（選擇器內可能有逗號，不能用逗號分隔）；沒寫「網站##」的視為所有網站
    adblockHide: $('adblockHide').value.split(/\r?\n/).map((l) => l.trim()).filter(Boolean).map((l) => (l.includes('##') ? l : `##${l}`)),
    adblockAllow: toList($('adblockAllow').value)
  });
}

$('adblockAllowHere').addEventListener('click', async () => {
  const tab = await activeTab();
  let host = '';
  try { host = new URL(tab.url).hostname.replace(/^www\./, ''); } catch {}
  if (!host) { adStatus('無法取得目前網站'); return; }
  const list = toList($('adblockAllow').value);
  if (!list.includes(host)) list.push(host);
  $('adblockAllow').value = list.join(', ');
  await chrome.storage.local.set({ adblockAllow: list });
  adStatus(`已加入白名單：${host}`);
});

/* ================= 影片偵測與下載 ================= */
const mediaKey = (id) => `media:${id}`;
function fmtSize(n) {
  if (!n) return '';
  const u = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return `${n >= 100 || i === 0 ? Math.round(n) : n.toFixed(1)} ${u[i]}`;
}
const mediaStatus = (t) => { $('mediaStatus').textContent = t; setTimeout(() => { $('mediaStatus').textContent = ''; }, 2500); };
async function copyToClipboard(text) {
  try {
    const ready = await chrome.runtime.sendMessage({ type: 'dl-ensure' });
    if (ready?.ok !== false) {
      const copied = await chrome.runtime.sendMessage({ type: 'clip-copy', text });
      if (copied?.ok) return true;
    }
  } catch { /* 改用 popup 原生剪貼簿 API */ }
  try {
    await navigator.clipboard.writeText(String(text));
    return true;
  } catch {
    return false;
  }
}

async function renderMedia() {
  const tab = await activeTab();
  const box = $('mediaList');
  box.textContent = '';
  const list = tab ? ((await chrome.storage.session.get(mediaKey(tab.id)))[mediaKey(tab.id)] || []) : [];
  $('mediaTab').textContent = list.length ? `影片 (${list.length})` : '影片';
  if (!list.length) {
    const d = document.createElement('div');
    d.className = 'media-empty';
    d.textContent = $('mediaDetect').checked ? '尚未偵測到媒體，請開始播放影片' : '偵測尚未啟用：勾選上方開關並儲存設定後，重新整理頁面';
    box.appendChild(d);
    return;
  }
  [...list].reverse().forEach((item) => {
    const row = document.createElement('div');
    row.className = 'media-row';
    const kind = document.createElement('span');
    kind.className = `kind ${item.kind}`;
    kind.textContent = item.kind === 'file' ? item.ext.toUpperCase() : item.kind.toUpperCase();
    const meta = document.createElement('div');
    meta.className = 'meta';
    const name = document.createElement('div');
    name.className = 'name';
    let host = '';
    let file = item.url;
    try {
      const u = new URL(item.url);
      host = u.hostname;
      file = decodeURIComponent(u.pathname.split('/').filter(Boolean).pop() || u.hostname);
    } catch { /* 保留完整網址 */ }
    name.textContent = file;
    name.title = item.url;
    const sub = document.createElement('div');
    sub.className = 'sub';
    sub.textContent = [fmtSize(item.size), host].filter(Boolean).join(' · ');
    const url = document.createElement('div');
    url.className = 'media-url';
    url.textContent = item.url;
    url.title = item.url;
    meta.append(name, sub, url);
    const dl = document.createElement('button');
    dl.textContent = '下載';
    dl.onclick = () => addToQueue(item, tab);
    const cp = document.createElement('button');
    cp.className = 'ghost';
    cp.textContent = '複製';
    cp.title = '複製連結';
    cp.onclick = async () => { mediaStatus(await copyToClipboard(item.url) ? '已複製連結' : '複製失敗，請確認 Chrome 剪貼簿權限'); };
    row.append(kind, meta, dl, cp);
    box.appendChild(row);
  });
}

/* ---- 下載佇列：引擎在背景（offscreen），這裡只負責顯示與下達指令 ---- */
async function dlSend(cmd, data = {}) {
  const r = await chrome.runtime.sendMessage({ type: 'dl-ensure' });
  if (r && r.ok === false) throw new Error(r.error || '無法啟動下載引擎');
  return chrome.runtime.sendMessage({ type: 'dlq-cmd', cmd, ...data });
}
async function addToQueue(item, tab) {
  try {
    await dlSend('add', {
      item: { url: item.url, kind: item.kind, ext: item.ext, size: item.size, title: tab?.title || '', referer: item.referer || tab?.url || '' }
    });
    mediaStatus('已加入下載佇列');
  } catch (e) { mediaStatus(`加入失敗：${e.message}`); }
}

const dqCards = new Map(); // 任務 id → 卡片元素
const DQ_BUTTONS = [
  ['pause', '暫停', 'ghost'], ['resume', '繼續', ''], ['retry', '重試', ''], ['fallback', '改用 fetch 重試', 'ghost'],
  ['show', '顯示檔案', 'ghost'], ['cancel', '取消', 'danger'], ['remove', '移除', 'ghost']
];

function dqMake(t) {
  const el = document.createElement('div');
  el.className = 'dq-card';
  el.innerHTML = `
    <div class="dq-top"><span class="dq-badge"></span><span class="dq-title"></span><span class="dq-state"></span></div>
    <div class="dq-choose" hidden>
      <select class="dq-quality"></select>
      <label hidden><input type="checkbox" class="dq-audio" checked> 同時下載音訊</label>
      <button data-a="start">開始下載</button>
    </div>
    <div class="dq-bar"><i></i></div>
    <div class="dq-info"></div>
    <div class="dq-note"></div>
    <div class="dq-actions"></div>`;
  const badge = el.querySelector('.dq-badge');
  badge.textContent = t.kind === 'file' ? (t.ext || 'FILE').toUpperCase() : t.kind.toUpperCase();
  badge.classList.add(t.kind);
  const title = el.querySelector('.dq-title');
  title.textContent = t.title;
  title.title = t.url;
  const actions = el.querySelector('.dq-actions');
  DQ_BUTTONS.forEach(([a, label, cls]) => {
    const b = document.createElement('button');
    b.dataset.a = a; b.textContent = label; b.hidden = true;
    if (cls) b.className = cls;
    actions.appendChild(b);
  });
  el.addEventListener('click', (e) => {
    const b = e.target.closest('button[data-a]');
    if (!b) return;
    const extra = b.dataset.a === 'start'
      ? { idx: Number(el.querySelector('.dq-quality').value) || 0, withAudio: el.querySelector('.dq-audio').checked }
      : {};
    dlSend(b.dataset.a, { id: t.id, ...extra }).catch(() => {});
  });
  return el;
}

function dqUpdate(el, t) {
  el.dataset.state = t.state;
  el.querySelector('.dq-state').textContent = t.stateText;
  el.querySelector('.dq-state').title = t.stateText;
  const choosing = t.state === 'choose';
  el.querySelector('.dq-choose').hidden = !choosing;
  const sel = el.querySelector('.dq-quality');
  if (choosing && !sel.options.length) { // 畫質選單只建立一次，避免更新時重設使用者的選擇
    t.options.forEach((label, i) => sel.add(new Option(label, i)));
    el.querySelector('.dq-choose label').hidden = !t.hasAudio;
  }
  el.querySelector('.dq-bar i').style.width = `${t.pct.toFixed(1)}%`;
  el.querySelector('.dq-info').textContent = t.info;
  el.querySelector('.dq-note').textContent = t.note;
  const s = t.state;
  const vis = {
    pause: s === 'downloading', resume: s === 'paused',
    retry: s === 'error' && !t.canFallback, fallback: s === 'error' && t.canFallback,
    show: s === 'done' && t.hasDownload,
    cancel: ['analyzing', 'choose', 'queued', 'downloading', 'paused'].includes(s),
    remove: ['done', 'error', 'cancelled', 'choose'].includes(s)
  };
  el.querySelectorAll('.dq-actions button').forEach((b) => { b.hidden = !vis[b.dataset.a]; });
}

function renderQueue(snap) {
  const list = $('dqList');
  const tasks = snap?.tasks || [];
  const ids = new Set(tasks.map((t) => t.id));
  for (const [id, el] of dqCards) if (!ids.has(id)) { el.remove(); dqCards.delete(id); }
  tasks.forEach((t, i) => { // 任務由新到舊排列
    let el = dqCards.get(t.id);
    if (!el) { el = dqMake(t); dqCards.set(t.id, el); }
    dqUpdate(el, t);
    if (list.children[i] !== el) list.insertBefore(el, list.children[i] || null);
  });
  $('dqEmpty').hidden = tasks.length > 0;
  $('dqSummary').textContent = tasks.length ? `共 ${tasks.length} 項，進行中 ${snap.active} 項` : '';
}

chrome.runtime.onMessage.addListener((m) => { if (m.type === 'dlq-state') renderQueue(m); });

async function loadQueue() {
  const ctx = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
  if (!ctx.length) { renderQueue({ tasks: [], active: 0 }); return; } // 引擎尚未啟動＝沒有任務
  renderQueue(await chrome.runtime.sendMessage({ type: 'dlq-cmd', cmd: 'get' }).catch(() => null));
}

$('dqAdd').onclick = async () => {
  const url = $('dqUrl').value.trim();
  if (!/^https?:\/\//i.test(url)) { $('dqUrl').focus(); return; }
  let path = '';
  try { path = new URL(url).pathname; } catch { return; }
  const kind = /\.m3u8$/i.test(path) ? 'hls' : /\.mpd$/i.test(path) ? 'dash' : 'file';
  const ext = /\.([a-z0-9]{2,5})$/i.exec(path)?.[1]?.toLowerCase() || 'mp4';
  const name = decodeURIComponent(path.split('/').filter(Boolean).pop() || new URL(url).hostname).replace(/\.[a-z0-9]{2,5}$/i, '');
  try {
    await dlSend('add', { item: { url, kind, ext: kind === 'file' ? ext : '', title: name, referer: $('dqRef').value.trim() } });
    $('dqUrl').value = '';
    mediaStatus('已加入下載佇列');
  } catch (e) { mediaStatus(`加入失敗：${e.message}`); }
};
$('dqClear').onclick = () => dlSend('clearDone').catch(() => {});
$('clearMedia').onclick = async () => {
  const tab = await activeTab();
  if (tab) await chrome.storage.session.remove(mediaKey(tab.id));
  renderMedia();
};
$('copyMediaDiagnostics').onclick = async () => {
  const tab = await activeTab();
  if (!tab?.id) { mediaStatus('無法取得目前分頁'); return; }
  const report = await chrome.runtime.sendMessage({ type: 'media-diagnostics', tabId: tab.id }).catch((e) => ({ error: e.message }));
  const text = JSON.stringify({ popupBuild: BUILD, popupVersion: chrome.runtime.getManifest().version, ...(report || { error: '沒有收到診斷資料' }) }, null, 2);
  mediaStatus(await copyToClipboard(text)
    ? '診斷資料已複製，請貼回回報問題'
    : '無法寫入剪貼簿，請確認 Chrome 剪貼簿權限');
};
chrome.storage.session.onChanged.addListener((c) => {
  if (Object.keys(c).some((k) => k.startsWith('media:'))) renderMedia();
});
$('mediaDetect').addEventListener('change', renderMedia);

async function saveMedia() {
  const folder = $('dlFolder').value.split(/[\\/]+/)
    .map((x) => x.replace(/[<>:"|?*\x00-\x1f]/g, '').trim().replace(/[. ]+$/, ''))
    .filter((x) => x && x !== '.' && x !== '..').join('/');
  $('dlFolder').value = folder;
  await chrome.storage.local.set({
    mediaDetect: $('mediaDetect').checked,
    mediaAutoCopy: $('mediaAutoCopy').checked,
    mediaAutoCopyReset: $('mediaAutoCopyReset').checked,
    mediaSwitchOnce: $('mediaSwitchOnce').checked,
    mediaKeywordEnabled: $('mediaKeywordEnabled').checked,
    mediaKeywordPageKeywords: toList($('mediaKeywordPageKeywords').value),
    mediaKeywordLinkKeywords: toList($('mediaKeywordLinkKeywords').value),
    mediaKeywordDelayMs: Math.max(0, Number($('mediaKeywordDelayMs').value) || 0),
    mediaKeywordCaseSensitive: $('mediaKeywordCaseSensitive').value === 'true',
    mediaKeywordClickOnce: $('mediaKeywordClickOnce').checked,
    mediaKeywordTriggerOnce: $('mediaKeywordTriggerOnce').checked,
    mediaKeywordOnlyOpenedTabs: $('mediaKeywordOnlyOpenedTabs').checked,
    dlFolder: folder,
    dlSaveAs: $('dlSaveAs').checked
  });
  const settings = await chrome.storage.local.get({
    mediaKeywordEnabled: false, mediaKeywordPageKeywords: [], mediaKeywordLinkKeywords: [],
    mediaKeywordDelayMs: 500, mediaKeywordCaseSensitive: false, mediaKeywordClickOnce: true,
    mediaKeywordTriggerOnce: true, mediaKeywordOnlyOpenedTabs: false
  });
  const tabs = await chrome.tabs.query({});
  await Promise.all(tabs.map((tab) => chrome.tabs.sendMessage(tab.id, { type: 'settings-updated', settings }).catch(() => {})));
}
$('openDlFolder').onclick = () => chrome.downloads.showDefaultFolder();

/* ================= 儲存設定（全部） ================= */
const saveBtn = $('saveAll');
let statusTimer = null;
function setDirty(on) {
  saveBtn.classList.toggle('dirty', on);
  if (on) { clearTimeout(statusTimer); $('saveStatus').textContent = '有尚未儲存的變更'; }
}
document.querySelectorAll('.view').forEach((v) => {
  v.addEventListener('input', (e) => { if (!e.target.classList.contains('hotkey') && !e.target.closest('.nodirty')) setDirty(true); });
  v.addEventListener('change', (e) => { if (!e.target.classList.contains('hotkey') && !e.target.closest('.nodirty')) setDirty(true); });
});

saveBtn.addEventListener('click', async () => {
  await saveOpener();
  const keywordMsg = await saveKeyword();
  await saveAdblock();
  await saveMedia();
  setDirty(false);
  $('saveStatus').textContent = `已儲存全部設定（${keywordMsg}）`;
  clearTimeout(statusTimer);
  statusTimer = setTimeout(() => { $('saveStatus').textContent = ''; }, 3000);
});

/* ================= 自訂快捷鍵錄製 ================= */
const MODIFIER_CODES = /^(Control|Alt|Shift|Meta)(Left|Right)$/;
const KEY_LABEL = (code) => code.replace(/^Key/, '').replace(/^Digit/, '').replace(/^Arrow/, '');
const hotkeyText = (hk) => hk
  ? [hk.ctrl && 'Ctrl', hk.alt && 'Alt', hk.shift && 'Shift', hk.meta && 'Meta', KEY_LABEL(hk.code)].filter(Boolean).join('+')
  : '';

function bindHotkey(inputId, storageKey) {
  const el = $(inputId);
  el.addEventListener('focus', () => { el.classList.add('recording'); el.placeholder = '請按下組合鍵…（Esc 取消）'; });
  el.addEventListener('blur', () => { el.classList.remove('recording'); el.placeholder = '點此後按下組合鍵；Backspace 清除'; });
  el.addEventListener('keydown', async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.code === 'Escape') { el.blur(); return; }
    if (e.code === 'Backspace' || e.code === 'Delete') {
      el.value = '';
      await chrome.storage.local.remove(storageKey);
      el.blur();
      return;
    }
    if (MODIFIER_CODES.test(e.code)) return; // 只按修飾鍵時繼續等待
    const hasMod = e.ctrlKey || e.altKey || e.metaKey || e.shiftKey;
    const isFKey = /^F\d{1,2}$/.test(e.code);
    if (!hasMod && !isFKey) {
      el.value = '';
      el.placeholder = '需搭配 Ctrl／Alt／Shift 或使用 F 鍵';
      return;
    }
    const hk = { code: e.code, ctrl: e.ctrlKey, alt: e.altKey, shift: e.shiftKey, meta: e.metaKey };
    await chrome.storage.local.set({ [storageKey]: hk });
    el.value = hotkeyText(hk);
    el.blur();
  });
}
bindHotkey('hotkeyOpener', 'hotkeyOpener');
bindHotkey('hotkeyKeyword', 'hotkeyKeyword');
$('openShortcuts').onclick = () => chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });

/* ================= 初始化 ================= */
async function init() {
  document.querySelector('h1').textContent = `JavPop v${chrome.runtime.getManifest().version}`;
  const s = await chrome.storage.local.get({
    ...defaults,
    openerSelector: 'a:has(img)',
    openerDelay: 1500,
    openerMax: 20,
    openerMark: true,
    openerSkipVisited: false,
    openerMarkExclude: [],
    pickerText: true,
    pickerTextLen: 40,
    pickerUrl: false,
    pickerUrlKey: 'u',
    lastView: 'openerView',
    hotkeyOpener: null,
    hotkeyKeyword: null,
    mediaDetect: false,
    mediaAutoCopy: true,
    mediaAutoCopyReset: true,
    mediaSwitchOnce: true,
    mediaKeywordEnabled: false,
    mediaKeywordPageKeywords: [],
    mediaKeywordLinkKeywords: [],
    mediaKeywordDelayMs: 500,
    mediaKeywordCaseSensitive: false,
    mediaKeywordClickOnce: true,
    mediaKeywordTriggerOnce: true,
    mediaKeywordOnlyOpenedTabs: false,
    dlFolder: 'JavPop',
    dlSaveAs: false,
    adblockEnabled: false,
    ytAdblock: false,
    ytNetwork: false,
    adblockCustom: [],
    adblockHide: [],
    adblockAllow: []
  });
  $('mediaDetect').checked = s.mediaDetect;
  $('mediaAutoCopy').checked = s.mediaAutoCopy !== false;
  $('mediaAutoCopyReset').checked = s.mediaAutoCopyReset !== false;
  $('mediaSwitchOnce').checked = s.mediaSwitchOnce !== false;
  $('mediaKeywordEnabled').checked = !!s.mediaKeywordEnabled;
  $('mediaKeywordPageKeywords').value = toText(s.mediaKeywordPageKeywords);
  $('mediaKeywordLinkKeywords').value = toText(s.mediaKeywordLinkKeywords);
  $('mediaKeywordDelayMs').value = s.mediaKeywordDelayMs;
  $('mediaKeywordCaseSensitive').value = String(s.mediaKeywordCaseSensitive);
  $('mediaKeywordClickOnce').checked = s.mediaKeywordClickOnce !== false;
  $('mediaKeywordTriggerOnce').checked = s.mediaKeywordTriggerOnce !== false;
  $('mediaKeywordOnlyOpenedTabs').checked = !!s.mediaKeywordOnlyOpenedTabs;
  $('dlFolder').value = s.dlFolder;
  $('dlSaveAs').checked = !!s.dlSaveAs;
  $('adblockEnabled').checked = s.adblockEnabled;
  $('ytAdblock').checked = !!s.ytAdblock;
  $('ytNetwork').checked = !!s.ytNetwork;
  $('adblockCustom').value = toText(s.adblockCustom);
  $('adblockHide').value = (s.adblockHide || []).join('\n');
  $('adblockAllow').value = toText(s.adblockAllow);
  $('hotkeyOpener').value = hotkeyText(s.hotkeyOpener);
  $('hotkeyKeyword').value = hotkeyText(s.hotkeyKeyword);

  $('selector').value = s.openerSelector;
  $('delay').value = s.openerDelay;
  $('max').value = s.openerMax;
  $('openerMark').checked = s.openerMark !== false;
  $('openerSkipVisited').checked = !!s.openerSkipVisited;
  $('openerMarkExclude').value = toText(s.openerMarkExclude);
  $('pickerText').checked = s.pickerText !== false;
  $('pickerTextLen').value = s.pickerTextLen;
  $('pickerUrl').checked = !!s.pickerUrl;
  $('pickerUrlKey').value = s.pickerUrlKey || 'u';
  refreshExcludeButton();
  showVisitedCount();

  $('enabled').checked = s.enabled;
  $('allTabs').checked = s.allTabs;
  $('onlyOpenedTabs').checked = s.onlyOpenedTabs;
  $('pageKeywords').value = toText(s.pageKeywords);
  $('linkKeywords').value = toText(s.linkKeywords);
  $('delayMs').value = s.delayMs;
  $('clickOnce').checked = s.clickOnce;
  $('triggerOnce').checked = s.triggerOnce !== false;
  $('scanOncePerPage').checked = s.scanOncePerPage;
  $('caseSensitive').value = String(s.caseSensitive);
  updateHint();

  document.querySelector(`.tab[data-view="${s.lastView}"]`)?.click();
  previewCount();
  renderMedia();
  loadQueue();

  const cmds = await chrome.commands.getAll();
  const show = (name, id) => {
    const c = cmds.find((x) => x.name === name);
    $(id).textContent = c?.shortcut ? `快捷鍵：${c.shortcut}` : '快捷鍵：尚未設定（chrome://extensions/shortcuts）';
  };
  show('run-opener', 'openerShortcut');
  show('toggle-keyword', 'keywordShortcut');
  show('toggle-picker', 'pickerShortcut');
}
init();


/* ===== 版本一致性檢查：背景程式與彈出視窗必須是同一版 ===== */
(async () => {
  let sw = null;
  try { sw = await chrome.runtime.sendMessage({ type: 'build-check' }); } catch { /* 舊版背景程式不認得此訊息 */ }
  if (sw && sw.build === BUILD) return;
  const box = $('buildWarn');
  box.textContent = `⚠ 背景程式與彈出視窗不是同一版（背景：${sw?.build || '舊版或無回應'}／彈出視窗：${BUILD}）。` +
    '請到 chrome://extensions 移除 JavPop，刪除舊資料夾，改用重新解壓縮的完整資料夾載入；解壓縮時請選「全部覆蓋」，不要跳過檔案。';
  box.hidden = false;
})();
