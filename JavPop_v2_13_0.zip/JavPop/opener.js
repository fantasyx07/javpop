// 列表頁：依序把圖片連結送到背景分頁開啟，並在頁面上標示已開啟／點擊過的連結（所有網站）
(() => {
  let running = false;
  let timer = null;

  // ---------- 已開啟紀錄 ----------
  const VISITED_KEY = 'openerVisited';
  const VISITED_LIMIT = 5000; // 最多保留筆數，超過時刪除最舊的
  let visited = {};           // { 網址: 時間戳 }
  let markEnabled = true;     // 在頁面標示已開啟的連結
  let skipVisited = false;    // 批次開啟時略過已開啟的連結
  let selectorCache = 'a:has(img)';
  let markExclude = [];       // 例外網站：不標示 ✓、不記錄手動點擊

  const isExcludedHere = () => {
    const h = location.hostname.toLowerCase().replace(/^www\./, '');
    return markExclude.some((d) => h === d || h.endsWith('.' + d));
  };

  const norm = (url) => {
    try { const u = new URL(url, location.href); u.hash = ''; return u.href; } catch { return ''; }
  };
  const isVisited = (url) => !!visited[norm(url)];

  chrome.storage.local.get(
    { [VISITED_KEY]: {}, openerMark: true, openerSkipVisited: false, openerSelector: 'a:has(img)', openerMarkExclude: [] },
    (v) => {
      visited = v[VISITED_KEY] || {};
      markEnabled = v.openerMark !== false;
      skipVisited = !!v.openerSkipVisited;
      selectorCache = v.openerSelector || selectorCache;
      markExclude = v.openerMarkExclude || [];
      refreshMarks();
    });

  chrome.storage.onChanged.addListener((c, area) => {
    if (area !== 'local') return;
    if (c[VISITED_KEY]) visited = c[VISITED_KEY].newValue || {};
    if (c.openerMark) markEnabled = c.openerMark.newValue !== false;
    if (c.openerSkipVisited) skipVisited = !!c.openerSkipVisited.newValue;
    if (c.openerSelector) selectorCache = c.openerSelector.newValue || selectorCache;
    if (c.openerMarkExclude) markExclude = c.openerMarkExclude.newValue || [];
    if (c[VISITED_KEY] || c.openerMark || c.openerSelector || c.openerMarkExclude) refreshMarks();
  });

  // 讀取最新紀錄後合併再寫入，避免多個分頁互相覆蓋
  async function recordVisited(urls) {
    const keys = urls.map(norm).filter(Boolean);
    if (!keys.length) return;
    const now = Date.now();
    const cur = (await chrome.storage.local.get({ [VISITED_KEY]: {} }))[VISITED_KEY] || {};
    keys.forEach((k) => { cur[k] = now; });
    const entries = Object.entries(cur);
    if (entries.length > VISITED_LIMIT) {
      entries.sort((a, b) => a[1] - b[1]);
      entries.slice(0, entries.length - VISITED_LIMIT).forEach(([k]) => delete cur[k]);
    }
    visited = cur;
    await chrome.storage.local.set({ [VISITED_KEY]: cur });
    refreshMarks();
  }

  // ---------- 頁面標示 ----------
  const STYLE_ID = 'javpop-visited-style';
  function injectStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const st = document.createElement('style');
    st.id = STYLE_ID;
    st.textContent = `
      a.javpop-visited { position: relative; }
      a.javpop-visited img { outline: 3px solid #f59e0b !important; outline-offset: -3px; filter: grayscale(.55) brightness(.8) !important; }
      a.javpop-visited:has(img)::after {
        content: "✓"; position: absolute; top: 6px; left: 6px; z-index: 5; pointer-events: none;
        min-width: 22px; padding: 1px 6px; text-align: center; border-radius: 999px; background: #f59e0b; color: #fff;
        font: 700 12px/1.6 system-ui, "Microsoft JhengHei", sans-serif; box-shadow: 0 1px 4px rgba(0,0,0,.4);
      }
      a.javpop-visited:not(:has(img))::before { content: "✓ "; color: #f59e0b; font-weight: 700; }
      a.javpop-visited:not(:has(img)) { opacity: .65; text-decoration-style: dashed; }
      #javpop-visited-pill {
        position: fixed; right: 14px; bottom: 14px; z-index: 2147483647; pointer-events: none;
        padding: 6px 12px; border-radius: 999px; background: rgba(23,32,51,.88); color: #fff;
        font: 600 13px/1.4 system-ui, "Microsoft JhengHei", sans-serif; box-shadow: 0 2px 8px rgba(0,0,0,.35);
      }
      #javpop-visited-pill b { color: #fbbf24; }
    `;
    (document.head || document.documentElement).appendChild(st);
  }

  function matchingLinks() {
    try { return [...document.querySelectorAll(selectorCache)].filter((a) => a.tagName === 'A' && a.href); }
    catch { return []; }
  }

  function refreshMarks() {
    document.querySelectorAll('a.javpop-visited').forEach((a) => a.classList.remove('javpop-visited'));
    const pill = document.getElementById('javpop-visited-pill');
    if (!markEnabled || isExcludedHere()) {
      pill?.remove();
      document.getElementById(STYLE_ID)?.remove();
      return;
    }
    injectStyle();
    const seen = new Set();
    const seenVisited = new Set();
    matchingLinks().forEach((a) => {
      const k = norm(a.href);
      if (!k) return;
      seen.add(k);
      if (visited[k]) { a.classList.add('javpop-visited'); seenVisited.add(k); }
    });
    if (!seenVisited.size) { pill?.remove(); return; } // 本頁沒有標示時不顯示計數
    const el = pill || Object.assign(document.createElement('div'), { id: 'javpop-visited-pill' });
    el.innerHTML = `✓ <b>${seenVisited.size}</b> / ${seen.size}`;
    if (!pill) document.documentElement.appendChild(el);
  }

  // 頁面內容動態載入（無限捲動等）時重新標示
  let markTimer = null;
  new MutationObserver((muts) => {
    if (muts.every((m) => m.target.id === 'javpop-visited-pill' || m.target.nodeName === 'STYLE')) return;
    clearTimeout(markTimer);
    markTimer = setTimeout(refreshMarks, 400);
  }).observe(document.documentElement, { childList: true, subtree: true });

  // 手動點擊（左鍵／中鍵／Ctrl+點擊）也算已開啟
  const onUserClick = (e) => {
    if (!e.isTrusted || isExcludedHere()) return; // 例外網站不記錄手動點擊
    const a = e.target?.closest?.('a[href]');
    if (!a || !a.href.startsWith('http')) return;
    if (!matchingLinks().includes(a)) return; // 只記錄符合選擇器的連結（列表中的圖片連結）
    recordVisited([a.href]);
  };
  document.addEventListener('click', onUserClick, true);
  document.addEventListener('auxclick', onUserClick, true);

  // ---------- 批次開啟 ----------
  const setState = (value) => {
    running = value;
    chrome.runtime.sendMessage({ type: 'opener-state', running: value }).catch?.(() => {});
  };

  function collect(selector, { skip = false } = {}) {
    const seen = new Set();
    const out = [];
    let skipped = 0;
    let nodes;
    try {
      nodes = document.querySelectorAll(selector);
    } catch {
      return { links: out, skipped }; // 無效的選擇器
    }
    nodes.forEach((a) => {
      const href = a.href;
      if (!href || !href.startsWith('http')) return;
      if (href === location.href || href.includes('#')) return;
      if (/\/(page|category|tag)\//.test(href)) return; // 略過分頁、分類連結
      if (seen.has(href)) return;
      seen.add(href);
      if (skip && isVisited(href)) { skipped++; return; }
      out.push(href);
    });
    return { links: out, skipped };
  }

  function stop() {
    clearTimeout(timer);
    if (running) setState(false);
  }

  function start({ selector, delay, max }) {
    stop();
    selectorCache = selector || selectorCache;
    const { links: all, skipped } = collect(selector, { skip: skipVisited });
    const links = all.slice(0, max);
    if (!links.length) { refreshMarks(); return { ok: false, count: 0, skipped }; }
    setState(true);
    let i = 0;
    const next = () => {
      if (!running) return;
      if (i >= links.length) {
        setState(false);
        return;
      }
      const url = links[i++];
      chrome.runtime.sendMessage({ type: 'open', url });
      recordVisited([url]);
      timer = setTimeout(next, delay);
    };
    next();
    return { ok: true, count: links.length, skipped };
  }


  // ---- 自訂快捷鍵（頁面內）----
  const matchHotkey = (e, hk) => !!hk && e.code === hk.code &&
    e.ctrlKey === !!hk.ctrl && e.altKey === !!hk.alt && e.shiftKey === !!hk.shift && e.metaKey === !!hk.meta;
  const inEditable = (e) => {
    const t = e.target;
    return t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName));
  };

  let hotkey = null;
  chrome.storage.local.get({ hotkeyOpener: null }, (v) => { hotkey = v.hotkeyOpener; });
  chrome.storage.onChanged.addListener((c, area) => {
    if (area === 'local' && c.hotkeyOpener) hotkey = c.hotkeyOpener.newValue || null;
  });
  document.addEventListener('keydown', (e) => {
    if (!hotkey || e.repeat || inEditable(e) || !matchHotkey(e, hotkey)) return;
    e.preventDefault();
    if (running) { stop(); return; }
    chrome.storage.local.get({ openerSelector: 'a:has(img)', openerDelay: 1500, openerMax: 20 }, (c) => {
      start({ selector: c.openerSelector, delay: c.openerDelay, max: c.openerMax });
    });
  }, true);

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === 'opener-start') sendResponse(start(msg));
    else if (msg.type === 'opener-toggle') {
      if (running) { stop(); sendResponse({ ok: true, stopped: true }); }
      else sendResponse(start(msg));
    }
    else if (msg.type === 'opener-stop') { stop(); sendResponse({ ok: true }); }
    else if (msg.type === 'opener-count') {
      const { links, skipped } = collect(msg.selector, { skip: skipVisited });
      sendResponse({ count: links.length, skipped });
    }
    else return false;
    return true;
  });
})();
