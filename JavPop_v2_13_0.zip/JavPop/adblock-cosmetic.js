// 廣告阻擋：頁面內隱藏常見廣告元素，並通知 popup-guard.js 攔截彈出視窗
(() => {
  const SELECTORS = [
    'ins.adsbygoogle', '.adsbygoogle', '[id^="google_ads_"]', '[id^="div-gpt-ad"]',
    'iframe[src*="doubleclick.net"]', 'iframe[src*="googlesyndication.com"]',
    'iframe[src*="exoclick.com"]', 'iframe[src*="exosrv.com"]', 'iframe[src*="magsrv.com"]',
    'iframe[src*="juicyads.com"]', 'iframe[src*="trafficjunky"]', 'iframe[src*="adsterra"]',
    'iframe[src*="highperformanceformat.com"]', 'iframe[src*="realsrv.com"]',
    'a[href*="exoclick.com"]', 'a[href*="juicyads.com"]', 'a[href*="trafficjunky"]',
    '.advertisement', '.ad-banner', '.banner-ads'
  ];
  const STYLE_ID = 'jp-adblock-style';

  const topHost = () => {
    const o = location.ancestorOrigins;
    try { return o && o.length ? new URL(o[o.length - 1]).hostname : location.hostname; }
    catch { return location.hostname; }
  };
  const isAllowed = (list) => {
    const h = topHost();
    return (list || []).some((d) => h === d || h.endsWith('.' + d));
  };

  // 自訂隱藏規則（uBlock 式語法）：`網站##選擇器`，網站可留空（所有網站）或以逗號列出多個
  // 每筆規則獨立成一條 CSS，其中一筆無效時不會影響其他規則
  function customCss(rules) {
    const h = location.hostname.toLowerCase();
    const out = [];
    for (const raw of rules || []) {
      const i = String(raw).indexOf('##');
      if (i < 0) continue;
      const hosts = raw.slice(0, i).split(',').map((x) => x.trim().toLowerCase()).filter(Boolean);
      const sel = raw.slice(i + 2).trim();
      if (!sel) continue;
      if (hosts.length && !hosts.some((d) => h === d || h.endsWith('.' + d))) continue;
      out.push(`${sel} { display: none !important; }`);
    }
    return out.join('\n');
  }

  function apply(s) {
    const root = document.documentElement;
    if (!root) return;
    const on = !!s.adblockEnabled && !isAllowed(s.adblockAllow);
    let el = document.getElementById(STYLE_ID);
    if (on) {
      root.dataset.jpAdblock = '1';
      const css = SELECTORS.join(',\n') + ' { display: none !important; }\n' + customCss(s.adblockHide);
      if (!el) {
        el = document.createElement('style');
        el.id = STYLE_ID;
        (document.head || root).appendChild(el);
      }
      if (el.textContent !== css) el.textContent = css;
    } else {
      delete root.dataset.jpAdblock;
      el?.remove();
    }
  }

  const load = () => chrome.storage.local.get({ adblockEnabled: false, adblockAllow: [], adblockHide: [] }, apply);
  load();
  chrome.storage.onChanged.addListener((c, area) => {
    if (area === 'local' && (c.adblockEnabled || c.adblockAllow || c.adblockHide)) load();
  });
})();
