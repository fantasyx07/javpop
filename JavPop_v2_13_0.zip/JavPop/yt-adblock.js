// YouTube 廣告阻擋（隔離環境）：隱藏廣告區塊、廣告播放時自動跳過／快轉、清除「廣告阻擋器」警告彈窗
// 與 yt-adblock-main.js（頁面環境）搭配；後者負責移除播放器資料裡的廣告欄位
(() => {
  const SELECTORS = [
    '#masthead-ad', '#player-ads', '.video-ads.ytp-ad-module',
    '.ytp-ad-overlay-container', '.ytp-ad-overlay-slot', '.ytp-ad-image-overlay', '.ytp-ad-text-overlay',
    'ytd-ad-slot-renderer', 'ytd-in-feed-ad-layout-renderer', 'ytd-banner-promo-renderer', 'ytd-statement-banner-renderer',
    'ytd-promoted-sparkles-web-renderer', 'ytd-promoted-sparkles-text-search-renderer', 'ytd-promoted-video-renderer',
    'ytd-display-ad-renderer', 'ytd-primetime-promo-renderer', 'ytd-companion-slot-renderer', 'ytd-action-companion-ad-renderer',
    'ytd-player-legacy-desktop-watch-ads-renderer', 'ytd-mealbar-promo-renderer', 'ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-ads"]',
    'ytd-rich-item-renderer:has(> #content > ytd-ad-slot-renderer)', 'ytd-rich-item-renderer:has(ytd-ad-slot-renderer)',
    'ytd-rich-section-renderer:has(ytd-statement-banner-renderer)', 'ytd-rich-section-renderer:has(ytd-ad-slot-renderer)',
    'ytm-promoted-sparkles-web-renderer', 'ytm-companion-ad-renderer'
  ];
  const SKIP_BUTTONS = ['.ytp-skip-ad-button', '.ytp-ad-skip-button', '.ytp-ad-skip-button-modern', '.ytp-ad-skip-button-container button'];
  const STYLE_ID = 'jp-yt-adblock-style';

  let on = false;
  let timer = null;
  let saved = null; // { muted, rate }：廣告開始前的靜音與速度，廣告結束後還原

  const mainPlayer = () => document.querySelector('#movie_player') || document.querySelector('.html5-video-player');

  function skipAd(player) {
    // 1. 可跳過的廣告：直接按「略過」
    for (const sel of SKIP_BUTTONS) {
      const b = player.querySelector(sel);
      if (b) { b.click(); break; }
    }
    // 2. 其餘廣告：靜音並把廣告影片快轉到結尾
    const video = player.querySelector('video.html5-main-video') || player.querySelector('video');
    if (!video) return;
    if (!saved) saved = { muted: video.muted, rate: video.playbackRate };
    try {
      video.muted = true;
      video.playbackRate = 16;
      if (Number.isFinite(video.duration) && video.duration > 0 && video.currentTime < video.duration - 0.2) {
        video.currentTime = video.duration;
      }
    } catch { /* 影片尚未就緒，下一輪再試 */ }
  }

  function restore(player) {
    if (!saved) return;
    const video = player?.querySelector('video.html5-main-video') || player?.querySelector('video');
    if (video) {
      try { video.muted = saved.muted; video.playbackRate = saved.rate || 1; } catch { /* ignore */ }
    }
    saved = null;
  }

  // 「廣告阻擋器違反規定」警告彈窗：移除彈窗與遮罩，並讓影片繼續播放
  function clearEnforcement() {
    const enf = document.querySelector('ytd-enforcement-message-view-model');
    if (!enf) return;
    (enf.closest('tp-yt-paper-dialog') || enf).remove();
    document.querySelectorAll('tp-yt-iron-overlay-backdrop').forEach((n) => n.remove());
    document.documentElement.style.overflow = '';
    if (document.body) document.body.style.overflow = '';
    const v = document.querySelector('video.html5-main-video') || document.querySelector('video');
    if (v && v.paused) v.play().catch(() => {});
  }

  function tick() {
    if (!on) return;
    clearEnforcement();
    document.querySelectorAll('.ytp-ad-overlay-close-button').forEach((b) => b.click());
    const player = mainPlayer();
    if (!player) return;
    const adShowing = player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting');
    if (adShowing) skipAd(player);
    else restore(player);
  }

  function setStyle(enabled) {
    let el = document.getElementById(STYLE_ID);
    if (!enabled) { el?.remove(); return; }
    if (!el) {
      el = document.createElement('style');
      el.id = STYLE_ID;
      // 每個選擇器獨立成一條規則：:has() 等不被支援時不會連累其他規則
      el.textContent = SELECTORS.map((s) => `${s} { display: none !important; }`).join('\n');
      (document.head || document.documentElement).appendChild(el);
    }
  }

  function apply(s) {
    if (!document.documentElement) { document.addEventListener('DOMContentLoaded', () => apply(s), { once: true }); return; }
    on = !!s.ytAdblock;
    if (on) {
      delete document.documentElement.dataset.jpYtAdblockOff; // yt-adblock-main.js 預設就是啟用的
      setStyle(true);
      if (!timer) timer = setInterval(tick, 250);
    } else {
      document.documentElement.dataset.jpYtAdblockOff = '1'; // 已載入的頁面中即時停用 yt-adblock-main.js
      setStyle(false);
      clearInterval(timer);
      timer = null;
      restore(mainPlayer());
    }
  }

  const load = () => chrome.storage.local.get({ ytAdblock: false }, apply);
  load();
  chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && c.ytAdblock) load(); });
})();
