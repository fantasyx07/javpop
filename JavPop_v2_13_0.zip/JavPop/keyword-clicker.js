(() => {
  const DEFAULT_SETTINGS = {
    enabled: false, allTabs: true, pageKeywords: [], linkKeywords: [], delayMs: 500,
    clickOnce: true, scanOncePerPage: true, caseSensitive: false, onlyOpenedTabs: false,
    targetTabId: null, mediaKeywordEnabled: false, mediaKeywordPageKeywords: [],
    mediaKeywordLinkKeywords: [], mediaKeywordDelayMs: 500, mediaKeywordCaseSensitive: false,
    mediaKeywordClickOnce: true, mediaKeywordOnlyOpenedTabs: false,
    triggerOnce: true, mediaKeywordTriggerOnce: true
  };

  let settings = { ...DEFAULT_SETTINGS };
  let alreadyClicked = false;
  let mediaAlreadyClicked = false;
  let timer = null;
  let observer = null;
  let isSubFrame = false;
  try { isSubFrame = window.top !== window; } catch { isSubFrame = true; }

  const splitKeywords = (items) => items
    .flatMap((item) => String(item || '').split(/[\n,，、]+/))
    .map((item) => item.trim()).filter(Boolean);
  const norm = (value, caseSensitive) => {
    const text = String(value || '').trim();
    return caseSensitive ? text : text.toLocaleLowerCase();
  };
  const pageText = () => (document.body?.innerText || document.documentElement?.innerText || '');
  const pageHasTrigger = (config) => {
    const text = norm(pageText(), config.caseSensitive);
    const keywords = splitKeywords(config.pageKeywords).map((x) => norm(x, config.caseSensitive));
    return keywords.length === 0 || keywords.some((keyword) => text.includes(keyword));
  };
  const isVisible = (element) => {
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
  };
  const findLink = (config) => {
    const keywords = splitKeywords(config.linkKeywords).map((x) => norm(x, config.caseSensitive));
    const links = [...document.querySelectorAll('a[href]')].filter(isVisible);
    const matches = (link, keyword) => norm(
      `${link.innerText || ''} ${link.textContent || ''} ${link.getAttribute('aria-label') || ''} ${link.href || ''}`,
      config.caseSensitive
    ).includes(keyword);
    if (keywords.length === 0) return links[0];
    return keywords.reduce((selected, keyword) => selected || links.find((link) => matches(link, keyword)), null);
  };
  const clickMediaPlayer = (attempt = 0) => {
    const visible = (el) => el && isVisible(el) && !el.disabled;
    const selectors = [
      '.vjs-play-control', '.vjs-big-play-button', '.plyr__control--overlaid',
      '.jw-icon-playback', '.jw-display-icon-container', '.video-js button[title*="Play"]',
      '[aria-label*="Play" i]', '[aria-label*="再生" i]', '[title*="Play" i]',
      '[title*="再生" i]', 'button[class*="play" i]', '[class*="play-button" i]'
    ];
    const buttons = selectors.flatMap((selector) => [...document.querySelectorAll(selector)]).filter(visible);
    const mediaNodes = [...document.querySelectorAll('video, audio')];
    const loaded = mediaNodes.some((media) => media.readyState >= 2 || media.currentSrc || media.src);
    // ST 頁面常先建立播放器外框，再延遲載入實際影片；至少等幾次輪詢後才按 Play。
    if (!loaded && !buttons.length && attempt < 6) return false;
    if (!loaded && attempt < 3) return false;
    if (buttons[0]) { buttons[0].click(); return true; }
    let started = false;
    mediaNodes.forEach((media) => {
      if (visible(media) && media.paused) {
        const result = media.play();
        if (result?.catch) result.catch(() => {});
        started = true;
      }
    });
    return started;
  };
  const assistMediaPlayback = (attempt = 0) => {
    if (!settings.mediaKeywordEnabled || attempt > 40) {
      if (attempt > 40) ask({ type: 'media-debug', event: 'player-timeout', details: { attempts: attempt } });
      return;
    }
    const started = clickMediaPlayer(attempt);
    if (started) {
      ask({ type: 'media-debug', event: 'player-clicked', details: { attempt } });
      return;
    }
    setTimeout(() => assistMediaPlayback(attempt + 1), 500);
  };
  const scanSignature = (config, workflow) => JSON.stringify({
    workflow, linkKeywords: splitKeywords(config.linkKeywords), caseSensitive: config.caseSensitive
  });
  const ask = (message) => new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => { void chrome.runtime.lastError; resolve(response); });
  });

  const triggerBlocked = { keyword: false, media: false }; // 這個網址已觸發過，本次載入不再詢問

  const tryClick = async (workflow) => {
    if (triggerBlocked[workflow]) return;
    const media = workflow === 'media';
    const config = media ? {
      enabled: settings.mediaKeywordEnabled,
      pageKeywords: settings.mediaKeywordPageKeywords,
      linkKeywords: settings.mediaKeywordLinkKeywords,
      delayMs: settings.mediaKeywordDelayMs,
      clickOnce: settings.mediaKeywordClickOnce,
      caseSensitive: settings.mediaKeywordCaseSensitive
    } : settings;
    const clicked = media ? mediaAlreadyClicked : alreadyClicked;
    if (!config.enabled || (config.clickOnce && clicked) || !pageHasTrigger(config)) return;
    if ((await ask({ type: 'can-run-on-tab', workflow }))?.allowed !== true) return;
    const claim = await ask({
      type: 'claim-page-scan', workflow, url: location.href,
      scanSignature: scanSignature(config, workflow)
    });
    if (!claim?.allowed) return;
    const link = findLink(config);
    if (!link) return;
    // 同一個網址只觸發一次：已觸發過就不再點擊（重新整理、另開分頁也一樣）
    if ((media ? settings.mediaKeywordTriggerOnce : settings.triggerOnce) !== false) {
      const key = JSON.stringify([workflow, location.href.split('#')[0], splitKeywords(config.pageKeywords), splitKeywords(config.linkKeywords), !!config.caseSensitive]);
      if ((await ask({ type: 'claim-trigger', key }))?.allowed === false) { triggerBlocked[workflow] = true; return; }
    }
    if (media) mediaAlreadyClicked = true;
    else alreadyClicked = true;
    link.dataset.keywordAutoClicker = media ? 'media-clicked' : 'clicked';
    link.click();
    if (media) {
      await ask({ type: 'media-keyword-clicked' });
      setTimeout(() => assistMediaPlayback(), 800);
    }
  };

  const scheduleCheck = () => {
    clearTimeout(timer);
    const delays = [];
    if (settings.enabled) delays.push(Number(settings.delayMs) || 0);
    if (settings.mediaKeywordEnabled) delays.push(Number(settings.mediaKeywordDelayMs) || 0);
    if (!delays.length) return;
    timer = setTimeout(() => { tryClick('keyword'); tryClick('media'); }, Math.max(0, Math.min(...delays)));
  };
  const start = (nextSettings) => {
    settings = { ...DEFAULT_SETTINGS, ...nextSettings };
    alreadyClicked = false;
    triggerBlocked.keyword = false; triggerBlocked.media = false;
    mediaAlreadyClicked = !!settings.mediaPageLocked;
    observer?.disconnect();
    if (isSubFrame) return; // iframe 只接收 media-followup，避免重複執行頁面關鍵字點擊
    if (!settings.enabled && !settings.mediaKeywordEnabled) return;
    scheduleCheck();
    observer = new MutationObserver(() => {
      const regularReady = !settings.clickOnce || !alreadyClicked;
      const mediaReady = !settings.mediaKeywordClickOnce || !mediaAlreadyClicked;
      if (regularReady || mediaReady) scheduleCheck();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  };

  const matchHotkey = (e, hk) => !!hk && e.code === hk.code &&
    e.ctrlKey === !!hk.ctrl && e.altKey === !!hk.alt && e.shiftKey === !!hk.shift && e.metaKey === !!hk.meta;
  const inEditable = (e) => { const t = e.target; return t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)); };
  let hotkey = null;
  chrome.storage.local.get({ hotkeyKeyword: null }, (v) => { hotkey = v.hotkeyKeyword; });
  chrome.storage.onChanged.addListener((c, area) => {
    if (area === 'local' && c.hotkeyKeyword) hotkey = c.hotkeyKeyword.newValue || null;
  });
  document.addEventListener('keydown', (e) => {
    if (!hotkey || e.repeat || inEditable(e) || !matchHotkey(e, hotkey)) return;
    e.preventDefault(); chrome.runtime.sendMessage({ type: 'toggle-keyword' });
  }, true);

  chrome.runtime.sendMessage({ type: 'get-settings' }, (response) => {
    if (!chrome.runtime.lastError) start(response || DEFAULT_SETTINGS);
  });
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'settings-updated') start({ ...settings, ...message.settings });
    if (message.type === 'media-followup') {
      mediaAlreadyClicked = true;
      assistMediaPlayback();
    }
  });
})();
