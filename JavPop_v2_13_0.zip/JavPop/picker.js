// 元素選取器：進入選取模式後點擊頁面元素，把「編號＋CSS 選擇器＋文字」清單複製到剪貼簿，貼給 AI 就能精準指出要改哪裡
(() => {
  if (window.__javpopPicker) return; // 避免重複注入
  window.__javpopPicker = true;

  const cfg = { pickerText: true, pickerTextLen: 40, pickerUrl: false, pickerUrlKey: 'u' };
  chrome.storage.local.get(cfg, (v) => Object.assign(cfg, v));
  chrome.storage.onChanged.addListener((c, area) => {
    if (area !== 'local') return;
    for (const k of Object.keys(cfg)) if (c[k]) cfg[k] = c[k].newValue;
    if (active) { renderBar(); }
  });

  let active = false;
  let picks = [];       // { el, sel, text, box }
  let hover = null;     // 目前游標（或用 ↑↓ 調整後）的元素
  let stack = [];       // 往外層走時留下的路徑，讓 ↓ 能走回內層
  let pointer = { x: 0, y: 0 };
  let ui = null;        // { host, root, hl, tip, layer, bar, msg }
  let msgTimer = null;
  let rafId = 0;

  /* ---------- CSS 選擇器（做法類似 DevTools「Copy selector」） ---------- */
  const esc = (s) => (window.CSS && CSS.escape ? CSS.escape(s) : String(s).replace(/[^\w-]/g, '\\$&'));

  function part(el, isTarget, forceNth) {
    if (el.id) {
      const s = `#${esc(el.id)}`;
      try { if (document.querySelectorAll(s).length === 1) return { sel: s, stop: true }; } catch { /* 略過 */ }
    }
    const tag = el.localName;
    let s = tag;
    if (isTarget) s += [...el.classList].map((c) => `.${esc(c)}`).join('');
    const parent = el.parentElement;
    if (parent) {
      const same = [...parent.children].filter((c) => c.localName === tag);
      if (same.length > 1 || forceNth) s += `:nth-child(${[...parent.children].indexOf(el) + 1})`;
    }
    return { sel: s, stop: false };
  }

  function selectorOf(el) {
    let last = '';
    for (const forceNth of [false, true]) {
      const parts = [];
      for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
        const { sel, stop } = part(n, n === el, forceNth);
        parts.unshift(sel);
        if (stop || n === document.body || n === document.documentElement) break;
      }
      last = parts.join(' > ');
      try { if (document.querySelector(last) === el) return last; } catch { /* 略過 */ }
    }
    return last;
  }

  const textOf = (el) => {
    const t = (el.innerText || el.textContent || el.getAttribute('alt') || el.getAttribute('aria-label') || el.getAttribute('title') || '');
    return t.replace(/\s+/g, ' ').trim().slice(0, 500);
  };

  /* ---------- 輸出與複製 ---------- */
  function buildList() {
    const lines = [];
    if (cfg.pickerUrl) lines.push(location.href);
    const max = Math.min(200, Math.max(5, Number(cfg.pickerTextLen) || 40));
    picks.forEach((p, i) => {
      let line = `${i + 1}. ${p.sel}`;
      if (cfg.pickerText && p.text) {
        const t = p.text.length > max ? `${p.text.slice(0, max)}…` : p.text;
        line += ` "${t.replace(/"/g, "'")}"`;
      }
      lines.push(line);
    });
    return lines.join('\n');
  }

  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); return true; } catch { /* 改用備援 */ }
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.cssText = 'position:fixed;opacity:0;top:0;left:0;';
      document.documentElement.appendChild(ta);
      ta.select();
      const ok = document.execCommand('copy');
      ta.remove();
      if (ok) return true;
    } catch { /* 改用 offscreen */ }
    try {
      await chrome.runtime.sendMessage({ type: 'dl-ensure' });
      return !!(await chrome.runtime.sendMessage({ type: 'clip-copy', text }))?.ok;
    } catch { return false; }
  }

  async function copyPicks() {
    if (!picks.length) { flash('已取消全部選取'); return; }
    const ok = await copyText(buildList());
    flash(ok ? `✓ 已複製 ${picks.length} 個選擇器` : '複製失敗，請確認剪貼簿權限');
  }

  /* ---------- 畫面 ---------- */
  function buildUI() {
    const host = document.createElement('div');
    host.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;';
    const root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = `
      <style>
        * { box-sizing: border-box; }
        .hl { position: fixed; display: none; border: 2px solid #596fff; background: rgba(89,111,255,.16); border-radius: 2px; }
        .tip { position: fixed; display: none; max-width: min(60vw, 560px); padding: 3px 8px; border-radius: 6px; background: #172033; color: #e2e8f0;
               font: 12px/1.5 ui-monospace, Consolas, monospace; word-break: break-all; box-shadow: 0 2px 8px rgba(0,0,0,.4); }
        .box { position: fixed; border: 2px solid #f59e0b; background: rgba(245,158,11,.14); border-radius: 2px; }
        .badge { position: absolute; top: -2px; left: -2px; min-width: 20px; height: 20px; padding: 0 5px; border-radius: 0 0 8px 0; background: #f59e0b; color: #fff;
                 font: 700 12px/20px system-ui, sans-serif; text-align: center; }
        .bar { position: fixed; left: 50%; bottom: 14px; transform: translateX(-50%); display: flex; flex-direction: column; gap: 4px; align-items: center;
               width: max-content; max-width: calc(100vw - 24px); padding: 8px 12px; border-radius: 12px; background: rgba(23,32,51,.95); color: #fff;
               font: 13px/1.5 system-ui, "Microsoft JhengHei", sans-serif; box-shadow: 0 4px 16px rgba(0,0,0,.45); pointer-events: auto; }
        .row { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; justify-content: center; }
        .hint { font-size: 11px; color: #94a3b8; }
        .msg { min-height: 18px; font-size: 12px; font-weight: 700; color: #6ee7a8; }
        b { color: #fbbf24; }
        button { all: unset; cursor: pointer; padding: 2px 10px; border-radius: 6px; background: #3b4560; color: #fff; font-size: 12px; }
        button:hover { background: #596fff; }
        button.end { background: #d64545; }
      </style>
      <div class="hl"></div><div class="layer"></div><div class="tip"></div>
      <div class="bar">
        <div class="row"><span>🎯 選取模式</span><span class="count"></span><span class="url"></span>
          <button class="clear" type="button">清除</button><button class="end" type="button">結束</button></div>
        <div class="row"><button class="hide" type="button" title="把選取的元素加入廣告阻擋的隱藏規則（只對此網站）；快速鍵 H">🚫 隱藏選取元素 (H)</button>
          <button class="blockdom" type="button" title="把選取元素載入的第三方網域加入封鎖清單；快速鍵 B">🌐 封鎖來源網域 (B)</button></div>
        <div class="msg"></div>
        <div class="hint">點擊元素加入／再點一次取消 · ↑ 外層　↓ 內層 · Esc 結束</div>
      </div>`;
    root.querySelector('.clear').addEventListener('click', () => { clearPicks(); flash('已清除'); });
    root.querySelector('.end').addEventListener('click', exit);
    root.querySelector('.hide').addEventListener('click', () => addToBlocklist('hide'));
    root.querySelector('.blockdom').addEventListener('click', () => addToBlocklist('domain'));
    return {
      host, root,
      hl: root.querySelector('.hl'), tip: root.querySelector('.tip'), layer: root.querySelector('.layer'),
      bar: root.querySelector('.bar'), msg: root.querySelector('.msg')
    };
  }

  function renderBar() {
    if (!ui) return;
    const key = String(cfg.pickerUrlKey || 'u').toUpperCase();
    ui.root.querySelector('.count').innerHTML = `已選 <b>${picks.length}</b>`;
    ui.root.querySelector('.url').innerHTML = `網址：<b>${cfg.pickerUrl ? '開' : '關'}</b>（${key}）`;
  }

  function flash(text, ms = 2500) {
    if (!ui) return;
    ui.msg.textContent = text;
    clearTimeout(msgTimer);
    msgTimer = setTimeout(() => { if (ui) ui.msg.textContent = ''; }, ms);
  }

  /* ---------- 加入廣告阻擋清單 ---------- */
  const pageHost = () => location.hostname.replace(/^www\./, '').toLowerCase();

  // 選取元素（含子孫）載入資源的第三方網域，排除與目前網站同源的網域
  function sourceDomains(els) {
    const page = pageHost();
    const set = new Set();
    const add = (u) => {
      try {
        const h = new URL(u, location.href).hostname.replace(/^www\./, '').toLowerCase();
        if (h && h !== page && !page.endsWith(`.${h}`) && !h.endsWith(`.${page}`) && /^[a-z0-9.-]+\.[a-z]{2,}$/.test(h)) set.add(h);
      } catch { /* 略過 data: 等無法解析的位址 */ }
    };
    els.forEach((el) => {
      [el, ...el.querySelectorAll('[src],[data-src]')].forEach((n) => {
        const a = n.getAttribute?.('src'); if (a) add(a);
        const b = n.getAttribute?.('data-src'); if (b) add(b);
        if (n.currentSrc) add(n.currentSrc);
      });
    });
    return [...set];
  }

  async function addToBlocklist(kind) {
    if (!picks.length) { flash('請先點選要阻擋的元素'); return; }
    const host = pageHost();
    const payload = { type: 'adblock-add', pageHost: host, rules: [], domains: [] };
    if (kind === 'hide') payload.rules = picks.map((p) => `${host}##${p.sel}`);
    else {
      payload.domains = sourceDomains(picks.map((p) => p.el));
      if (!payload.domains.length) { flash('選取的元素沒有第三方來源網域，可改用「隱藏選取元素」', 4000); return; }
    }
    let res = null;
    try { res = await chrome.runtime.sendMessage(payload); } catch { /* 背景程式沒有回應 */ }
    if (!res?.ok) { flash('加入失敗，請重新整理頁面或重新載入擴充功能後再試', 4000); return; }
    const parts = [];
    if (kind === 'hide') {
      parts.push(res.addedRules ? `已加入 ${res.addedRules} 筆隱藏規則` : '規則已存在');
      if (res.rejected) parts.push(`${res.rejected} 筆過於寬鬆已略過`);
    } else {
      parts.push(res.addedDomains.length ? `已封鎖 ${res.addedDomains.join('、')}` : '這些網域已在封鎖清單');
    }
    if (!res.enabled) parts.push('⚠ 廣告阻擋目前關閉，請先在廣告阻擋分頁開啟並儲存');
    clearPicks();
    flash(`✓ ${parts.join('，')}`, 5000);
  }

  const place = (node, r) => {
    node.style.left = `${r.left}px`; node.style.top = `${r.top}px`;
    node.style.width = `${r.width}px`; node.style.height = `${r.height}px`;
  };

  function frame() {
    if (!active || !ui) return;
    // 游標下的元素高亮與選擇器提示
    if (hover && hover.isConnected) {
      const r = hover.getBoundingClientRect();
      place(ui.hl, r);
      ui.hl.style.display = 'block';
      if (ui.tip.dataset.for !== String(hoverId)) {
        ui.tip.textContent = selectorOf(hover);
        ui.tip.dataset.for = String(hoverId);
      }
      ui.tip.style.display = 'block';
      const w = ui.tip.offsetWidth, h = ui.tip.offsetHeight;
      let x = Math.min(pointer.x + 14, window.innerWidth - w - 8);
      let y = pointer.y + 20;
      if (y + h > window.innerHeight - 8) y = pointer.y - h - 10;
      ui.tip.style.left = `${Math.max(4, x)}px`;
      ui.tip.style.top = `${Math.max(4, y)}px`;
    } else {
      ui.hl.style.display = 'none';
      ui.tip.style.display = 'none';
    }
    // 已選取元素的外框與編號
    picks.forEach((p) => {
      const r = p.el.isConnected ? p.el.getBoundingClientRect() : null;
      if (!r || (!r.width && !r.height)) { p.box.style.display = 'none'; return; }
      p.box.style.display = 'block';
      place(p.box, r);
    });
    rafId = requestAnimationFrame(frame);
  }

  let hoverId = 0;
  const setHover = (el) => { if (el !== hover) { hover = el; hoverId++; } };

  /* ---------- 選取 ---------- */
  function renumber() {
    picks.forEach((p, i) => { p.box.firstChild.textContent = String(i + 1); });
    renderBar();
  }

  function togglePick(el) {
    const i = picks.findIndex((p) => p.el === el);
    if (i >= 0) {
      picks[i].box.remove();
      picks.splice(i, 1);
    } else {
      const box = document.createElement('div');
      box.className = 'box';
      box.innerHTML = '<span class="badge"></span>';
      ui.layer.appendChild(box);
      picks.push({ el, sel: selectorOf(el), text: textOf(el), box });
    }
    renumber();
    copyPicks();
  }

  function clearPicks() {
    picks.forEach((p) => p.box.remove());
    picks = [];
    renumber();
  }

  /* ---------- 事件 ---------- */
  const isOurs = (e) => ui && e.target === ui.host;

  const onMove = (e) => {
    pointer = { x: e.clientX, y: e.clientY };
    if (isOurs(e)) { setHover(null); return; }
    const t = document.elementFromPoint(e.clientX, e.clientY);
    if (t === ui.host || !t) { setHover(null); return; }
    if (t !== hover && !stack.includes(t)) stack = [];
    setHover(t);
  };

  const block = (e) => {
    if (isOurs(e)) return; // 工具列自己的按鈕要能正常使用
    e.preventDefault();
    e.stopImmediatePropagation();
  };

  const onClick = (e) => {
    if (isOurs(e)) return;
    block(e);
    const el = hover || e.target;
    if (el && el.nodeType === 1) togglePick(el);
  };

  const onKey = (e) => {
    if (e.ctrlKey || e.altKey || e.metaKey) return; // 不干擾瀏覽器／擴充功能快捷鍵
    if (e.key === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); exit(); return; }
    if (e.key === 'ArrowUp') {
      e.preventDefault(); e.stopImmediatePropagation();
      if (hover?.parentElement) { stack.push(hover); setHover(hover.parentElement); }
      return;
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault(); e.stopImmediatePropagation();
      if (stack.length) setHover(stack.pop());
      return;
    }
    if (e.key.length === 1 && e.key.toLowerCase() === String(cfg.pickerUrlKey || 'u').toLowerCase()) {
      e.preventDefault(); e.stopImmediatePropagation();
      cfg.pickerUrl = !cfg.pickerUrl;
      chrome.storage.local.set({ pickerUrl: cfg.pickerUrl });
      renderBar();
      if (picks.length) copyPicks();
      else flash(`網址：${cfg.pickerUrl ? '開' : '關'}`);
      return;
    }
    // 快速鍵：H＝隱藏選取元素，B＝封鎖來源網域（與工具列按鈕相同）
    const k = e.key.toLowerCase();
    if (k === 'h' || k === 'b') {
      e.preventDefault(); e.stopImmediatePropagation();
      addToBlocklist(k === 'h' ? 'hide' : 'domain');
    }
  };

  const BLOCKED = ['mousedown', 'mouseup', 'pointerdown', 'pointerup', 'auxclick', 'dblclick'];

  function enter() {
    active = true;
    picks = []; hover = null; stack = [];
    ui = buildUI();
    document.documentElement.appendChild(ui.host);
    const st = document.createElement('style');
    st.id = 'javpop-picker-style';
    st.textContent = 'html, html * { cursor: crosshair !important; }';
    (document.head || document.documentElement).appendChild(st);
    window.addEventListener('mousemove', onMove, true);
    window.addEventListener('click', onClick, true);
    BLOCKED.forEach((t) => window.addEventListener(t, block, true));
    window.addEventListener('keydown', onKey, true);
    renderBar();
    rafId = requestAnimationFrame(frame);
  }

  function exit() {
    active = false;
    cancelAnimationFrame(rafId);
    window.removeEventListener('mousemove', onMove, true);
    window.removeEventListener('click', onClick, true);
    BLOCKED.forEach((t) => window.removeEventListener(t, block, true));
    window.removeEventListener('keydown', onKey, true);
    document.getElementById('javpop-picker-style')?.remove();
    ui?.host.remove();
    ui = null; picks = []; hover = null; stack = [];
  }

  chrome.runtime.onMessage.addListener((m, _sender, sendResponse) => {
    if (m.type !== 'picker-toggle') return false;
    if (active) exit(); else enter();
    sendResponse({ ok: true, active });
    return false;
  });
})();
