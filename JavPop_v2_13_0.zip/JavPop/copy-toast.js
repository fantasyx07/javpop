// 頁面提示：影片連結已自動複製到剪貼簿（含「關閉自動複製」按鈕）
(() => {
  let host = null;
  let hideTimer = null;

  const build = () => {
    host = document.createElement('div');
    host.style.cssText = 'all:initial;position:fixed;top:14px;right:14px;z-index:2147483647;';
    const root = host.attachShadow({ mode: 'closed' }); // 隔離樣式，避免被網頁 CSS 影響
    root.innerHTML = `
      <style>
        .t { box-sizing: border-box; width: 300px; max-width: calc(100vw - 28px); padding: 10px 12px; border-radius: 10px;
             background: rgba(23,32,51,.94); color: #fff; font: 13px/1.5 system-ui, "Microsoft JhengHei", sans-serif;
             box-shadow: 0 4px 16px rgba(0,0,0,.4); opacity: 0; transform: translateY(-6px); transition: opacity .2s, transform .2s; }
        .t.show { opacity: 1; transform: none; }
        .h { font-weight: 700; color: #6ee7a8; }
        .u { margin-top: 2px; color: #cbd5e1; font-size: 12px; word-break: break-all; display: -webkit-box;
             -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
        .b { margin-top: 6px; padding: 2px 10px; border: 0; border-radius: 6px; background: #3b4560; color: #fff;
             font: inherit; font-size: 12px; cursor: pointer; }
        .b:hover { background: #596fff; }
      </style>
      <div class="t"><div class="h"></div><div class="u"></div><button class="b" type="button">關閉自動複製</button></div>`;
    host.addEventListener('mouseenter', () => clearTimeout(hideTimer));
    host.addEventListener('mouseleave', () => schedule(1500));
    root.querySelector('.b').addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'autocopy-off' }, () => void chrome.runtime.lastError);
      root.querySelector('.h').textContent = '已關閉自動複製';
      root.querySelector('.u').textContent = '可在彈出視窗「影片」分頁重新開啟';
      root.querySelector('.b').remove();
      schedule(2500);
    });
    host.root = root;
    document.documentElement.appendChild(host);
  };

  const schedule = (ms) => {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => {
      host?.root.querySelector('.t')?.classList.remove('show');
      setTimeout(() => { host?.remove(); host = null; }, 250);
    }, ms);
  };

  chrome.runtime.onMessage.addListener((m) => {
    if (m.type !== 'copy-toast') return;
    if (host && !host.root.querySelector('.b')) { host.remove(); host = null; } // 上一個提示已被按過「關閉」，重新建立
    if (!host) build();
    const r = host.root;
    const kind = { hls: 'HLS 串流', dash: 'DASH 串流', file: '影片檔' }[m.kind] || '影片';
    r.querySelector('.h').textContent = `✓ 已複製${kind}連結到剪貼簿`;
    r.querySelector('.u').textContent = m.url;
    r.querySelector('.u').title = m.url;
    requestAnimationFrame(() => r.querySelector('.t').classList.add('show'));
    schedule(4500);
  });
})();
