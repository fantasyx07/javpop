// YouTube 廣告阻擋（頁面環境）：在播放器資料送到前端程式前，移除廣告欄位
// 此腳本只在「阻擋 YouTube 廣告」開啟時由背景程式註冊；使用者關閉後，已載入的頁面由 yt-adblock.js
// 設定 <html data-jp-yt-adblock-off="1"> 即時停用（頁面環境無法讀取 chrome.storage）
(() => {
  const FIELDS = ['adPlacements', 'playerAds', 'adSlots'];
  const enabled = () => document.documentElement?.dataset.jpYtAdblockOff !== '1';

  function strip(o) {
    try {
      if (!o || typeof o !== 'object') return o;
      for (const k of FIELDS) if (k in o) delete o[k];
      if (o.playerResponse && typeof o.playerResponse === 'object') {
        for (const k of FIELDS) if (k in o.playerResponse) delete o.playerResponse[k];
      }
    } catch { /* 物件被凍結等情況：略過 */ }
    return o;
  }

  // 1) JSON.parse：播放器回應多半經由它解析
  const nativeParse = JSON.parse;
  JSON.parse = function (...args) {
    const r = nativeParse.apply(this, args);
    return enabled() ? strip(r) : r;
  };

  // 2) fetch → response.json()：網站內換頁時的 /youtubei/v1/ 回應
  const nativeJson = Response.prototype.json;
  Response.prototype.json = function (...args) {
    const p = nativeJson.apply(this, args);
    if (!enabled() || !/\/youtubei\/v1\//.test(this.url || '')) return p;
    return p.then(strip);
  };

  // 3) 首次載入時網頁內嵌的 ytInitialPlayerResponse（是 JS 物件字面值，不會經過 JSON.parse）
  //    先在 window 上定義存取器，之後 `var ytInitialPlayerResponse = {...}` 的指派會經過 setter
  try {
    let value;
    Object.defineProperty(window, 'ytInitialPlayerResponse', {
      configurable: true,
      get() { return value; },
      set(v) { value = enabled() ? strip(v) : v; }
    });
  } catch { /* 屬性已存在：略過 */ }
})();
