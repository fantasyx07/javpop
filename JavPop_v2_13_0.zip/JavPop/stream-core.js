// 串流解析與下載核心：HLS(m3u8)／DASH(mpd) 解析、區段下載引擎、AES-128 解密
// 不依賴 DOM 與 chrome API，可在瀏覽器擴充頁面與 Node 中使用。
(function (root) {
  'use strict';

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const resolveUrl = (rel, base) => { try { return new URL(rel, base).href; } catch { return rel; } };

  /* ===================== 工具 ===================== */
  function formatBytes(n) {
    if (!n && n !== 0) return '';
    const u = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
    return `${n >= 100 || i === 0 ? Math.round(n) : n.toFixed(1)} ${u[i]}`;
  }

  function sanitizeFilename(name, fallback = 'video') {
    let s = String(name || '')
      .replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_')
      .replace(/\s+/g, ' ')
      .trim()
      .replace(/[. ]+$/, '');
    if (s.length > 120) s = s.slice(0, 120).trim();
    return s || fallback;
  }

  /* ===================== HLS ===================== */
  function parseAttrs(str) {
    const out = {};
    const re = /([A-Z0-9-]+)=("([^"]*)"|[^,]*)/g;
    let m;
    while ((m = re.exec(str))) out[m[1]] = m[3] !== undefined ? m[3] : m[2];
    return out;
  }

  function parseRange(v, lastEnd) {
    const [len, off] = String(v).split('@');
    const length = parseInt(len, 10);
    const offset = off !== undefined ? parseInt(off, 10) : lastEnd;
    return { length, offset };
  }

  function parseM3U8(text, baseUrl) {
    const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    if (!lines.length || !lines[0].startsWith('#EXTM3U')) throw new Error('不是有效的 m3u8 檔案');

    if (lines.some((l) => l.startsWith('#EXT-X-STREAM-INF'))) {
      const variants = [];
      const audioMedia = [];
      for (let i = 0; i < lines.length; i++) {
        const l = lines[i];
        if (l.startsWith('#EXT-X-STREAM-INF:')) {
          const a = parseAttrs(l.slice(18));
          let j = i + 1;
          while (j < lines.length && lines[j].startsWith('#')) j++;
          if (j >= lines.length) continue;
          variants.push({
            url: resolveUrl(lines[j], baseUrl),
            bandwidth: parseInt(a.BANDWIDTH || a['AVERAGE-BANDWIDTH'] || '0', 10),
            resolution: a.RESOLUTION || '',
            codecs: a.CODECS || '',
            audio: a.AUDIO || '',
            name: a.NAME || ''
          });
        } else if (l.startsWith('#EXT-X-MEDIA:')) {
          const a = parseAttrs(l.slice(13));
          if (a.TYPE === 'AUDIO' && a.URI) {
            audioMedia.push({
              group: a['GROUP-ID'] || '', name: a.NAME || '', lang: a.LANGUAGE || '',
              default: a.DEFAULT === 'YES', url: resolveUrl(a.URI, baseUrl)
            });
          }
        }
      }
      return { type: 'master', variants, audioMedia };
    }

    let seq = 0;
    let key = null;
    let map = null;
    let ended = false;
    let unsupported = null;
    let pendingDur = 0;
    let pendingRange = null;
    let lastEnd = 0;
    const segments = [];

    for (const l of lines) {
      if (l.startsWith('#EXT-X-MEDIA-SEQUENCE:')) seq = parseInt(l.slice(22), 10) || 0;
      else if (l.startsWith('#EXT-X-KEY:')) {
        const a = parseAttrs(l.slice(11));
        const method = (a.METHOD || 'NONE').toUpperCase();
        if (method === 'NONE') key = null;
        else if (method === 'AES-128') {
          if (a.KEYFORMAT && a.KEYFORMAT !== 'identity') unsupported = '此串流使用 DRM 保護，無法下載';
          else if (!a.URI) unsupported = '加密串流缺少金鑰位址';
          else key = { url: resolveUrl(a.URI, baseUrl), iv: a.IV || null };
        } else unsupported = `不支援的加密方式（${method}），無法下載`;
      } else if (l.startsWith('#EXT-X-MAP:')) {
        const a = parseAttrs(l.slice(11));
        if (a.URI) map = { url: resolveUrl(a.URI, baseUrl), range: a.BYTERANGE ? parseRange(a.BYTERANGE, 0) : null };
      } else if (l.startsWith('#EXT-X-BYTERANGE:')) {
        pendingRange = parseRange(l.slice(17), lastEnd);
        lastEnd = pendingRange.offset + pendingRange.length;
      } else if (l.startsWith('#EXTINF:')) pendingDur = parseFloat(l.slice(8)) || 0;
      else if (l.startsWith('#EXT-X-ENDLIST')) ended = true;
      else if (!l.startsWith('#')) {
        segments.push({
          url: resolveUrl(l, baseUrl), duration: pendingDur, seq: seq + segments.length,
          key, range: pendingRange
        });
        pendingDur = 0;
        pendingRange = null;
      }
    }
    return {
      type: 'media', segments, map, ended, unsupported,
      duration: segments.reduce((s, x) => s + x.duration, 0),
      encrypted: segments.some((s) => s.key)
    };
  }

  /* ===================== 簡易 XML（供 MPD 使用） ===================== */
  const decodeXml = (s) => String(s)
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');

  function parseXML(text) {
    text = text
      .replace(/<\?[\s\S]*?\?>/g, '')
      .replace(/<!--[\s\S]*?-->/g, '')
      .replace(/<!DOCTYPE[^>]*>/gi, '')
      .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, (_, t) => t.replace(/&/g, '&amp;').replace(/</g, '&lt;'));
    const rootEl = { name: '#root', attrs: {}, children: [], text: '' };
    const stack = [rootEl];
    const re = /<(\/?)([A-Za-z_][\w:.-]*)((?:\s+[\w:.-]+\s*=\s*(?:"[^"]*"|'[^']*'))*)\s*(\/?)>|([^<]+)/g;
    let m;
    while ((m = re.exec(text))) {
      if (m[5] !== undefined) { stack[stack.length - 1].text += m[5]; continue; }
      const name = m[2].replace(/^.*:/, '');
      if (m[1]) { if (stack.length > 1) stack.pop(); continue; }
      const attrs = {};
      const ar = /([\w:.-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g;
      let a;
      while ((a = ar.exec(m[3]))) attrs[a[1].replace(/^.*:/, '')] = decodeXml(a[2] !== undefined ? a[2] : a[3]);
      const el = { name, attrs, children: [], text: '' };
      stack[stack.length - 1].children.push(el);
      if (!m[4]) stack.push(el);
    }
    return rootEl.children[0];
  }

  /* ===================== DASH (MPD) ===================== */
  const kids = (el, name) => (el ? el.children.filter((c) => c.name === name) : []);
  const textOf = (el, name) => (kids(el, name)[0]?.text || '').trim();

  function isoDuration(s) {
    if (!s) return 0;
    const m = /^P(?:(\d+(?:\.\d+)?)D)?(?:T(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?)?$/.exec(s);
    if (!m) return 0;
    return (parseFloat(m[1]) || 0) * 86400 + (parseFloat(m[2]) || 0) * 3600 + (parseFloat(m[3]) || 0) * 60 + (parseFloat(m[4]) || 0);
  }

  function fillTemplate(t, vars) {
    return t
      .replace(/\$(RepresentationID|Number|Bandwidth|Time)(?:%0(\d+)d)?\$/g, (_, n, w) => {
        let v = String(vars[n]);
        if (w) v = v.padStart(parseInt(w, 10), '0');
        return v;
      })
      .replace(/\$\$/g, '$');
  }

  function parseMPD(text, baseUrl) {
    const mpd = parseXML(text);
    if (!mpd || mpd.name !== 'MPD') throw new Error('不是有效的 MPD 檔案');
    if (mpd.attrs.type === 'dynamic') return { type: 'mpd', tracks: [], unsupported: '直播（dynamic）MPD 不支援' };

    const total = isoDuration(mpd.attrs.mediaPresentationDuration);
    const period = kids(mpd, 'Period')[0];
    if (!period) throw new Error('MPD 沒有 Period');
    const periodDur = isoDuration(period.attrs.duration) || total;

    let base = resolveUrl(textOf(mpd, 'BaseURL') || '', baseUrl);
    base = resolveUrl(textOf(period, 'BaseURL') || '', base);

    const tracks = [];
    for (const as of kids(period, 'AdaptationSet')) {
      const asBase = resolveUrl(textOf(as, 'BaseURL') || '', base);
      const reps = kids(as, 'Representation');
      for (const rep of reps) {
        const mime = rep.attrs.mimeType || as.attrs.mimeType || '';
        const kind = as.attrs.contentType || rep.attrs.contentType || mime.split('/')[0] || 'video';
        if (kind !== 'video' && kind !== 'audio') continue; // 字幕等略過
        const repBase = resolveUrl(textOf(rep, 'BaseURL') || '', asBase);
        const drm = kids(as, 'ContentProtection').length > 0 || kids(rep, 'ContentProtection').length > 0;
        const id = rep.attrs.id || '';
        const bandwidth = parseInt(rep.attrs.bandwidth || '0', 10);
        const track = {
          id, kind, bandwidth, drm, mime,
          width: parseInt(rep.attrs.width || as.attrs.width || '0', 10),
          height: parseInt(rep.attrs.height || as.attrs.height || '0', 10),
          codecs: rep.attrs.codecs || as.attrs.codecs || '',
          lang: as.attrs.lang || '',
          init: null, segments: [], single: null
        };

        const st = kids(rep, 'SegmentTemplate')[0] || kids(as, 'SegmentTemplate')[0];
        const sl = kids(rep, 'SegmentList')[0] || kids(as, 'SegmentList')[0];
        if (st) {
          const timescale = parseInt(st.attrs.timescale || '1', 10) || 1;
          const startNumber = st.attrs.startNumber !== undefined ? parseInt(st.attrs.startNumber, 10) : 1;
          const vars = { RepresentationID: id, Bandwidth: bandwidth };
          if (st.attrs.initialization) track.init = resolveUrl(fillTemplate(st.attrs.initialization, vars), repBase);
          const mediaT = st.attrs.media;
          const timeline = kids(st, 'SegmentTimeline')[0];
          if (mediaT && timeline) {
            let t = 0;
            let n = startNumber;
            for (const S of kids(timeline, 'S')) {
              if (S.attrs.t !== undefined) t = parseInt(S.attrs.t, 10);
              const d = parseInt(S.attrs.d, 10);
              let r = S.attrs.r !== undefined ? parseInt(S.attrs.r, 10) : 0;
              if (r < 0) r = periodDur && d ? Math.max(0, Math.ceil((periodDur * timescale - t) / d) - 1) : 0;
              for (let i = 0; i <= r; i++) {
                track.segments.push(resolveUrl(fillTemplate(mediaT, { ...vars, Number: n, Time: t }), repBase));
                t += d;
                n++;
              }
            }
          } else if (mediaT) {
            const d = parseInt(st.attrs.duration || '0', 10);
            let count = 0;
            if (st.attrs.endNumber) count = parseInt(st.attrs.endNumber, 10) - startNumber + 1;
            else if (d && periodDur) count = Math.ceil((periodDur * timescale) / d);
            for (let i = 0; i < count; i++) {
              track.segments.push(resolveUrl(fillTemplate(mediaT, { ...vars, Number: startNumber + i }), repBase));
            }
          }
        } else if (sl) {
          const init = kids(sl, 'Initialization')[0];
          if (init?.attrs.sourceURL) track.init = resolveUrl(init.attrs.sourceURL, repBase);
          for (const su of kids(sl, 'SegmentURL')) {
            if (su.attrs.media) track.segments.push(resolveUrl(su.attrs.media, repBase));
          }
        } else if (repBase && repBase !== base) {
          track.single = repBase; // 單一檔案（BaseURL）
        }
        if (track.init || track.segments.length || track.single) tracks.push(track);
      }
    }
    return { type: 'mpd', tracks, duration: periodDur };
  }

  /* ===================== 區段下載引擎 ===================== */
  function hexToBytes(hex) {
    const h = hex.replace(/^0x/i, '').padStart(32, '0').slice(-32);
    const out = new Uint8Array(16);
    for (let i = 0; i < 16; i++) out[i] = parseInt(h.substr(i * 2, 2), 16);
    return out;
  }
  function seqToIV(seq) {
    const out = new Uint8Array(16);
    new DataView(out.buffer).setUint32(12, seq >>> 0);
    return out;
  }

  // items: [{ url, range?, key?: { url, iv }, seq? }]
  function makeJob(items, opts = {}) {
    return {
      items,
      parts: new Array(items.length),
      doneFlags: new Array(items.length).fill(false),
      completed: 0,
      bytes: 0,
      paused: false,
      cancelled: false,
      controller: null,
      waiters: [],
      keyCache: new Map(),
      concurrency: opts.concurrency || 6,
      retries: opts.retries ?? 3,
      fetchInit: opts.fetchInit || { credentials: 'include' }
    };
  }

  async function waitIfPaused(job) {
    while (job.paused && !job.cancelled) await new Promise((r) => job.waiters.push(r));
  }
  function setPaused(job, on) {
    job.paused = on;
    if (!on) job.waiters.splice(0).forEach((r) => r());
  }
  function cancelJob(job) {
    job.cancelled = true;
    job.controller?.abort();
    setPaused(job, false);
  }

  function getKey(job, keyUrl) {
    if (!job.keyCache.has(keyUrl)) {
      job.keyCache.set(keyUrl, (async () => {
        const res = await fetch(keyUrl, { ...job.fetchInit, signal: job.controller.signal });
        if (!res.ok) throw new Error(`金鑰下載失敗 HTTP ${res.status}`);
        const raw = await res.arrayBuffer();
        return crypto.subtle.importKey('raw', raw, 'AES-CBC', false, ['decrypt']);
      })().catch((e) => { job.keyCache.delete(keyUrl); throw e; }));
    }
    return job.keyCache.get(keyUrl);
  }

  async function fetchItem(job, i) {
    const it = job.items[i];
    let attempt = 0;
    for (;;) {
      try {
        const headers = {};
        if (it.range) headers.Range = `bytes=${it.range.offset}-${it.range.offset + it.range.length - 1}`;
        const res = await fetch(it.url, { ...job.fetchInit, headers, signal: job.controller.signal });
        if (!res.ok && res.status !== 206) throw new Error(`HTTP ${res.status}`);
        if (it.key) {
          const cryptoKey = await getKey(job, it.key.url);
          const iv = it.key.iv ? hexToBytes(it.key.iv) : seqToIV(it.seq || 0);
          const plain = await crypto.subtle.decrypt({ name: 'AES-CBC', iv }, cryptoKey, await res.arrayBuffer());
          job.parts[i] = new Blob([plain]);
          job.bytes += plain.byteLength;
        } else {
          const blob = await res.blob();
          job.parts[i] = blob;
          job.bytes += blob.size;
        }
        return;
      } catch (e) {
        if (job.cancelled || job.controller.signal.aborted) throw e;
        if (++attempt > job.retries) throw e;
        await sleep(500 * attempt);
      }
    }
  }

  // 可重複呼叫：失敗或取消後再次呼叫會從尚未完成的區段繼續
  async function runJob(job, onProgress) {
    job.cancelled = false;
    job.controller = new AbortController();
    const todo = [];
    for (let i = 0; i < job.items.length; i++) if (!job.doneFlags[i]) todo.push(i);
    let p = 0;
    let failure = null;
    const worker = async () => {
      while (!failure && !job.cancelled) {
        await waitIfPaused(job);
        if (failure || job.cancelled) return;
        const k = p++;
        if (k >= todo.length) return;
        const i = todo[k];
        try {
          await fetchItem(job, i);
          job.doneFlags[i] = true;
          job.completed++;
          onProgress?.(job);
        } catch (e) {
          if (job.cancelled) return;
          failure = failure || e;
          job.controller.abort();
          return;
        }
      }
    };
    await Promise.all(Array.from({ length: Math.min(job.concurrency, todo.length) }, worker));
    if (job.cancelled) throw new Error('已取消');
    if (failure) throw failure;
  }

  // 依檔頭判斷容器格式
  async function sniffContainer(blob) {
    const b = new Uint8Array(await blob.slice(0, 12).arrayBuffer());
    if (b[0] === 0x47) return 'ts';
    const tag = String.fromCharCode(b[4] || 0, b[5] || 0, b[6] || 0, b[7] || 0);
    if (['ftyp', 'styp', 'moof', 'sidx'].includes(tag)) return 'mp4';
    if (b[0] === 0x49 && b[1] === 0x44 && b[2] === 0x33) return 'aac'; // ID3
    if (b[0] === 0xff && (b[1] & 0xf0) === 0xf0) return 'aac'; // ADTS
    return 'bin';
  }

  async function assemble(job, { audioOnly = false } = {}) {
    const firstIdx = job.parts.findIndex(Boolean);
    const container = firstIdx >= 0 ? await sniffContainer(job.parts[firstIdx]) : 'bin';
    const map = {
      ts: ['ts', 'video/mp2t'],
      mp4: [audioOnly ? 'm4a' : 'mp4', audioOnly ? 'audio/mp4' : 'video/mp4'],
      aac: ['aac', 'audio/aac'],
      bin: ['bin', 'application/octet-stream']
    };
    const [ext, type] = map[container];
    return { blob: new Blob(job.parts, { type }), ext, container };
  }

  const api = {
    resolveUrl, formatBytes, sanitizeFilename,
    parseM3U8, parseXML, parseMPD, isoDuration, fillTemplate,
    makeJob, runJob, setPaused, cancelJob, assemble, sniffContainer
  };
  root.StreamCore = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
