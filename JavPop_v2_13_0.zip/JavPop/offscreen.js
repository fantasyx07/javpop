// 下載引擎（執行於 offscreen 文件）：關閉彈出視窗後仍會持續下載。
// offscreen 文件只能使用 chrome.runtime，所以 downloads / declarativeNetRequest 經由 service worker 代為呼叫。
(() => {
  'use strict';
  const SC = StreamCore;
  const MAX_RUNNING = 2; // 同時進行的串流任務數

  const px = async (api, ...args) => {
    const r = await chrome.runtime.sendMessage({ type: 'dl-proxy', api, args });
    if (r && r.error) throw new Error(r.error);
    return r ? r.result : undefined;
  };
  const dl = {
    download: (o) => px('downloads.download', o),
    search: (q) => px('downloads.search', q),
    pause: (id) => px('downloads.pause', id),
    resume: (id) => px('downloads.resume', id),
    cancel: (id) => px('downloads.cancel', id),
    show: (id) => px('downloads.show', id)
  };
  const dnr = {
    updateSessionRules: (o) => px('dnr.updateSessionRules', o),
    getSessionRules: () => px('dnr.getSessionRules')
  };

  const tasks = [];
  let nextId = 1;

  const STATE_LABEL = {
    analyzing: '分析中…', choose: '請選擇畫質', queued: '排隊中', downloading: '下載中',
    paused: '已暫停', saving: '儲存中…', done: '完成', error: '失敗', cancelled: '已取消'
  };
  const ACTIVE = ['analyzing', 'choose', 'queued', 'downloading', 'paused', 'saving'];

  // 儲存位置：「下載」資料夾底下的子資料夾（可多層）；或每次跳出另存視窗讓使用者自選
  const cleanFolder = (v) => String(v || '').split(/[\\/]+/)
    .map((p) => p.replace(/[<>:"|?*\x00-\x1f]/g, '').trim().replace(/[. ]+$/, ''))
    .filter((p) => p && p !== '.' && p !== '..')
    .join('/');
  async function destOf(fileName) {
    const s = (await px('storage.get', { dlFolder: 'JavPop', dlSaveAs: false })) || {};
    const folder = cleanFolder(s.dlFolder);
    return { filename: folder ? `${folder}/${fileName}` : fileName, saveAs: !!s.dlSaveAs };
  }

  const hostOf = (u) => { try { return new URL(u).hostname; } catch { return ''; } };
  const mbps = (bw) => (bw ? `${(bw / 1e6).toFixed(bw >= 1e7 ? 0 : 1)} Mbps` : '');

  /* ===================== Referer（部分網站會檢查來源頁面） ===================== */
  const ruleIds = new Map();
  let ruleSeq = 1000;

  async function setReferer(t, urls = []) {
    if (!t.referer) return;
    const hosts = new Set(t.hosts || []);
    urls.forEach((u) => { const h = hostOf(u); if (h) hosts.add(h); });
    t.hosts = [...hosts];
    if (!t.hosts.length) return;
    const id = ruleIds.get(t.id) ?? ++ruleSeq;
    ruleIds.set(t.id, id);
    const requestHeaders = [{ header: 'referer', operation: 'set', value: t.referer }];
    try { requestHeaders.push({ header: 'origin', operation: 'set', value: new URL(t.referer).origin }); } catch { /* 無效的來源 */ }
    await dnr.updateSessionRules({
      removeRuleIds: [id],
      addRules: [{
        id, priority: 1,
        action: { type: 'modifyHeaders', requestHeaders },
        condition: { requestDomains: t.hosts, initiatorDomains: [chrome.runtime.id], resourceTypes: ['xmlhttprequest', 'other'] }
      }]
    });
  }
  async function clearReferer(t) {
    const id = ruleIds.get(t.id);
    if (!id) return;
    ruleIds.delete(t.id);
    await dnr.updateSessionRules({ removeRuleIds: [id] }).catch(() => {});
  }

  async function fetchText(url) {
    const res = await fetch(url, { credentials: 'include' });
    if (!res.ok) throw new Error(`讀取清單失敗 HTTP ${res.status}`);
    return res.text();
  }

  /* ===================== 建立任務 ===================== */
  function addTask(item) {
    const t = {
      id: nextId++, url: item.url, kind: item.kind, ext: item.ext || '', size: item.size || 0,
      title: SC.sanitizeFilename(item.title || hostOf(item.url) || 'video'),
      referer: item.referer || '', state: item.kind === 'file' ? 'queued' : 'analyzing',
      msg: '', note: '', parts: [], options: [], choice: 0, withAudio: true,
      downloadId: null, fileBytes: 0, fileTotal: 0, savedBytes: 0,
      speed: 0, lastBytes: 0, lastTime: 0, cancelled: false, el: null
    };
    tasks.unshift(t);
    refresh();
    if (t.kind === 'file') pump();
    else analyze(t);
    return t;
  }

  /* ===================== 分析串流清單 ===================== */
  async function analyze(t) {
    try {
      await setReferer(t, [t.url]);
      const text = await fetchText(t.url);
      if (t.kind === 'hls') {
        const pl = SC.parseM3U8(text, t.url);
        if (pl.type === 'master') {
          const vs = [...pl.variants].sort((a, b) => b.bandwidth - a.bandwidth);
          if (!vs.length) throw new Error('清單中沒有可用的畫質');
          t.audioMedia = pl.audioMedia;
          t.options = vs.map((v) => {
            const h = /x(\d+)/.exec(v.resolution)?.[1];
            const label = [h ? `${h}p` : '', mbps(v.bandwidth), v.name].filter(Boolean).join(' · ') || '預設畫質';
            return { label, variant: v };
          });
        } else {
          t.options = [{ label: '預設畫質', media: true }];
        }
      } else {
        const mpd = SC.parseMPD(text, t.url);
        if (mpd.unsupported) throw new Error(mpd.unsupported);
        const ok = mpd.tracks.filter((x) => !x.drm);
        if (!ok.length) throw new Error(mpd.tracks.length ? '此串流使用 DRM 保護，無法下載' : '清單中沒有可下載的影音軌');
        const videos = ok.filter((x) => x.kind === 'video').sort((a, b) => b.bandwidth - a.bandwidth);
        const audios = ok.filter((x) => x.kind === 'audio').sort((a, b) => b.bandwidth - a.bandwidth);
        t.audioTrack = videos.length ? audios[0] || null : null;
        t.options = (videos.length ? videos : audios).map((tr) => ({
          label: tr.kind === 'audio'
            ? `音訊 · ${Math.round(tr.bandwidth / 1000)} kbps`
            : [tr.height ? `${tr.height}p` : '', mbps(tr.bandwidth), tr.codecs.split('.')[0]].filter(Boolean).join(' · ') || '預設畫質',
          track: tr
        }));
      }
      if (t.options.length === 1) choose(t, 0, true);
      else { t.state = 'choose'; refresh(t); }
    } catch (e) {
      fail(t, e);
    }
  }

  function choose(t, idx, withAudio) {
    const opt = t.options[idx];
    t.parts = [];
    if (t.kind === 'hls') {
      if (opt.media) t.parts.push({ label: '', url: t.url });
      else {
        const v = opt.variant;
        const aud = withAudio && v.audio
          ? (t.audioMedia || []).filter((a) => a.group === v.audio).sort((a, b) => Number(b.default) - Number(a.default))[0]
          : null;
        const split = !!(aud && aud.url !== v.url);
        t.parts.push({ label: split ? 'video' : '', url: v.url });
        if (split) t.parts.push({ label: 'audio', url: aud.url, audioOnly: true });
      }
    } else {
      const tr = opt.track;
      const split = !!(withAudio && t.audioTrack && tr.kind === 'video');
      t.parts.push({ label: split ? 'video' : '', track: tr, audioOnly: tr.kind === 'audio' });
      if (split) t.parts.push({ label: 'audio', track: t.audioTrack, audioOnly: true });
    }
    t.note = t.parts.length > 1 ? '影音分離：會存成兩個檔案，可用 ffmpeg 合併（見頁面底部說明）' : '';
    t.state = 'queued';
    refresh(t);
    pump();
  }

  /* ===================== 佇列調度 ===================== */
  function pump() {
    let running = tasks.filter((x) => x.kind !== 'file' && (x.state === 'downloading' || x.state === 'saving')).length;
    for (const t of [...tasks].reverse()) {
      if (t.state !== 'queued') continue;
      if (t.kind === 'file') { runFile(t); continue; }
      if (running >= MAX_RUNNING) continue;
      running++;
      runStream(t);
    }
  }

  function fail(t, e) {
    if (t.state === 'cancelled') return;
    t.state = 'error';
    t.msg = e?.message || String(e);
    clearReferer(t);
    refresh(t);
    pump();
  }

  /* ===================== 串流任務 ===================== */
  async function preparePart(t, part) {
    if (part.job) return;
    let items = [];
    if (part.track) {
      const tr = part.track;
      if (tr.single) items = [{ url: tr.single }];
      else {
        if (tr.init) items.push({ url: tr.init });
        tr.segments.forEach((u) => items.push({ url: u }));
      }
    } else {
      const pl = SC.parseM3U8(await fetchText(part.url), part.url);
      if (pl.type !== 'media') throw new Error('預期為單一畫質的播放清單');
      if (pl.unsupported) throw new Error(pl.unsupported);
      if (!pl.ended) throw new Error('直播串流（沒有 ENDLIST）不支援');
      if (!pl.segments.length) throw new Error('播放清單沒有任何區段');
      if (pl.map) items.push({ url: pl.map.url, range: pl.map.range });
      pl.segments.forEach((s) => items.push({ url: s.url, range: s.range, key: s.key, seq: s.seq }));
    }
    if (!items.length) throw new Error('沒有可下載的區段');
    part.job = SC.makeJob(items);
    await setReferer(t, [...items.map((i) => i.url), ...items.filter((i) => i.key).map((i) => i.key.url)]);
  }

  async function runStream(t) {
    t.state = 'downloading';
    t.msg = '';
    refresh(t);
    try {
      await setReferer(t, [t.url, ...t.parts.map((p) => p.url).filter(Boolean)]);
      for (const part of t.parts) await preparePart(t, part);
      if (t.cancelled) throw new Error('已取消');
      for (const part of t.parts) {
        if (part.saved) continue;
        if (!part.done) {
          await SC.runJob(part.job, () => {});
          part.done = true;
        }
        t.state = 'saving';
        refresh(t);
        const { blob, ext } = await SC.assemble(part.job, { audioOnly: !!part.audioOnly });
        await saveBlob(t, part, blob, ext);
        t.savedBytes += blob.size;
        part.saved = true;
        part.job.parts = [];
        t.state = 'downloading';
      }
      t.state = 'done';
      clearReferer(t);
      refresh(t);
      pump();
    } catch (e) {
      if (t.cancelled) return;
      fail(t, e);
    }
  }

  async function saveBlob(t, part, blob, ext) {
    const base = t.title + (t.parts.length > 1 && part.label ? `.${part.label}` : '');
    const url = URL.createObjectURL(blob);
    try {
      const id = await dl.download({ url, ...(await destOf(`${base}.${ext}`)), conflictAction: 'uniquify' });
      t.downloadId = id;
      await waitDownload(t, id, false);
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  // 輪詢 chrome.downloads，直到完成或中斷
  function waitDownload(t, id, track) {
    return new Promise((resolve, reject) => {
      const tick = async () => {
        if (t.cancelled) return reject(new Error('已取消'));
        const [d] = await dl.search({ id });
        if (!d) return reject(new Error('下載項目不存在'));
        if (track) {
          t.fileBytes = d.bytesReceived || 0;
          t.fileTotal = d.totalBytes > 0 ? d.totalBytes : t.size;
          if (t.state === 'downloading' || t.state === 'paused') {
            const st = d.paused ? 'paused' : 'downloading';
            if (st !== t.state) { t.state = st; refresh(t); }
          }
        }
        if (d.state === 'complete') return resolve(d);
        if (d.state === 'interrupted') return reject(new Error(`下載中斷：${d.error || '未知原因'}`));
        setTimeout(tick, 400);
      };
      tick().catch(reject);
    });
  }

  /* ===================== 直連檔案（chrome.downloads） ===================== */
  async function runFile(t) {
    t.state = 'downloading';
    t.msg = '';
    t.canFallback = false;
    refresh(t);
    try {
      const id = await dl.download({ url: t.url, ...(await destOf(`${t.title}.${t.ext || 'mp4'}`)), conflictAction: 'uniquify' });
      t.downloadId = id;
      await waitDownload(t, id, true);
      t.state = 'done';
      refresh(t);
    } catch (e) {
      if (t.cancelled) return;
      t.canFallback = true;
      t.note = '瀏覽器直接下載失敗（可能需要來源頁面 Referer），可改用 fetch 帶 Referer 重試';
      fail(t, e);
    }
  }

  async function runFileViaFetch(t) {
    t.state = 'downloading';
    t.msg = '';
    t.note = '';
    t.canFallback = false;
    refresh(t);
    try {
      await setReferer(t, [t.url]);
      if (!t.parts.length) t.parts = [{ label: '', job: SC.makeJob([{ url: t.url }], { concurrency: 1 }) }];
      const part = t.parts[0];
      await SC.runJob(part.job, () => {});
      t.state = 'saving';
      refresh(t);
      const blob = new Blob(part.job.parts, { type: 'application/octet-stream' });
      await saveBlob(t, { label: '' }, blob, t.ext || 'mp4');
      t.savedBytes = blob.size;
      part.job.parts = [];
      t.state = 'done';
      clearReferer(t);
      refresh(t);
    } catch (e) {
      if (t.cancelled) return;
      t.canFallback = true;
      fail(t, e);
    }
  }

  /* ===================== 控制 ===================== */
  async function act(t, action, arg) {
    switch (action) {
      case 'start':
        if (t.state === 'choose') choose(t, Number(arg?.idx) || 0, arg?.withAudio !== false);
        break;
      case 'pause':
        if (t.kind === 'file' && t.downloadId != null) await dl.pause(t.downloadId).catch(() => {});
        else t.parts.forEach((p) => p.job && SC.setPaused(p.job, true));
        t.state = 'paused';
        refresh(t);
        break;
      case 'resume':
        if (t.kind === 'file' && t.downloadId != null) await dl.resume(t.downloadId).catch(() => {});
        else t.parts.forEach((p) => p.job && SC.setPaused(p.job, false));
        t.state = 'downloading';
        refresh(t);
        break;
      case 'cancel':
        t.cancelled = true;
        t.state = 'cancelled';
        t.parts.forEach((p) => p.job && SC.cancelJob(p.job));
        if (t.downloadId != null && t.kind === 'file') dl.cancel(t.downloadId).catch(() => {});
        clearReferer(t);
        refresh(t);
        pump();
        break;
      case 'retry':
        t.cancelled = false;
        t.msg = '';
        t.state = 'queued';
        if (t.kind !== 'file' && !t.parts.length) { t.state = 'analyzing'; refresh(t); analyze(t); break; }
        refresh(t);
        pump();
        break;
      case 'fallback':
        t.cancelled = false;
        runFileViaFetch(t);
        break;
      case 'show':
        if (t.downloadId != null) dl.show(t.downloadId);
        break;
      case 'remove': {
        t.cancelled = true;
        t.parts.forEach((p) => p.job && SC.cancelJob(p.job));
        clearReferer(t);
        tasks.splice(tasks.indexOf(t), 1);
        refresh();
        break;
      }
    }
  }


  /* ===================== 畫面資料與廣播 ===================== */
  function progressOf(t) {
    if (t.kind === 'file' && !t.parts.length) {
      const pct = t.fileTotal ? Math.min(100, (t.fileBytes / t.fileTotal) * 100) : 0;
      return { pct, text: t.fileTotal ? `${SC.formatBytes(t.fileBytes)} / ${SC.formatBytes(t.fileTotal)}` : SC.formatBytes(t.fileBytes), bytes: t.fileBytes };
    }
    let done = 0, total = 0, bytes = t.savedBytes;
    t.parts.forEach((p) => {
      if (p.saved) { done += p.job.items.length; total += p.job.items.length; }
      else if (p.job) { done += p.job.completed; total += p.job.items.length; bytes += p.job.bytes; }
    });
    const pct = t.state === 'done' ? 100 : total ? (done / total) * 100 : 0;
    const seg = t.kind === 'file' ? '' : `區段 ${done}/${total} · `;
    return { pct, text: `${seg}${SC.formatBytes(bytes)}`, bytes };
  }

  function view(t) {
    const p = progressOf(t);
    const info = [];
    if (['downloading', 'paused', 'saving', 'done', 'error'].includes(t.state)) {
      if (t.state !== 'done' && p.pct) info.push(`${p.pct.toFixed(1)}%`);
      info.push(p.text);
      if (t.state === 'downloading' && t.speed > 0) info.push(`${SC.formatBytes(t.speed)}/s`);
      if (t.parts.length > 1) {
        const idx = t.parts.findIndex((x) => !x.saved);
        if (idx >= 0 && t.state !== 'done') info.push(`第 ${idx + 1}/${t.parts.length} 個檔案（${t.parts[idx].label}）`);
      }
    }
    return {
      id: t.id, url: t.url, title: t.title, kind: t.kind, ext: t.ext, state: t.state,
      stateText: t.msg && t.state === 'error' ? `失敗：${t.msg}` : STATE_LABEL[t.state],
      pct: p.pct, info: info.join(' · '), note: t.note,
      options: t.state === 'choose' ? t.options.map((o) => o.label) : [],
      hasAudio: t.kind === 'hls' ? (t.audioMedia || []).length > 0 : !!t.audioTrack,
      canFallback: !!t.canFallback, hasDownload: t.downloadId != null
    };
  }

  function snapshot() {
    return { tasks: tasks.map(view), active: tasks.filter((t) => ACTIVE.includes(t.state)).length };
  }

  let broadcastTimer = null;
  function refresh() { // 合併短時間內的多次更新
    if (broadcastTimer) return;
    broadcastTimer = setTimeout(() => {
      broadcastTimer = null;
      chrome.runtime.sendMessage({ type: 'dlq-state', ...snapshot() }).catch(() => {}); // 彈出視窗未開啟時沒有接收者，忽略
    }, 250);
  }

  // 速度與進度定時更新
  setInterval(() => {
    const now = Date.now();
    tasks.forEach((t) => {
      if (t.state !== 'downloading' && t.state !== 'paused') return;
      const bytes = progressOf(t).bytes;
      const dt = (now - (t.lastTime || now)) / 1000;
      if (t.lastTime && dt > 0) {
        const inst = Math.max(0, (bytes - t.lastBytes) / dt);
        t.speed = t.speed ? t.speed * 0.6 + inst * 0.4 : inst;
      }
      if (t.state === 'paused') t.speed = 0;
      t.lastBytes = bytes;
      t.lastTime = now;
      refresh();
    });
  }, 700);

  /* ===================== 來自彈出視窗的指令 ===================== */
  chrome.runtime.onMessage.addListener((m, _sender, sendResponse) => {
    if (m.type === 'clip-copy') { // 寫入剪貼簿（service worker 沒有 DOM，所以由這裡執行）
      const ta = document.createElement('textarea');
      ta.value = String(m.text || '');
      ta.style.cssText = 'position:fixed;opacity:0;';
      document.body.appendChild(ta);
      ta.select();
      let ok = false;
      try { ok = document.execCommand('copy'); } catch { /* 忽略 */ }
      ta.remove();
      sendResponse({ ok });
      return false;
    }
    if (m.type !== 'dlq-cmd') return false;
    const t = tasks.find((x) => x.id === m.id);
    switch (m.cmd) {
      case 'get': break;
      case 'add': addTask(m.item); break;
      case 'clearDone':
        tasks.filter((x) => x.state === 'done' || x.state === 'cancelled').forEach((x) => act(x, 'remove'));
        break;
      default: if (t) act(t, m.cmd, m);
    }
    sendResponse(snapshot());
    return false;
  });

  // 清掉上次殘留的 Referer 規則
  dnr.getSessionRules()
    .then((rules) => dnr.updateSessionRules({ removeRuleIds: rules.map((r) => r.id) }))
    .catch(() => {});
})();
